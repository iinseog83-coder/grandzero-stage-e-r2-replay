/-
  GRANDZERO Ω — Stage D (Algebraic Dynamics, Invariants, Barriers & Memory Gate)
  Module D-1: Q0GuardedDiscreteDynamicsAndTrajectories.lean
  Scope:
    1. Unit- & authority-typed discrete dynamical specification `GuardedDynSpecQ0`
       bound directly to frozen `Stage B` declarations (`BridgeMorphismQ0`,
       `BridgeCertQ0`, `checkBridgeUnitsOnly`, `checkBridgeStatic`, `checkBridgeCert`,
       `thm_transport_maps_valid_domain` — `Tribunal F-D03`).
    2. Rate-field dimensional gate `expectedRateUnit` (`[u_i / s]` preserving `KindTagQ0`).
    3. Multi-step partial trajectory evaluator `iterateStep`, one-step forward invariance
       `ForwardInvariant`, non-vacuous forward invariance `NonVacuousForwardInvariant`,
       and all-time (`∀ t ∈ ℕ`) pole-free domain preservation `thm_forward_invariant_all_steps`.
-/

import StageC

namespace GrandZero.StageD

open GrandZero.StageA
open GrandZero.StageB
open GrandZero.StageC

/-! ### Part 1: Rate-Unit Synthesis & `GuardedDynSpecQ0` Bound to Frozen `Stage B` (`F-D03`) -/

/-- Exact SI time-derivative unit `[u / s]` preserving physical `KindTagQ0`. -/
def expectedRateUnit (u : UnitSpecQ0) : UnitSpecQ0 :=
  { dim := DimVec7.sub u.dim UnitSpecQ0.second.dim, kind := u.kind }

/-- Check that every expression in a continuous rate vector field `F` synthesizes `[Γ[i] / s]`. -/
def checkRateFieldUnits (Γ : VarCtxQ0) : List ExprQ0 → VarCtxQ0 → Bool
  | [], [] => true
  | f :: fs, u :: us =>
      (synthUnit Γ f == some (expectedRateUnit u)) &&
      checkRateFieldUnits Γ fs us
  | _, _ => false

theorem checkRateFieldUnits_length {Γ : VarCtxQ0} :
    ∀ {fs : List ExprQ0} {us : VarCtxQ0},
      checkRateFieldUnits Γ fs us = true → fs.length = us.length
  | [], [], _ => rfl
  | [], _ :: _, h => by simp [checkRateFieldUnits] at h
  | _ :: _, [], h => by simp [checkRateFieldUnits] at h
  | _ :: fs, _ :: us, h => by
      simp only [checkRateFieldUnits, Bool.and_eq_true] at h
      exact congrArg Nat.succ (checkRateFieldUnits_length h.2)

/-- Fine-grained static rejection reason for `Stage D` (`Section 3`). -/
inductive StageDInvalidReasonQ0 where
  | illTypedDynamics     : StageDInvalidReasonQ0
  | authorityEscalation  : StageDInvalidReasonQ0
  | invalidBarrierOrRate : StageDInvalidReasonQ0
  | invalidSheafBase     : StageDInvalidReasonQ0
  deriving DecidableEq, Repr, Inhabited

/-- Unit- & authority-typed guarded discrete dynamical system over `StageB.ContextQ0`,
    optionally paired with a formal continuous rate vector field `optRateField`. -/
structure GuardedDynSpecQ0 where
  ctx          : ContextQ0
  stepCoords   : List ExprQ0
  optRateField : Option (List ExprQ0) := none
  sysAuth      : AuthorityVecQ0 := AuthorityVecQ0.formalOnly
  claimedAuth  : AuthorityVecQ0 := AuthorityVecQ0.formalOnly
  deriving DecidableEq, Repr, Inhabited

namespace GuardedDynSpecQ0

/-- Canonical step endomorphism `C → C` bound directly to frozen `StageB.BridgeMorphismQ0` (`F-D03`). -/
def toStepBridge (D : GuardedDynSpecQ0) : BridgeMorphismQ0 :=
  { src     := D.ctx
    dst     := D.ctx
    coords  := D.stepCoords
    srcAuth := D.sysAuth
    dstAuth := D.claimedAuth }

end GuardedDynSpecQ0

/-- Static unit & optional rate-field dimensional check for `GuardedDynSpecQ0`. -/
def checkDynUnitsOnly (D : GuardedDynSpecQ0) : Bool :=
  checkBridgeUnitsOnly D.toStepBridge &&
  match D.optRateField with
  | none       => true
  | some rates => checkRateFieldUnits D.ctx.vars rates D.ctx.vars

/-- Ordered static validator for `GuardedDynSpecQ0` (`Step 1: Units` → `Step 2: 3D Authority`). -/
def validateDynSpecStatic (D : GuardedDynSpecQ0) : Option StageDInvalidReasonQ0 :=
  if !checkDynUnitsOnly D then
    some .illTypedDynamics
  else if !checkAuthorityLe D.claimedAuth D.sysAuth then
    some .authorityEscalation
  else
    none

theorem lem_validateDynSpecStatic_none_imp_bridgeStatic {D : GuardedDynSpecQ0}
    (hv : validateDynSpecStatic D = none) :
    checkBridgeStatic D.toStepBridge = true ∧
    AuthorityLe D.claimedAuth D.sysAuth := by
  unfold validateDynSpecStatic at hv
  cases hu : checkDynUnitsOnly D with
  | false => simp [hu] at hv
  | true =>
      simp only [hu, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hv
      cases ha : checkAuthorityLe D.claimedAuth D.sysAuth with
      | false => simp [ha] at hv
      | true =>
          unfold checkDynUnitsOnly at hu
          simp only [Bool.and_eq_true] at hu
          refine ⟨?_, (lem_checkAuthorityLe_iff _ _).mp ha⟩
          unfold checkBridgeStatic
          rw [hu.1]
          exact ha

/-! ### Part 2: Partial Multi-Step Trajectory Evaluation & Forward Invariance (`∀ t ∈ ℕ`) -/

/-- Exact `t`-step partial trajectory evaluator: returns `none` immediately if any intermediate
    step hits a division-by-zero pole. -/
def iterateStep (stepCoords : List ExprQ0) : Nat → List Rat → Option (List Rat)
  | 0,     ρ₀ => some ρ₀
  | t + 1, ρ₀ =>
      match iterateStep stepCoords t ρ₀ with
      | none    => none
      | some ρt => evalCoords ρt stepCoords

@[simp] theorem iterateStep_zero (stepCoords : List ExprQ0) (ρ₀ : List Rat) :
    iterateStep stepCoords 0 ρ₀ = some ρ₀ := rfl

@[simp] theorem iterateStep_succ (stepCoords : List ExprQ0) (t : Nat) (ρ₀ : List Rat) :
    iterateStep stepCoords (t + 1) ρ₀ =
      match iterateStep stepCoords t ρ₀ with
      | none    => none
      | some ρt => evalCoords ρt stepCoords := rfl

/-- Semantic one-step forward domain invariance of `D` on `Real_ℚ(D.ctx)`. -/
def ForwardInvariant (D : GuardedDynSpecQ0) : Prop :=
  ∀ ρ : List Rat, ValidDomainQ0 ρ D.ctx →
    ∃ ρ' : List Rat, evalCoords ρ D.stepCoords = some ρ' ∧ ValidDomainQ0 ρ' D.ctx

/-- Non-vacuous forward domain invariance (`Real_ℚ(D.ctx) ≠ ∅` ∧ `ForwardInvariant D`). -/
def NonVacuousForwardInvariant (D : GuardedDynSpecQ0) : Prop :=
  (∃ ρ₀ : List Rat, ValidDomainQ0 ρ₀ D.ctx) ∧ ForwardInvariant D

/-- Vacuous Forward Invariance Trap Theorem:
    Whenever `Real_ℚ(D.ctx) = ∅` (certified by `StageB.checkEmptyOverlapCert`), `ForwardInvariant D`
    holds vacuously, yet `NonVacuousForwardInvariant D` is FALSE. -/
theorem thm_empty_safe_domain_vacuous_invariance
    (D : GuardedDynSpecQ0) (ec : EmptyOverlapCertQ0)
    (hec : checkEmptyOverlapCert D.ctx ec = true) :
    ForwardInvariant D ∧ ¬ NonVacuousForwardInvariant D := by
  have hemp := thm_empty_overlap_sound D.ctx ec hec
  refine ⟨?_, ?_⟩
  · intro ρ hval
    exact False.elim (hemp ρ hval)
  · rintro ⟨⟨ρ₀, h₀⟩, _⟩
    exact hemp ρ₀ h₀

/-- Exact Frozen `Stage B` Bridge Soundness Binding (`F-D03`):
    Passing `StageB.checkBridgeCert D.toStepBridge cert = true` certifies 3D authority
    non-escalation AND `ForwardInvariant D`. -/
theorem thm_stepBridgeCert_imp_forwardInvariant
    (D : GuardedDynSpecQ0) (cert : BridgeCertQ0)
    (hcert : checkBridgeCert D.toStepBridge cert = true) :
    AuthorityLe D.claimedAuth D.sysAuth ∧ ForwardInvariant D := by
  rcases thm_transport_maps_valid_domain D.toStepBridge cert hcert with ⟨hauth, hmap⟩
  exact ⟨hauth, hmap⟩

/-- Target Theorem `thm_forward_invariant_all_steps`:
    If `ForwardInvariant D` holds, then for EVERY initial state `ρ₀ ∈ Real_ℚ(D.ctx)` and
    EVERY horizon `t ∈ ℕ`, the `t`-step trajectory `iterateStep D.stepCoords t ρ₀` is
    total (pole-free, returning `some ρt`) and remains inside `Real_ℚ(D.ctx)`. -/
theorem thm_forward_invariant_all_steps
    (D : GuardedDynSpecQ0)
    (hinv : ForwardInvariant D)
    (ρ₀ : List Rat) (h₀ : ValidDomainQ0 ρ₀ D.ctx) :
    ∀ t : Nat, ∃ ρt : List Rat,
      iterateStep D.stepCoords t ρ₀ = some ρt ∧ ValidDomainQ0 ρt D.ctx
  | 0 => ⟨ρ₀, rfl, h₀⟩
  | t + 1 => by
      rcases thm_forward_invariant_all_steps D hinv ρ₀ h₀ t with ⟨ρt, hit, hvt⟩
      rcases hinv ρt hvt with ⟨ρ_next, hev, hv_next⟩
      exact ⟨ρ_next, by simp [iterateStep, hit, hev], hv_next⟩

/-- Direct corollary combining frozen `StageB.checkBridgeCert` + verified initial state `ρ₀` (`F-D03`). -/
theorem thm_certified_step_all_time_safe
    (D : GuardedDynSpecQ0) (cert : BridgeCertQ0) (ρ₀ : List Rat)
    (hcert : checkBridgeCert D.toStepBridge cert = true)
    (hinit : checkValidDomainQ0 ρ₀ D.ctx = true) :
    AuthorityLe D.claimedAuth D.sysAuth ∧
    NonVacuousForwardInvariant D ∧
    ∀ t : Nat, ∃ ρt : List Rat,
      iterateStep D.stepCoords t ρ₀ = some ρt ∧ ValidDomainQ0 ρt D.ctx := by
  rcases thm_stepBridgeCert_imp_forwardInvariant D cert hcert with ⟨hauth, hinv⟩
  have h₀ : ValidDomainQ0 ρ₀ D.ctx := (lem_checkValidDomain_iff ρ₀ D.ctx).mp hinit
  exact ⟨hauth, ⟨⟨ρ₀, h₀⟩, hinv⟩, thm_forward_invariant_all_steps D hinv ρ₀ h₀⟩

end GrandZero.StageD
