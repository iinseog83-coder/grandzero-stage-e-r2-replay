/-
  GRANDZERO Ω — Stage E-R2 (Identifiability, Bounded-Error Set-Membership,
                            Surgical SEM Interventions & Conditional Empirical Qualification Gate)
  Structured Audit Executable (`stage_e_r2_audit`)
  Note: Every boolean and rational field printed below is computed dynamically at
        runtime by the Lean kernel functions (zero hardcoded `"true"` literals).
-/

import StageE

open GrandZero.StageA
open GrandZero.StageB
open GrandZero.StageC
open GrandZero.StageD
open GrandZero.StageE

def main : IO Unit := do
  IO.println "=========================================================================="
  IO.println "GRANDZERO OMEGA — STAGE E-R2 IDENTIFIABILITY, INTERVENTION & EMPIRICAL GATE"
  IO.println "=========================================================================="

  let mut allVectorsOk := true
  for rec in stageEVectorRecords do
    let matched := decide (rec.expected = rec.actual)
    if !matched then
      allVectorsOk := false
    IO.println s!"VECTOR|ID={rec.vecId}|EXPECTED={formatStageEOutcome rec.expected}|ACTUAL={formatStageEOutcome rec.actual}|MATCH={matched}|DETAIL={rec.detail}"

  -- Live runtime verification of F-E01 & F-E02 (non-zero offset d₀ = 3, affine left-inverse recovery, tight LP)
  let d0NonZero := decide (te01_design.d0 ⟨0, by decide⟩ ≠ 0)
  let leftInvOk := vecEqBool (affineLeftInverseEst te01_design te01_rc (te01_design.predict (vecOfList 2 [10, 5])))
                             (vecOfList 2 [10, 5])
  let tightTe01Ok := checkTightQueryIntervalCert te01_design te01_anchor.yObs te01_anchor.eps te01_spec.cQuery te01_lpTight
  IO.println s!"EXTRA|ID=TE-01-FE01-FE02|OFFSET_D0_NONZERO={d0NonZero}|AFFINE_LEFT_INV_OK={leftInvOk}|TIGHT_MINIMAX_OK={tightTe01Ok}"

  -- Live runtime verification of F-E03 (separate noiseless StructuralQueryIdentifiable vs positive noisy width > 0)
  let structIdOk := checkQueryOrthogonalKernel te02_design te02_rc te02b_cQuery
  let qLbVal := te02b_lpEnclosing.qLb te02_anchor.yObs te02_anchor.eps
  let qUbVal := te02b_lpEnclosing.qUb te02_anchor.yObs te02_anchor.eps
  let widthVal := te02b_lpEnclosing.width te02_anchor.yObs te02_anchor.eps
  let widthPosOk := decide (qLbVal = 9 ∧ qUbVal = 11 ∧ widthVal = 2 ∧ 0 < widthVal)
  IO.println s!"EXTRA|ID=TE-02B-FE03-SPLIT|STRUCT_QUERY_ID={structIdOk}|NOISY_BOUNDS_9_11_WIDTH2_POS={widthPosOk}"

  -- Live runtime verification of F-E04 (Canonical 3-node IV Wald = 3 = do-effect ≠ 19/6 OLS + bad exclusion blocked)
  let waldEqDo := decide (te04c_M3.SigmaObs ivIdx0 ivIdx2 / te04c_M3.SigmaObs ivIdx0 ivIdx1 =
                          interventionalUnitEffect te04c_sc1 ivIdx2)
  let olsBiased := decide (te04c_M3.SigmaObs ivIdx1 ivIdx2 / te04c_M3.SigmaObs ivIdx1 ivIdx1 ≠
                           interventionalUnitEffect te04c_sc1 ivIdx2)
  let badExclBlocked := !checkCanonicalIV3Assumptions te04c_badExclusionM3 te04c_sc1
  IO.println s!"EXTRA|ID=TE-04C-FE04-IV3|WALD_EQ_DO_EFFECT={waldEqDo}|OLS_BIASED_BY_CONFOUNDER={olsBiased}|BAD_EXCLUSION_BLOCKED={badExclBlocked}"

  -- Live runtime verification of F-E05 (forged external label & tampered-ε stolen-ID both fail TCB provenance)
  let forgedAttesterBlocked := !verifyExternalProvenance stageE_tcb te07b2_forgedOriginAnchor
  let tamperedEpsBlocked := !verifyExternalProvenance stageE_tcb te07b2_tamperedEpsAnchor
  let dynEscapeOk := checkDynHoldoutResidualEscape td02_dyn td01_H [2, 0, 1, 1] 1 2 (1 / 2)
  IO.println s!"EXTRA|ID=TE-07B2-FE05-PROVENANCE|FORGED_ATTESTER_BLOCKED={forgedAttesterBlocked}|TAMPERED_EPS_BLOCKED={tamperedEpsBlocked}|STAGED_HOLDOUT_ESCAPE={dynEscapeOk}"

  -- Live runtime verification of F-E06 & F-E07 (unattested holdout blocked, mismatch schedule & degenerate clamp blocked)
  let badHoldoutBlocked := decide (auditStageEEmpiricalGate stageE_tcb te08a_badHoldoutSpec te08a_badHoldoutBundle =
                                   .rejectedUnattestedEmpiricalQualification)
  let mismatchClampBlocked := decide (auditStageEEmpiricalGate stageE_tcb te08b_mismatchSpec te08b_mismatchBundle =
                                      .rejectedInvalidCertificate)
  let sameClampBlocked := decide (auditStageEEmpiricalGate stageE_tcb te04b_spec te08b_degenerateSameClampBundle =
                                  .rejectedInvalidCertificate)
  IO.println s!"EXTRA|ID=TE-08AB-FE06-FE07|UNATTESTED_HOLDOUT_BLOCKED={badHoldoutBlocked}|MISMATCH_CLAMP_BLOCKED={mismatchClampBlocked}|SAME_CLAMP_BLOCKED={sameClampBlocked}"

  -- Live runtime verification of F-E08 Dual-Lock (Lock 2A const-offset diff, Lock 2B channel-cal diff, Lock 1 tampered & post-hoc blocked)
  let lock2aDiffOk := checkConstantOffsetDiffRefutation te04b_design rfl ⟨0, by decide⟩ ⟨1, by decide⟩
                        te04b_anchor.yObs te04b_anchor.eps (interventionalUnitEffect te04_sc2 ⟨1, by decide⟩)
  let lock2bDiffOk := checkCalibratedOffsetDiffRefutation te08c_channelCalDesign rfl ⟨0, by decide⟩ ⟨1, by decide⟩
                        te08c_d0Chan te08c_yObsChan te04b_anchor.eps (interventionalUnitEffect te04_sc2 ⟨1, by decide⟩)
  let tamperedCalBlocked := !verifyExternalProvenance stageE_tcb te08d_tamperedCalAnchor
  let posthocSeqBlocked := !verifyExternalProvenance te08d_posthocTcb te08d_posthocAnchor
  IO.println s!"EXTRA|ID=TE-08CD-FE08-DUALLOCK|LOCK2A_CONST_DIFF={lock2aDiffOk}|LOCK2B_CHAN_DIFF={lock2bDiffOk}|TAMPERED_D0_BLOCKED={tamperedCalBlocked}|POSTHOC_SEQ_BLOCKED={posthocSeqBlocked}"

  let allOk := allVectorsOk && d0NonZero && leftInvOk && tightTe01Ok &&
               structIdOk && widthPosOk && waldEqDo && olsBiased &&
               badExclBlocked && forgedAttesterBlocked && tamperedEpsBlocked && dynEscapeOk &&
               badHoldoutBlocked && mismatchClampBlocked && sameClampBlocked &&
               lock2aDiffOk && lock2bDiffOk && tamperedCalBlocked && posthocSeqBlocked
  IO.println "--------------------------------------------------------------------------"
  IO.println s!"ALL STAGE E-R2 IDENTIFIABILITY, INTERVENTION & EMPIRICAL VECTORS MATCH EXPECTED: {allOk}"
  if !allOk then
    throw (IO.userError "Stage E-R2 adversarial audit failed!")
