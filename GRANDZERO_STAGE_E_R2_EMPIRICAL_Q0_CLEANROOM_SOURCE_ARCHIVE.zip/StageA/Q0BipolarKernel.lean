/-
  GRANDZERO Ω — Stage A (M1-P0 R3) Isolated Kernel
  Module A-5: Q0BipolarKernel.lean
  Scope: Target-Bound Guard Proof Checker `checkGuardProof` (`THM-GUARD-PROOF-SOUND`),
         6-Channel `SyndromeQ0`, `ProofCertQ0` (AST, Lowered SSA, & 3-Tier Raw SSA),
         `auditProof` (`THM-SYNDROME-SOUND`), `checkObstruction` (`THM-L05-BIPOLAR`),
         and Mechanized Verification of Adversarial Cross-Term Vectors `XT-01 ~ XT-06`
         plus `R3` Commutation Traces `Trace A / B / C`.
-/

import StageA.Q0GuardedReflection

namespace GrandZero.StageA

/-! ### Part 1: Target-Bound Guard Proof Checker (`M1-P0 R2` §2.1) -/

/-- Plain first-order guard discharge proof witness (`M1-P0 R1/R2`). -/
inductive GuardProofQ0 where
  | gActiveMem  : Nat → GuardProofQ0
  | gRatLit     : GuardProofQ0
  | gPosImpNz   : GuardProofQ0 → GuardProofQ0
  | gPosImpNNeg : GuardProofQ0 → GuardProofQ0
  | gMulNz      : GuardProofQ0 → GuardProofQ0 → GuardProofQ0
  | gDivNz      : GuardProofQ0 → GuardProofQ0 → GuardProofQ0
  | gHypEqLitNz : Nat → GuardProofQ0
  deriving DecidableEq, Repr, Inhabited

/-- Trusted target-bound guard judgment checker `Γ_vars; Γ_hyps; Ω ⊢_GQ0 p : target` (`R2` §2.1). -/
def checkGuardProof
    (Γ_vars : VarCtxQ0) (Γ_hyps : HypCtxQ0) (Ω : List GuardQ0)
    (p : GuardProofQ0) (target : GuardQ0) : Bool :=
  if (synthUnit Γ_vars (guardExpr target)).isNone then false
  else
    match p, target with
    | .gActiveMem idx, ω =>
        match Ω[idx]? with
        | some ω' => decide (ω' = ω)
        | none    => false
    | .gRatLit, .nonZero (.ratLit q _) => decide (q ≠ 0)
    | .gRatLit, .pos     (.ratLit q _) => decide (0 < q)
    | .gRatLit, .nonNeg  (.ratLit q _) => decide (0 ≤ q)
    | .gPosImpNz p_pos,   .nonZero e   => checkGuardProof Γ_vars Γ_hyps Ω p_pos (.pos e)
    | .gPosImpNNeg p_pos, .nonNeg  e   => checkGuardProof Γ_vars Γ_hyps Ω p_pos (.pos e)
    | .gMulNz p1 p2, .nonZero (.binOp .mul e1 e2) =>
        checkGuardProof Γ_vars Γ_hyps Ω p1 (.nonZero e1) &&
        checkGuardProof Γ_vars Γ_hyps Ω p2 (.nonZero e2)
    | .gDivNz p1 p2, .nonZero (.binOp .div e1 e2) =>
        checkGuardProof Γ_vars Γ_hyps Ω p1 (.nonZero e1) &&
        checkGuardProof Γ_vars Γ_hyps Ω p2 (.nonZero e2)
    | .gHypEqLitNz hyp_idx, .nonZero e =>
        match Γ_hyps[hyp_idx]? with
        | some (.eqProp lhs (.ratLit q _)) => decide (lhs = e ∧ q ≠ 0)
        | some (.eqProp (.ratLit q _) rhs) => decide (rhs = e ∧ q ≠ 0)
        | _                                => false
    | _, _ => false

theorem rat_pos_imp_ne_zero {q : Rat} (h : 0 < q) : q ≠ 0 := by grind
theorem rat_pos_imp_nonneg {q : Rat} (h : 0 < q) : 0 ≤ q := by grind

/-- Target Theorem `THM-GUARD-PROOF-SOUND` (`M1-P0 R2` §2.1):
    Any guard proof accepted by `checkGuardProof` guarantees static well-typedness of
    the target guard expression AND semantic truth of `evalGuard ρ target = true`. -/
theorem thm_guard_proof_sound
    (Γ_vars : VarCtxQ0) (Γ_hyps : HypCtxQ0) (Ω : List GuardQ0) (ρ : List Rat)
    (henv : EnvModelsCtx ρ Γ_vars)
    (hhyps : HypsHold ρ Γ_hyps)
    (hguards : GuardsHold ρ Ω) :
    ∀ (p : GuardProofQ0) (ω : GuardQ0),
      checkGuardProof Γ_vars Γ_hyps Ω p ω = true →
      (synthUnit Γ_vars (guardExpr ω)).isSome = true ∧ evalGuard ρ ω = true
  | p, ω, hchk => by
      unfold checkGuardProof at hchk
      cases hsu : synthUnit Γ_vars (guardExpr ω) with
      | none =>
          simp [hsu] at hchk
      | some u_ω =>
        simp only [hsu, Option.isNone_some, Bool.false_eq_true, ↓reduceIte] at hchk
        refine ⟨by simp, ?_⟩
        cases p with
        | gActiveMem idx =>
            dsimp only at hchk
            cases hget : Ω[idx]? with
            | none => rw [hget] at hchk; contradiction
            | some ω' =>
                rw [hget] at hchk
                simp only [decide_eq_true_eq] at hchk
                subst hchk
                exact hguards ω' (List.mem_of_getElem? hget)
        | gRatLit =>
            cases ω with
            | nonZero d =>
                cases d <;> try contradiction
                rename_i q u
                simp only [decide_eq_true_eq] at hchk
                exact (evalGuard_nonZero_iff ρ (.ratLit q u)).mpr ⟨q, rfl, hchk⟩
            | pos d =>
                cases d <;> try contradiction
                rename_i q u
                simp only [decide_eq_true_eq] at hchk
                exact (evalGuard_pos_iff ρ (.ratLit q u)).mpr ⟨q, rfl, hchk⟩
            | nonNeg d =>
                cases d <;> try contradiction
                rename_i q u
                simp only [decide_eq_true_eq] at hchk
                exact (evalGuard_nonNeg_iff ρ (.ratLit q u)).mpr ⟨q, rfl, hchk⟩
        | gPosImpNz p_pos =>
            cases ω with
            | pos _ | nonNeg _ => contradiction
            | nonZero e =>
                have ih := (thm_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p_pos (.pos e) hchk).2
                rcases (evalGuard_pos_iff ρ e).mp ih with ⟨v, hv, hpos⟩
                exact (evalGuard_nonZero_iff ρ e).mpr ⟨v, hv, rat_pos_imp_ne_zero hpos⟩
        | gPosImpNNeg p_pos =>
            cases ω with
            | nonZero _ | pos _ => contradiction
            | nonNeg e =>
                have ih := (thm_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p_pos (.pos e) hchk).2
                rcases (evalGuard_pos_iff ρ e).mp ih with ⟨v, hv, hpos⟩
                exact (evalGuard_nonNeg_iff ρ e).mpr ⟨v, hv, rat_pos_imp_nonneg hpos⟩
        | gMulNz p1 p2 =>
            cases ω with
            | pos _ | nonNeg _ => contradiction
            | nonZero d =>
                cases d with
                | bvar _ | ratLit _ _ | unaryNeg _ | letBind _ _ => contradiction
                | binOp op e1 e2 =>
                    cases op with
                    | add | sub | div => contradiction
                    | mul =>
                        simp only [Bool.and_eq_true] at hchk
                        have ih1 := (thm_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p1 (.nonZero e1) hchk.1).2
                        have ih2 := (thm_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p2 (.nonZero e2) hchk.2).2
                        rcases (evalGuard_nonZero_iff ρ e1).mp ih1 with ⟨v1, hv1, hnz1⟩
                        rcases (evalGuard_nonZero_iff ρ e2).mp ih2 with ⟨v2, hv2, hnz2⟩
                        exact (evalGuard_nonZero_iff ρ (.binOp .mul e1 e2)).mpr
                          ⟨v1 * v2, by simp [denoteExpr, evalBinOp, hv1, hv2], rat_mul_ne_zero hnz1 hnz2⟩
        | gDivNz p1 p2 =>
            cases ω with
            | pos _ | nonNeg _ => contradiction
            | nonZero d =>
                cases d with
                | bvar _ | ratLit _ _ | unaryNeg _ | letBind _ _ => contradiction
                | binOp op e1 e2 =>
                    cases op with
                    | add | sub | mul => contradiction
                    | div =>
                        simp only [Bool.and_eq_true] at hchk
                        have ih1 := (thm_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p1 (.nonZero e1) hchk.1).2
                        have ih2 := (thm_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p2 (.nonZero e2) hchk.2).2
                        rcases (evalGuard_nonZero_iff ρ e1).mp ih1 with ⟨v1, hv1, hnz1⟩
                        rcases (evalGuard_nonZero_iff ρ e2).mp ih2 with ⟨v2, hv2, hnz2⟩
                        exact (evalGuard_nonZero_iff ρ (.binOp .div e1 e2)).mpr
                          ⟨v1 / v2, by simp [denoteExpr, evalBinOp, hv1, hv2, hnz2], rat_div_ne_zero hnz1 hnz2⟩
        | gHypEqLitNz hyp_idx =>
            cases ω with
            | pos _ | nonNeg _ => contradiction
            | nonZero e =>
                dsimp only at hchk
                cases hget : Γ_hyps[hyp_idx]? with
                | none => rw [hget] at hchk; contradiction
                | some prop =>
                    rw [hget] at hchk
                    have hprop_true := hhyps prop (List.mem_of_getElem? hget)
                    cases prop with
                    | eqProp lhs rhs =>
                        -- Check how `match` in `checkGuardProof` splits on `(lhs, rhs)`:
                        -- First pattern: `(.eqProp lhs (.ratLit q _))`!
                        cases rhs with
                        | ratLit q u =>
                            simp only [decide_eq_true_eq] at hchk
                            rcases hchk with ⟨hlhs, hq_nz⟩
                            subst hlhs
                            simp only [denoteProp, denoteExpr] at hprop_true
                            cases he : denoteExpr ρ lhs with
                            | none => rw [he] at hprop_true; contradiction
                            | some ve =>
                                rw [he] at hprop_true
                                simp only [Option.some.injEq, decide_eq_true_eq] at hprop_true
                                subst hprop_true
                                exact (evalGuard_nonZero_iff ρ lhs).mpr ⟨ve, he, hq_nz⟩
                        | bvar _ | unaryNeg _ | binOp _ _ _ | letBind _ _ =>
                            cases lhs with
                            | ratLit q u =>
                                simp only [decide_eq_true_eq] at hchk
                                rcases hchk with ⟨hrhs, hq_nz⟩
                                rw [hrhs] at hprop_true
                                simp only [denoteProp, denoteExpr] at hprop_true
                                cases he : denoteExpr ρ e with
                                | none => rw [he] at hprop_true; contradiction
                                | some ve =>
                                    rw [he] at hprop_true
                                    simp only [Option.some.injEq, decide_eq_true_eq] at hprop_true
                                    subst hprop_true
                                    exact (evalGuard_nonZero_iff ρ e).mpr ⟨q, he, hq_nz⟩
                            | _ => contradiction

/-- Pairwise verification of a list of target guards against a list of `GuardProofQ0`s. -/
def checkGuardListProofs
    (Γ_vars : VarCtxQ0) (Γ_hyps : HypCtxQ0) (Ω : List GuardQ0) :
    List GuardProofQ0 → List GuardQ0 → Bool
  | [], [] => true
  | p :: ps, ω :: ωs =>
      checkGuardProof Γ_vars Γ_hyps Ω p ω &&
      checkGuardListProofs Γ_vars Γ_hyps Ω ps ωs
  | _, _ => false

theorem thm_guard_list_sound
    (Γ_vars : VarCtxQ0) (Γ_hyps : HypCtxQ0) (Ω : List GuardQ0) (ρ : List Rat)
    (henv : EnvModelsCtx ρ Γ_vars)
    (hhyps : HypsHold ρ Γ_hyps)
    (hguards : GuardsHold ρ Ω) :
    ∀ (ps : List GuardProofQ0) (targets : List GuardQ0),
      checkGuardListProofs Γ_vars Γ_hyps Ω ps targets = true →
      GuardsHold ρ targets
  | [], [], _ => fun _ hm => by simp at hm
  | [], _ :: _, h => by simp [checkGuardListProofs] at h
  | _ :: _, [], h => by simp [checkGuardListProofs] at h
  | p :: ps, ω :: ωs, h => by
      simp only [checkGuardListProofs, Bool.and_eq_true] at h
      have hd := (thm_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p ω h.1).2
      have tl := thm_guard_list_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards ps ωs h.2
      intro g hg
      cases List.mem_cons.mp hg with
      | inl heq => subst heq; exact hd
      | inr hmem => exact tl g hmem

/-! ### Part 2: 6-Channel Diagnostic `SyndromeQ0` & `ProofCertQ0` (`M1-P0 R1~R3`) -/

structure SyndromeQ0 where
  illTypedOrScopeError      : Nat := 0
  unitOrKindMismatch        : Nat := 0
  unguardedPoleLeak         : Nat := 0
  polynomialResidualNonZero : Nat := 0
  invalidGuardOrHypProof    : Nat := 0
  structuralBindMismatch    : Nat := 0
  deriving DecidableEq, Repr, Inhabited

namespace SyndromeQ0

def zero : SyndromeQ0 := {}

def add (s1 s2 : SyndromeQ0) : SyndromeQ0 :=
  { illTypedOrScopeError      := s1.illTypedOrScopeError + s2.illTypedOrScopeError
    unitOrKindMismatch        := s1.unitOrKindMismatch + s2.unitOrKindMismatch
    unguardedPoleLeak         := s1.unguardedPoleLeak + s2.unguardedPoleLeak
    polynomialResidualNonZero := s1.polynomialResidualNonZero + s2.polynomialResidualNonZero
    invalidGuardOrHypProof    := s1.invalidGuardOrHypProof + s2.invalidGuardOrHypProof
    structuralBindMismatch    := s1.structuralBindMismatch + s2.structuralBindMismatch }

theorem add_eq_zero_iff (s1 s2 : SyndromeQ0) :
    SyndromeQ0.add s1 s2 = SyndromeQ0.zero ↔ s1 = SyndromeQ0.zero ∧ s2 = SyndromeQ0.zero := by
  cases s1; cases s2
  simp only [SyndromeQ0.add, SyndromeQ0.zero, mk.injEq]
  omega

end SyndromeQ0

/-- Proof certificate language for `SIR-Core-Q0` supporting AST reflection, lowered SSA
    reflection, 3-tier validated `RawTape` reflection, and compositional equational steps. -/
inductive ProofCertQ0 where
  | gprAstCert         : (lhsGuards rhsGuards : List GuardProofQ0) → ProofCertQ0
  | gprLoweredTapeCert : (lhsGuards rhsGuards : List GuardProofQ0) → ProofCertQ0
  | gprRawTapeCert     : (raw : RawTape) → (lhsRoot rhsRoot : Nat) →
                         (lhsGuards rhsGuards : List GuardProofQ0) → ProofCertQ0
  | hypEqCert          : (hypIdx : Nat) → ProofCertQ0
  | symmCert           : ProofCertQ0 → ProofCertQ0
  | transCert          : (mid : ExprQ0) → ProofCertQ0 → ProofCertQ0 → ProofCertQ0
  deriving DecidableEq, Repr, Inhabited

/-- Shared core check for two reflected `GPRResultQ0`s (`ra`, `rb`). -/
def verifyGPRPair
    (Γ_vars : VarCtxQ0) (Γ_hyps : HypCtxQ0) (Ω : List GuardQ0)
    (ra rb : GPRResultQ0)
    (lhsProofs rhsProofs : List GuardProofQ0) : SyndromeQ0 :=
  if ra.unit != rb.unit then
    { unitOrKindMismatch := 1 }
  else if !(checkGuardListProofs Γ_vars Γ_hyps Ω lhsProofs ra.guards &&
            checkGuardListProofs Γ_vars Γ_hyps Ω rhsProofs rb.guards) then
    { unguardedPoleLeak := 1
      invalidGuardOrHypProof :=
        if lhsProofs.length == ra.guards.length && rhsProofs.length == rb.guards.length then 1 else 0 }
  else if canonPoly (polySub (polyMul ra.num rb.den) (polyMul rb.num ra.den)) != PolyQ0.zero then
    { polynomialResidualNonZero := 1 }
  else
    SyndromeQ0.zero

theorem verifyGPRPair_eq_zero_iff
    (Γ_vars : VarCtxQ0) (Γ_hyps : HypCtxQ0) (Ω : List GuardQ0)
    (ra rb : GPRResultQ0) (lp rp : List GuardProofQ0) :
    verifyGPRPair Γ_vars Γ_hyps Ω ra rb lp rp = SyndromeQ0.zero →
    ra.unit = rb.unit ∧
    checkGuardListProofs Γ_vars Γ_hyps Ω lp ra.guards = true ∧
    checkGuardListProofs Γ_vars Γ_hyps Ω rp rb.guards = true ∧
    canonPoly (polySub (polyMul ra.num rb.den) (polyMul rb.num ra.den)) = PolyQ0.zero := by
  unfold verifyGPRPair
  intro h
  by_cases hu : ra.unit != rb.unit
  · simp [hu, SyndromeQ0.zero] at h
  · simp only [hu] at h
    have hueq : ra.unit = rb.unit := by
      simp [bne_iff_ne] at hu; exact hu
    by_cases hg : !(checkGuardListProofs Γ_vars Γ_hyps Ω lp ra.guards &&
                    checkGuardListProofs Γ_vars Γ_hyps Ω rp rb.guards)
    · simp [hg, SyndromeQ0.zero] at h
    · simp only [hg] at h
      have hg_both : checkGuardListProofs Γ_vars Γ_hyps Ω lp ra.guards = true ∧
                     checkGuardListProofs Γ_vars Γ_hyps Ω rp rb.guards = true := by
        cases h1 : checkGuardListProofs Γ_vars Γ_hyps Ω lp ra.guards <;>
        cases h2 : checkGuardListProofs Γ_vars Γ_hyps Ω rp rb.guards <;>
        simp [h1, h2] at hg ⊢
      by_cases hp : canonPoly (polySub (polyMul ra.num rb.den) (polyMul rb.num ra.den)) != PolyQ0.zero
      · simp [hp, SyndromeQ0.zero] at h
      · have hpeq : canonPoly (polySub (polyMul ra.num rb.den) (polyMul rb.num ra.den)) = PolyQ0.zero := by
          simp [bne_iff_ne] at hp; exact hp
        exact ⟨hueq, hg_both.1, hg_both.2, hpeq⟩

/-- Total computable Fail-Closed Whitebox Proof Auditor (`auditProof`, `M1-P0 R1~R3`). -/
def auditProof
    (Γ_vars : VarCtxQ0) (Γ_hyps : HypCtxQ0) (Ω : List GuardQ0) :
    ProofCertQ0 → ExprQ0 → ExprQ0 → SyndromeQ0
  | .gprAstCert lp rp, a, b =>
      if !(wellScoped Γ_vars.length a && wellScoped Γ_vars.length b) then
        { illTypedOrScopeError := 1 }
      else
        match reflectExpr Γ_vars a, reflectExpr Γ_vars b with
        | some ra, some rb => verifyGPRPair Γ_vars Γ_hyps Ω ra rb lp rp
        | _, _             => { unitOrKindMismatch := 1 }
  | .gprLoweredTapeCert lp rp, a, b =>
      if hsc : wellScoped Γ_vars.length a = true ∧ wellScoped Γ_vars.length b = true then
        let rta := lowerExprTop Γ_vars.length ⟨a, hsc.1⟩
        let rtb := lowerExprTop Γ_vars.length ⟨b, hsc.2⟩
        match reflectTapeRoot Γ_vars rta, reflectTapeRoot Γ_vars rtb with
        | some ra, some rb => verifyGPRPair Γ_vars Γ_hyps Ω ra rb lp rp
        | _, _             => { unitOrKindMismatch := 1 }
      else
        { illTypedOrScopeError := 1 }
  | .gprRawTapeCert raw lhsRoot rhsRoot lp rp, a, b =>
      -- 3-Tier RawTape Validation (`M1-P0 R3` §3):
      -- Tier 1: Structural index & backward-DAG bounds check
      match validateTape Γ_vars.length raw with
      | none => { illTypedOrScopeError := 1 }
      | some ⟨n, vt⟩ =>
          if hl : lhsRoot < n then
            if hr : rhsRoot < n then
              -- Tier 2: Global static unit check across all tape rows
              if !(checkAllRowsWellTyped Γ_vars vt) then
                { unitOrKindMismatch := 1 }
              else
                let lf : Fin n := ⟨lhsRoot, hl⟩
                let rf : Fin n := ⟨rhsRoot, hr⟩
                if !(reifyTape vt lf == a && reifyTape vt rf == b) then
                  { structuralBindMismatch := 1 }
                else
                  -- Tier 3: Local cone reflection & guard discharge
                  match reflectTape Γ_vars vt lf, reflectTape Γ_vars vt rf with
                  | some ra, some rb => verifyGPRPair Γ_vars Γ_hyps Ω ra rb lp rp
                  | _, _             => { unitOrKindMismatch := 1 }
            else { illTypedOrScopeError := 1 }
          else { illTypedOrScopeError := 1 }
  | .hypEqCert hypIdx, a, b =>
      match synthUnit Γ_vars a, synthUnit Γ_vars b with
      | some ua, some ub =>
          if ua != ub then
            { unitOrKindMismatch := 1 }
          else
            match Γ_hyps[hypIdx]? with
            | some (.eqProp lhs rhs) =>
                if lhs == a && rhs == b then SyndromeQ0.zero
                else { invalidGuardOrHypProof := 1 }
            | none => { invalidGuardOrHypProof := 1 }
      | _, _ =>
          if !(wellScoped Γ_vars.length a && wellScoped Γ_vars.length b) then
            { illTypedOrScopeError := 1 }
          else
            { unitOrKindMismatch := 1 }
  | .symmCert sub, a, b =>
      auditProof Γ_vars Γ_hyps Ω sub b a
  | .transCert mid p1 p2, a, b =>
      SyndromeQ0.add
        (auditProof Γ_vars Γ_hyps Ω p1 a mid)
        (auditProof Γ_vars Γ_hyps Ω p2 mid b)

/-! ### Part 3: Main Soundness Theorems (`THM-SYNDROME-SOUND` & `THM-L05-BIPOLAR`) -/

/-- Target Theorem `THM-SYNDROME-SOUND` (`M1-P0 R1` §3.2 / `R2` §3.2):
    Zero syndrome guarantees static physical unit equality AND universal `StrongEq`
    across every valid model environment `ρ`. -/
theorem thm_syndrome_sound :
    ∀ (cert : ProofCertQ0) (Γ_vars : VarCtxQ0) (Γ_hyps : HypCtxQ0)
      (Ω : List GuardQ0) (a b : ExprQ0),
      auditProof Γ_vars Γ_hyps Ω cert a b = SyndromeQ0.zero →
      (∃ u : UnitSpecQ0, synthUnit Γ_vars a = some u ∧ synthUnit Γ_vars b = some u) ∧
      (∀ ρ : List Rat,
        EnvModelsCtx ρ Γ_vars →
        HypsHold ρ Γ_hyps →
        GuardsHold ρ Ω →
        StrongEq ρ a b)
  | .gprAstCert lp rp, Γ_vars, Γ_hyps, Ω, a, b, haud => by
      unfold auditProof at haud
      by_cases hsc : !(wellScoped Γ_vars.length a && wellScoped Γ_vars.length b)
      · simp [hsc, SyndromeQ0.zero] at haud
      · simp only [hsc] at haud
        cases hra : reflectExpr Γ_vars a with
        | none => rw [hra] at haud; simp [SyndromeQ0.zero] at haud
        | some ra =>
          cases hrb : reflectExpr Γ_vars b with
          | none => rw [hra, hrb] at haud; simp [SyndromeQ0.zero] at haud
          | some rb =>
            rw [hra, hrb] at haud
            rcases verifyGPRPair_eq_zero_iff Γ_vars Γ_hyps Ω ra rb lp rp haud
              with ⟨hueq, hg_a, hg_b, hpoly0⟩
            have hua := (thm_gpr_unit_sound a Γ_vars ra hra).1
            have hub := (thm_gpr_unit_sound b Γ_vars rb hrb).1
            refine ⟨⟨ra.unit, hua, by rw [hueq]; exact hub⟩, ?_⟩
            intro ρ henv hhyps hguards
            have hga := thm_guard_list_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards lp ra.guards hg_a
            have hgb := thm_guard_list_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards rp rb.guards hg_b
            rcases thm_gpr_value_sound a Γ_vars ρ ra henv hra hga with ⟨hda, hdena⟩
            rcases thm_gpr_value_sound b Γ_vars ρ rb henv hrb hgb with ⟨hdb, hdenb⟩
            have hzero := canonPoly_eq_zero_sound hpoly0 ρ
            rw [evalPoly_sub, evalPoly_mul, evalPoly_mul] at hzero
            have hfrac_eq := rat_eq_of_cross_sub_zero _ _ _ _ hda hdb hzero
            exact ⟨evalPoly ρ ra.num / evalPoly ρ ra.den, hdena, by rw [hfrac_eq]; exact hdenb⟩
  | .gprLoweredTapeCert lp rp, Γ_vars, Γ_hyps, Ω, a, b, haud => by
      unfold auditProof at haud
      split at haud
      · rename_i hsc
        let rta := lowerExprTop Γ_vars.length ⟨a, hsc.1⟩
        let rtb := lowerExprTop Γ_vars.length ⟨b, hsc.2⟩
        cases hra : reflectTapeRoot Γ_vars rta with
        | none => simp [rta, hra, SyndromeQ0.zero] at haud
        | some ra =>
          cases hrb : reflectTapeRoot Γ_vars rtb with
          | none => simp [rta, rtb, hra, hrb, SyndromeQ0.zero] at haud
          | some rb =>
            simp only [rta, rtb, hra, hrb] at haud
            rcases verifyGPRPair_eq_zero_iff Γ_vars Γ_hyps Ω ra rb lp rp haud
              with ⟨hueq, hg_a, hg_b, hpoly0⟩
            have comm_a := thm_ast_tape_gpr_commute Γ_vars rfl ⟨a, hsc.1⟩
            have comm_b := thm_ast_tape_gpr_commute Γ_vars rfl ⟨b, hsc.2⟩
            have hua_t := (thm_tape_gpr_unit_sound Γ_vars rta.tape rta.root ra hra).1
            have hub_t := (thm_tape_gpr_unit_sound Γ_vars rtb.tape rtb.root rb hrb).1
            have hua : synthUnit Γ_vars a = some ra.unit := by
              rw [← comm_a.2.1]; exact hua_t
            have hub : synthUnit Γ_vars b = some ra.unit := by
              rw [← comm_b.2.1, hueq]; exact hub_t
            refine ⟨⟨ra.unit, hua, hub⟩, ?_⟩
            intro ρ henv hhyps hguards
            have hga := thm_guard_list_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards lp ra.guards hg_a
            have hgb := thm_guard_list_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards rp rb.guards hg_b
            rcases thm_tape_gpr_value_sound Γ_vars ρ henv rta.tape rta.root ra hra hga with ⟨hda, hdena⟩
            rcases thm_tape_gpr_value_sound Γ_vars ρ henv rtb.tape rtb.root rb hrb hgb with ⟨hdb, hdenb⟩
            have hzero := canonPoly_eq_zero_sound hpoly0 ρ
            rw [evalPoly_sub, evalPoly_mul, evalPoly_mul] at hzero
            have hfrac_eq := rat_eq_of_cross_sub_zero _ _ _ _ hda hdb hzero
            have heval_a : denoteExpr ρ a = some (evalPoly ρ ra.num / evalPoly ρ ra.den) := by
              rw [← comm_a.1 ρ henv]; exact hdena
            have heval_b : denoteExpr ρ b = some (evalPoly ρ ra.num / evalPoly ρ ra.den) := by
              rw [← comm_b.1 ρ henv, hfrac_eq]; exact hdenb
            exact ⟨_, heval_a, heval_b⟩
      · simp [SyndromeQ0.zero] at haud
  | .gprRawTapeCert raw lhsRoot rhsRoot lp rp, Γ_vars, Γ_hyps, Ω, a, b, haud => by
      unfold auditProof at haud
      cases hval : validateTape Γ_vars.length raw with
      | none => rw [hval] at haud; simp [SyndromeQ0.zero] at haud
      | some nvt =>
        rcases nvt with ⟨n, vt⟩
        rw [hval] at haud; dsimp only at haud
        if hl : lhsRoot < n then
          if hr : rhsRoot < n then
            simp only [hl, hr, ↓reduceDIte] at haud
            by_cases hwt : !(checkAllRowsWellTyped Γ_vars vt)
            · simp [hwt, SyndromeQ0.zero] at haud
            · simp only [hwt] at haud
              let lf : Fin n := ⟨lhsRoot, hl⟩
              let rf : Fin n := ⟨rhsRoot, hr⟩
              by_cases href : !(reifyTape vt lf == a && reifyTape vt rf == b)
              · simp [lf, rf, href, SyndromeQ0.zero] at haud
              · simp only [lf, rf, href] at haud
                have hreify_both : reifyTape vt lf = a ∧ reifyTape vt rf = b := by
                  cases h1 : (reifyTape vt lf == a) <;>
                  cases h2 : (reifyTape vt rf == b) <;>
                  simp [h1, h2] at href
                  exact ⟨beq_iff_eq.mp h1, beq_iff_eq.mp h2⟩
                cases hra : reflectTape Γ_vars vt lf with
                | none => rw [hra] at haud; simp [SyndromeQ0.zero] at haud
                | some ra =>
                  cases hrb : reflectTape Γ_vars vt rf with
                  | none => rw [hra, hrb] at haud; simp [SyndromeQ0.zero] at haud
                  | some rb =>
                    rw [hra, hrb] at haud
                    rcases verifyGPRPair_eq_zero_iff Γ_vars Γ_hyps Ω ra rb lp rp haud
                      with ⟨hueq, hg_a, hg_b, hpoly0⟩
                    have hua_t := (thm_tape_gpr_unit_sound Γ_vars vt lf ra hra).1
                    have hub_t := (thm_tape_gpr_unit_sound Γ_vars vt rf rb hrb).1
                    have hua : synthUnit Γ_vars a = some ra.unit := by
                      rw [← hreify_both.1, (lem_reify_exact vt lf).2 Γ_vars]; exact hua_t
                    have hub : synthUnit Γ_vars b = some ra.unit := by
                      rw [← hreify_both.2, (lem_reify_exact vt rf).2 Γ_vars, hueq]; exact hub_t
                    refine ⟨⟨ra.unit, hua, hub⟩, ?_⟩
                    intro ρ henv hhyps hguards
                    have hga := thm_guard_list_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards lp ra.guards hg_a
                    have hgb := thm_guard_list_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards rp rb.guards hg_b
                    rcases thm_tape_gpr_value_sound Γ_vars ρ henv vt lf ra hra hga with ⟨hda, hdena⟩
                    rcases thm_tape_gpr_value_sound Γ_vars ρ henv vt rf rb hrb hgb with ⟨hdb, hdenb⟩
                    have hzero := canonPoly_eq_zero_sound hpoly0 ρ
                    rw [evalPoly_sub, evalPoly_mul, evalPoly_mul] at hzero
                    have hfrac_eq := rat_eq_of_cross_sub_zero _ _ _ _ hda hdb hzero
                    have heval_a : denoteExpr ρ a = some (evalPoly ρ ra.num / evalPoly ρ ra.den) := by
                      rw [← hreify_both.1, (lem_reify_exact vt lf).1 ρ]; exact hdena
                    have heval_b : denoteExpr ρ b = some (evalPoly ρ ra.num / evalPoly ρ ra.den) := by
                      rw [← hreify_both.2, (lem_reify_exact vt rf).1 ρ, hfrac_eq]; exact hdenb
                    exact ⟨_, heval_a, heval_b⟩
          else simp [hl, hr, SyndromeQ0.zero] at haud
        else simp [hl, SyndromeQ0.zero] at haud
  | .hypEqCert hypIdx, Γ_vars, Γ_hyps, _, a, b, haud => by
      unfold auditProof at haud
      cases hua : synthUnit Γ_vars a with
      | none =>
          simp only [hua] at haud
          by_cases hsc : !(wellScoped Γ_vars.length a && wellScoped Γ_vars.length b) <;>
            simp [hsc, SyndromeQ0.zero] at haud
      | some ua =>
        cases hub : synthUnit Γ_vars b with
        | none =>
            simp only [hua, hub] at haud
            by_cases hsc : !(wellScoped Γ_vars.length a && wellScoped Γ_vars.length b) <;>
              simp [hsc, SyndromeQ0.zero] at haud
        | some ub =>
          simp only [hua, hub] at haud
          by_cases hu_ne : ua != ub
          · simp [hu_ne, SyndromeQ0.zero] at haud
          · simp only [hu_ne] at haud
            have hueq : ua = ub := by simp [bne_iff_ne] at hu_ne; exact hu_ne
            cases hget : Γ_hyps[hypIdx]? with
            | none => rw [hget] at haud; simp [SyndromeQ0.zero] at haud
            | some prop =>
              rw [hget] at haud
              cases prop with
              | eqProp lhs rhs =>
                  dsimp only at haud
                  by_cases hmatch : (lhs == a && rhs == b)
                  · have hab : lhs = a ∧ rhs = b := by
                      simp [Bool.and_eq_true, beq_iff_eq] at hmatch; exact hmatch
                    rcases hab with ⟨hab1, hab2⟩
                    subst hab1; subst hab2
                    refine ⟨⟨ua, rfl, congrArg some hueq.symm⟩, ?_⟩
                    intro ρ _ hhyps _
                    have hp := hhyps (.eqProp lhs rhs) (List.mem_of_getElem? hget)
                    simp only [denoteProp] at hp
                    cases hdl : denoteExpr ρ lhs with
                    | none => rw [hdl] at hp; contradiction
                    | some vl =>
                      cases hdr : denoteExpr ρ rhs with
                      | none => rw [hdl, hdr] at hp; contradiction
                      | some vr =>
                        rw [hdl, hdr] at hp
                        simp only [Option.some.injEq, decide_eq_true_eq] at hp
                        subst hp
                        exact ⟨vl, hdl, hdr⟩
                  · simp [hmatch, SyndromeQ0.zero] at haud
  | .symmCert sub, Γ_vars, Γ_hyps, Ω, a, b, haud => by
      unfold auditProof at haud
      rcases thm_syndrome_sound sub Γ_vars Γ_hyps Ω b a haud with ⟨⟨u, hb, ha⟩, hsem⟩
      exact ⟨⟨u, ha, hb⟩, fun ρ he hh hg => (hsem ρ he hh hg).symm⟩
  | .transCert mid p1 p2, Γ_vars, Γ_hyps, Ω, a, b, haud => by
      unfold auditProof at haud
      rcases (SyndromeQ0.add_eq_zero_iff _ _).mp haud with ⟨hz1, hz2⟩
      rcases thm_syndrome_sound p1 Γ_vars Γ_hyps Ω a mid hz1 with ⟨⟨u1, ha, hmid1⟩, hsem1⟩
      rcases thm_syndrome_sound p2 Γ_vars Γ_hyps Ω mid b hz2 with ⟨⟨u2, hmid2, hb⟩, hsem2⟩
      rw [hmid1] at hmid2
      injection hmid2 with hu
      subst hu
      exact ⟨⟨u1, ha, hb⟩,
             fun ρ he hh hg => (hsem1 ρ he hh hg).trans (hsem2 ρ he hh hg)⟩

/-- Tribunal Synthesis Corollary:
    `Accepted(p) ⟹ WellTyped(p) ∧ GuardSafe(p) ∧ SemanticallySound(p)`. -/
theorem thm_accepted_wellTyped_guardSafe_sound
    {cert : ProofCertQ0} {Γ_vars : VarCtxQ0} {Γ_hyps : HypCtxQ0}
    {Ω : List GuardQ0} {a b : ExprQ0}
    (haud : auditProof Γ_vars Γ_hyps Ω cert a b = SyndromeQ0.zero) :
    (∃ u : UnitSpecQ0, synthUnit Γ_vars a = some u ∧ synthUnit Γ_vars b = some u) ∧
    (∀ ρ : List Rat, EnvModelsCtx ρ Γ_vars → HypsHold ρ Γ_hyps → GuardsHold ρ Ω →
      (denoteExpr ρ a).isSome = true ∧ (denoteExpr ρ b).isSome = true) ∧
    (∀ ρ : List Rat, EnvModelsCtx ρ Γ_vars → HypsHold ρ Γ_hyps → GuardsHold ρ Ω →
      StrongEq ρ a b) := by
  rcases thm_syndrome_sound cert Γ_vars Γ_hyps Ω a b haud with ⟨hut, hsem⟩
  refine ⟨hut, ?_, hsem⟩
  intro ρ he hh hg
  rcases hsem ρ he hh hg with ⟨v, ha, hb⟩
  simp [ha, hb]

/-- Computable negative-pole obstruction checker (`checkObstruction`, `M1-P0 R1` §3.3). -/
def checkObstruction
    (Γ_vars : VarCtxQ0) (Γ_hyps : HypCtxQ0) (Ω : List GuardQ0)
    (ρ₀ : List Rat) (a b : ExprQ0) : Bool :=
  envModelsCtxBool ρ₀ Γ_vars &&
  hypsHoldBool ρ₀ Γ_hyps &&
  guardsHoldBool ρ₀ Ω &&
  !(strongEqBool ρ₀ a b)

/-- Target Theorem `THM-L05-BIPOLAR` (`M1-P0 R1` §3.3):
    A single valid counterwitness `ρ₀` passing `checkObstruction` refutes ALL possible
    proof certificates `cert : ProofCertQ0` in `SIR-Core-Q0`. -/
theorem thm_l05_bipolar
    {Γ_vars : VarCtxQ0} {Γ_hyps : HypCtxQ0} {Ω : List GuardQ0}
    {ρ₀ : List Rat} {a b : ExprQ0}
    (hobs : checkObstruction Γ_vars Γ_hyps Ω ρ₀ a b = true) :
    ∀ cert : ProofCertQ0, auditProof Γ_vars Γ_hyps Ω cert a b ≠ SyndromeQ0.zero := by
  intro cert haud
  unfold checkObstruction at hobs
  simp only [Bool.and_eq_true, Bool.not_eq_true'] at hobs
  rcases hobs with ⟨⟨⟨henvB, hhypsB⟩, hguardsB⟩, hneqB⟩
  have henv := (envModelsCtxBool_iff ρ₀ Γ_vars).mp henvB
  have hhyps := (hypsHoldBool_iff ρ₀ Γ_hyps).mp hhypsB
  have hguards := (guardsHoldBool_iff ρ₀ Ω).mp hguardsB
  have hstrong := (thm_syndrome_sound cert Γ_vars Γ_hyps Ω a b haud).2 ρ₀ henv hhyps hguards
  have htrue : strongEqBool ρ₀ a b = true := (strongEqBool_iff ρ₀ a b).mpr hstrong
  rw [htrue] at hneqB
  contradiction

/-! ### Part 4: Mechanized Verification of Adversarial Vectors `XT-01 ~ XT-06` (`R2` §4 & `R3` §4) -/

section AdversarialVectors

-- XT-01: Γ = [x : Meter], Ω = []
-- LHS: `let y := div 1_1 x in mul 0_m2 y`, RHS: `0_m`
def xt01_ctx : VarCtxQ0 := [UnitSpecQ0.meter]
def xt01_lhs : ExprQ0 :=
  .letBind (.binOp .div (.ratLit 1 UnitSpecQ0.unitless) (.bvar 0))
           (.binOp .mul (.ratLit 0 UnitSpecQ0.meterSq) (.bvar 0))
def xt01_rhs : ExprQ0 := .ratLit 0 UnitSpecQ0.meter

theorem xt01_expected_reject_syndrome :
    auditProof xt01_ctx [] [] (.gprLoweredTapeCert [] []) xt01_lhs xt01_rhs =
      { unguardedPoleLeak := 1 } := by decide

theorem xt01_obstruction_verified :
    checkObstruction xt01_ctx [] [] [0] xt01_lhs xt01_rhs = true := by decide

theorem xt01_unprovable_all_certs :
    ∀ cert : ProofCertQ0,
      auditProof xt01_ctx [] [] cert xt01_lhs xt01_rhs ≠ SyndromeQ0.zero :=
  thm_l05_bipolar xt01_obstruction_verified

-- XT-02: Γ = [x_0 : Unitless], Ω = [nonZero(x_0)]
-- `let y := x_0 + 1_1 in (1_1 / y) * y = 1_1` (De Bruijn scope shift trap at x_0 = -1)
def xt02_ctx : VarCtxQ0 := [UnitSpecQ0.unitless]
def xt02_guards : List GuardQ0 := [.nonZero (.bvar 0)]
def xt02_lhs : ExprQ0 :=
  .letBind (.binOp .add (.bvar 0) (.ratLit 1 UnitSpecQ0.unitless))
           (.binOp .mul (.binOp .div (.ratLit 1 UnitSpecQ0.unitless) (.bvar 0)) (.bvar 0))
def xt02_rhs : ExprQ0 := .ratLit 1 UnitSpecQ0.unitless

theorem xt02_expected_reject_syndrome :
    auditProof xt02_ctx [] xt02_guards (.gprLoweredTapeCert [.gActiveMem 0] []) xt02_lhs xt02_rhs =
      { unguardedPoleLeak := 1, invalidGuardOrHypProof := 1 } := by decide

theorem xt02_obstruction_verified :
    checkObstruction xt02_ctx [] xt02_guards [-1] xt02_lhs xt02_rhs = true := by
  with_unfolding_all rfl

theorem xt02_unprovable_all_certs :
    ∀ cert : ProofCertQ0,
      auditProof xt02_ctx [] xt02_guards cert xt02_lhs xt02_rhs ≠ SyndromeQ0.zero :=
  thm_l05_bipolar xt02_obstruction_verified

-- XT-03: Γ = [x : Unitless], Ω = [pos(x)]
-- `1_1 / (x / x) = 1_1` with nested guard discharge `[gPosImpNz, gDivNz]`
def xt03_ctx : VarCtxQ0 := [UnitSpecQ0.unitless]
def xt03_guards : List GuardQ0 := [.pos (.bvar 0)]
def xt03_lhs : ExprQ0 :=
  .binOp .div (.ratLit 1 UnitSpecQ0.unitless) (.binOp .div (.bvar 0) (.bvar 0))
def xt03_rhs : ExprQ0 := .ratLit 1 UnitSpecQ0.unitless
def xt03_proofs : List GuardProofQ0 :=
  [.gPosImpNz (.gActiveMem 0),
   .gDivNz (.gPosImpNz (.gActiveMem 0)) (.gPosImpNz (.gActiveMem 0))]

theorem xt03_expected_pass_ast :
    auditProof xt03_ctx [] xt03_guards (.gprAstCert xt03_proofs []) xt03_lhs xt03_rhs =
      SyndromeQ0.zero := by
  with_unfolding_all rfl

theorem xt03_expected_pass_tape :
    auditProof xt03_ctx [] xt03_guards (.gprLoweredTapeCert xt03_proofs []) xt03_lhs xt03_rhs =
      SyndromeQ0.zero := by
  with_unfolding_all rfl

-- Also verify F-M1P0-R1-02 target-binding block: proof of `pos(x)` cannot discharge `nonZero(y)`!
theorem xt03_misbound_guard_rejected :
    checkGuardProof [UnitSpecQ0.unitless, UnitSpecQ0.unitless] [] [.pos (.bvar 0)]
      (.gPosImpNz (.gActiveMem 0)) (.nonZero (.bvar 1)) = false := by decide

-- XT-04: Γ = [x : Energy (J), y : Torque (N·m)], Ω = [nonZero(x)]
-- `(x / x) * y = x` (iso-dimensional L^2 M T^-2, distinct QuantityKind)
def xt04_ctx : VarCtxQ0 := [UnitSpecQ0.energy, UnitSpecQ0.torque]
def xt04_guards : List GuardQ0 := [.nonZero (.bvar 0)]
def xt04_lhs : ExprQ0 := .binOp .mul (.binOp .div (.bvar 0) (.bvar 0)) (.bvar 1)
def xt04_rhs : ExprQ0 := .bvar 0

theorem xt04_expected_reject_syndrome :
    auditProof xt04_ctx [] xt04_guards (.gprLoweredTapeCert [.gActiveMem 0] []) xt04_lhs xt04_rhs =
      { unitOrKindMismatch := 1 } := by decide

theorem xt04_unprovable_all_certs :
    ∀ cert : ProofCertQ0,
      auditProof xt04_ctx [] xt04_guards cert xt04_lhs xt04_rhs ≠ SyndromeQ0.zero := by
  intro cert haud
  rcases (thm_syndrome_sound cert xt04_ctx [] xt04_guards xt04_lhs xt04_rhs haud).1
    with ⟨u, hu1, hu2⟩
  have h1 : synthUnit xt04_ctx xt04_lhs = some UnitSpecQ0.torque := by decide
  have h2 : synthUnit xt04_ctx xt04_rhs = some UnitSpecQ0.energy := by decide
  rw [h1] at hu1; rw [h2] at hu2
  injection hu1 with e1; injection hu2 with e2
  rw [← e1] at e2
  revert e2; decide

-- XT-05: Γ = [x : Energy (J), y : Torque (N·m)], Ω = []
-- `let z := add x y in (5_1 = 5_1)` (unused binder concealing unit/kind error)
def xt05_ctx : VarCtxQ0 := [UnitSpecQ0.energy, UnitSpecQ0.torque]
def xt05_lhs : ExprQ0 :=
  .letBind (.binOp .add (.bvar 0) (.bvar 1)) (.ratLit 5 UnitSpecQ0.unitless)
def xt05_rhs : ExprQ0 := .ratLit 5 UnitSpecQ0.unitless

theorem xt05_expected_reject_syndrome :
    auditProof xt05_ctx [] [] (.gprLoweredTapeCert [] []) xt05_lhs xt05_rhs =
      { unitOrKindMismatch := 1 } := by decide

theorem xt05_unprovable_all_certs :
    ∀ cert : ProofCertQ0,
      auditProof xt05_ctx [] [] cert xt05_lhs xt05_rhs ≠ SyndromeQ0.zero := by
  intro cert haud
  rcases (thm_syndrome_sound cert xt05_ctx [] [] xt05_lhs xt05_rhs haud).1 with ⟨u, hu1, _⟩
  have hnone : synthUnit xt05_ctx xt05_lhs = none := by decide
  rw [hnone] at hu1
  contradiction

-- XT-06: Shared SSA Wire `w_1 := 1 / (x - 1)` in `(w_+ * w_+) - (w_- * w_-) = 4 * w_1`
-- WITH an unreferenced, statically well-typed dead pole row `row 1 := 1_1 / 0_1`!
def xt06_ctx : VarCtxQ0 := [UnitSpecQ0.unitless]
def xt06_guards : List GuardQ0 :=
  [.nonZero (.binOp .sub (.bvar 0) (.ratLit 1 UnitSpecQ0.unitless))]

def xt06_raw_tape : RawTape := #[
  -- row 0: const 1_1
  .constRat 1 UnitSpecQ0.unitless,
  -- row 1: const 0_1
  .constRat 0 UnitSpecQ0.unitless,
  -- row 2: DEAD ROW `1_1 / 0_1` (statically well-typed, dynamically `none` — outside StrictDeps!)
  .binOp .div 0 1,
  -- row 3: x (`inVar 0`)
  .inVar 0,
  -- row 4: x - 1_1
  .binOp .sub 3 0,
  -- row 5: shared wire `w_1 = 1_1 / (x - 1_1)`
  .binOp .div 0 4,
  -- row 6: `w_+ = w_1 + 1_1`
  .binOp .add 5 0,
  -- row 7: `w_- = w_1 - 1_1`
  .binOp .sub 5 0,
  -- row 8: `w_+ * w_+`
  .binOp .mul 6 6,
  -- row 9: `w_- * w_-`
  .binOp .mul 7 7,
  -- row 10 (LHS root): `(w_+ * w_+) - (w_- * w_-)`
  .binOp .sub 8 9,
  -- row 11: const 4_1
  .constRat 4 UnitSpecQ0.unitless,
  -- row 12 (RHS root): `4_1 * w_1`
  .binOp .mul 11 5
]

def xt06_w1_expr : ExprQ0 :=
  .binOp .div (.ratLit 1 UnitSpecQ0.unitless)
              (.binOp .sub (.bvar 0) (.ratLit 1 UnitSpecQ0.unitless))
def xt06_wplus : ExprQ0 := .binOp .add xt06_w1_expr (.ratLit 1 UnitSpecQ0.unitless)
def xt06_wminus : ExprQ0 := .binOp .sub xt06_w1_expr (.ratLit 1 UnitSpecQ0.unitless)
def xt06_lhs : ExprQ0 := .binOp .sub (.binOp .mul xt06_wplus xt06_wplus)
                                     (.binOp .mul xt06_wminus xt06_wminus)
def xt06_rhs : ExprQ0 := .binOp .mul (.ratLit 4 UnitSpecQ0.unitless) xt06_w1_expr

theorem xt06_expected_pass_raw_ssa_with_dead_row :
    auditProof xt06_ctx [] xt06_guards
      (.gprRawTapeCert xt06_raw_tape 10 12 [.gActiveMem 0] [.gActiveMem 0])
      xt06_lhs xt06_rhs = SyndromeQ0.zero := by
  with_unfolding_all rfl

-- Also verify R3 §4 Trace A (`let y := x_0 + 1_m in y = x_0 + 1_m`)
def traceA_ctx : VarCtxQ0 := [UnitSpecQ0.meter]
def traceA_lhs : ExprQ0 :=
  .letBind (.binOp .add (.bvar 0) (.ratLit 1 UnitSpecQ0.meter)) (.bvar 0)
def traceA_rhs : ExprQ0 :=
  .binOp .add (.bvar 0) (.ratLit 1 UnitSpecQ0.meter)

theorem traceA_commutes_and_passes :
    auditProof traceA_ctx [] [] (.gprLoweredTapeCert [] []) traceA_lhs traceA_rhs =
      SyndromeQ0.zero := by
  with_unfolding_all rfl

-- Verify R3 §4 Trace B (`let y := 1_1 / x_0 in y + y = 2_1 / x_0` under `Ω = [nonZero(x_0)]`)
def traceB_ctx : VarCtxQ0 := [UnitSpecQ0.unitless]
def traceB_guards : List GuardQ0 := [.nonZero (.bvar 0)]
def traceB_lhs : ExprQ0 :=
  .letBind (.binOp .div (.ratLit 1 UnitSpecQ0.unitless) (.bvar 0))
           (.binOp .add (.bvar 0) (.bvar 0))
def traceB_rhs : ExprQ0 :=
  .binOp .div (.ratLit 2 UnitSpecQ0.unitless) (.bvar 0)

theorem traceB_ast_and_ssa_pass :
    auditProof traceB_ctx [] traceB_guards (.gprAstCert [.gActiveMem 0] [.gActiveMem 0])
      traceB_lhs traceB_rhs = SyndromeQ0.zero ∧
    auditProof traceB_ctx [] traceB_guards (.gprLoweredTapeCert [.gActiveMem 0] [.gActiveMem 0])
      traceB_lhs traceB_rhs = SyndromeQ0.zero := by
  constructor <;> with_unfolding_all rfl

-- Verify R3 §4 Trace C (Dead-row `1_1 / 0_1` passes, whereas strict `let y := 1_1 / 0_1 in 5_1 = 5_1` is universally unprovable)
def traceC_dead_tape : RawTape := #[
  .constRat 1 UnitSpecQ0.unitless, -- row 0: 1_1
  .constRat 0 UnitSpecQ0.unitless, -- row 1: 0_1
  .binOp .div 0 1,                 -- row 2: DEAD ROW `1_1 / 0_1`
  .constRat 5 UnitSpecQ0.unitless  -- row 3: 5_1 (root)
]
def traceC_five : ExprQ0 := .ratLit 5 UnitSpecQ0.unitless
def traceC_strict_let_pole : ExprQ0 :=
  .letBind (.binOp .div (.ratLit 1 UnitSpecQ0.unitless) (.ratLit 0 UnitSpecQ0.unitless))
           traceC_five

theorem traceC_dead_row_passes :
    auditProof [] [] [] (.gprRawTapeCert traceC_dead_tape 3 3 [] [])
      traceC_five traceC_five = SyndromeQ0.zero := by
  with_unfolding_all rfl

theorem traceC_strict_let_obstruction :
    checkObstruction [] [] [] [] traceC_strict_let_pole traceC_five = true := by
  with_unfolding_all rfl

theorem traceC_strict_let_unprovable_all_certs :
    ∀ cert : ProofCertQ0,
      auditProof [] [] [] cert traceC_strict_let_pole traceC_five ≠ SyndromeQ0.zero :=
  thm_l05_bipolar traceC_strict_let_obstruction

end AdversarialVectors

end GrandZero.StageA
