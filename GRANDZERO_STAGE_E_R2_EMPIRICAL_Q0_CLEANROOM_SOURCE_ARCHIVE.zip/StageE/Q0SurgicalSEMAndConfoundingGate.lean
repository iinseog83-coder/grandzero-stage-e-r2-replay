/-
  GRANDZERO Ω — Stage E-R2 (Identifiability, Bounded-Error Set-Membership,
                            Surgical SEM Interventions & Conditional Empirical Qualification Gate)
  Module E-3 (R2): Q0SurgicalSEMAndConfoundingGate.lean
  Scope:
    1. Certified Acyclic Linear Structural Equation Models `LinearSEMQ0 d` with explicit
       DAG topological ordering `checkDAGTopologicalOrder`, certified resolvent `S = (I - B)⁻¹`,
       and positive-semidefinite exogenous factor `Ω = L_Ω L_Ωᵀ` (`thm_psd_factor_nonneg_quad`,
       `thm_sem_unique_equilibrium_solution`).
    2. Graph-surgical hard intervention `do(X_i := u)` via `doZeroRow` (`thm_doZeroRow_preserves_DAG`,
       `thm_surgical_do_clamp_response`).
    3. Confounding Observational-vs-Interventional No-Go Theorem (`thm_confounding_twin_obs_eq_do_neq`),
       certifying `Σ_obs(M₁) = Σ_obs(M₂) ∧ InterventionalEffect(M₁) ≠ InterventionalEffect(M₂)`.
    4. Restricted Canonical 3-Node Linear IV (`Tribunal F-E04`, strictly separated from active
       `do`-clamping): `checkCanonicalIV3Assumptions` + `thm_canonical_iv3_wald_identifies_do_effect`,
       proving exact Wald recovery `β = Σ_obs[0,2] / Σ_obs[0,1] = S_do(1)[2,1]`.
    5. Domain-Separated Differential Slope Identification & Universal Offset Refutation (`Tribunal F-E08 Lock 2`):
       - Domain A (`thm_active_do_diff_refutes_all_constant_offsets`): Under `u_{r1} ≠ u_{r2}`,
         `|(y₂ - y₁) - (u₂ - u₁)β| > ε₁ + ε₂` refutes `β` across ALL constant intercepts `∀ b ∈ ℚ` (`d_{0,r} = b`).
       - Domain B (`thm_active_do_calibrated_diff_refutes_all_uniform_drifts`): For general channel-specific
         pre-calibrated offsets `d₀^cal`, stripping `y^corr_r := y^obs_r - d_{0,r}^cal` and verifying
         `|(y^corr₂ - y^corr₁) - (u₂ - u₁)β| > ε₁ + ε₂` refutes `β` across `d₀^cal + b·1` for `∀ b ∈ ℚ`
         (including `b = 0`, i.e., `d₀ = d₀^cal`).
       Epistemic Scope Note (Tribunal §2): These differential refutations are deterministic sufficient
       conditions valid conditionally on the physical validity of the certified error bounds `|e_r| ≤ ε_r`;
       absence of a differential violation does not by itself imply full model validity.
-/

import StageE.Q0BoundedErrorPolytopeAndHoldoutGate

namespace GrandZero.StageE

open GrandZero.StageA
open GrandZero.StageB
open GrandZero.StageC
open GrandZero.StageD

/-! ### Part 1: Certified Acyclic `LinearSEMQ0 d` & PSD Noise Factor `Ω = L_Ω L_Ωᵀ` -/

theorem subMat_vec {m n : Nat} (A B : MatQ0 m n) (x : VecQ0 n) :
    matVec (subMat A B) x = subVec (matVec A x) (matVec B x) := by
  funext i
  unfold matVec subMat subVec
  rw [← finSum_sub]
  apply finSum_ext
  intro j
  grind

theorem dotVec_self_nonneg : ∀ {r : Nat} (z : VecQ0 r), 0 ≤ dotVec z z
  | 0, _ => by simp only [dotVec, finSum]; grind
  | k + 1, z => by
      unfold dotVec
      simp only [finSum]
      have hsq : ∀ a : Rat, 0 ≤ a * a := by
        intro a
        by_cases ha : a = 0
        · subst ha; grind
        · exact Rat.le_of_lt (rat_sq_pos_of_ne_zero ha)
      have h0 := hsq (z ⟨0, Nat.zero_lt_succ k⟩)
      have hrest : 0 ≤ dotVec (fun i : Fin k => z ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩)
                              (fun i : Fin k => z ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩) :=
        dotVec_self_nonneg _
      unfold dotVec at hrest
      grind

/-- Target Theorem `thm_psd_factor_nonneg_quad`:
    Any covariance matrix factored as `Ω = L Lᵀ` satisfies `0 ≤ ⟨v, Ω v⟩` for all `v ∈ ℚ^d`. -/
theorem thm_psd_factor_nonneg_quad {d r : Nat} (L : MatQ0 d r) (v : VecQ0 d) :
    0 ≤ dotVec v (matVec (matMul L (transposeMat L)) v) := by
  rw [matVec_matMul, dotVec_matVec_transpose]
  exact dotVec_self_nonneg (matVec (transposeMat L) v)

/-- Certified finite-dimensional rational Linear Acyclic Structural Equation Model `X = B X + ξ`
    with exogenous second-moment matrix `Ω = Lomega · Lomegaᵀ`. -/
structure LinearSEMQ0 (d : Nat) where
  rNoise : Nat
  B      : MatQ0 d d
  tau    : Fin d → Nat
  S      : MatQ0 d d
  Lomega : MatQ0 d rNoise

namespace LinearSEMQ0

/-- Exogenous noise/confounder covariance `Ω = L_Ω L_Ωᵀ`. -/
def Omega {d : Nat} (M : LinearSEMQ0 d) : MatQ0 d d :=
  matMul M.Lomega (transposeMat M.Lomega)

/-- Passive observational second-moment / covariance matrix `Σ_obs = S Ω Sᵀ`. -/
def SigmaObs {d : Nat} (M : LinearSEMQ0 d) : MatQ0 d d :=
  matMul (matMul M.S M.Omega) (transposeMat M.S)

end LinearSEMQ0

/-- Strict DAG topological ordering check: `B i j ≠ 0 → tau j < tau i`. -/
def checkDAGTopologicalOrder {d : Nat} (B : MatQ0 d d) (tau : Fin d → Nat) : Bool :=
  allFin d fun i =>
    allFin d fun j =>
      if B i j == 0 then true
      else decide (tau j < tau i)

/-- Whitebox structural validity check for `LinearSEMQ0 d`. -/
def checkLinearSEMValid {d : Nat} (M : LinearSEMQ0 d) : Bool :=
  checkDAGTopologicalOrder M.B M.tau &&
  matEqBool (matMul (subMat (idMat d) M.B) M.S) (idMat d) &&
  matEqBool (matMul M.S (subMat (idMat d) M.B)) (idMat d)

/-- Target Theorem `thm_sem_unique_equilibrium_solution`:
    Whenever `checkLinearSEMValid M = true`, for every exogenous vector `ξ ∈ ℚ^d`,
    `X - B X = ξ` has the unique rational solution `X = S ξ`. -/
theorem thm_sem_unique_equilibrium_solution {d : Nat}
    (M : LinearSEMQ0 d) (hM : checkLinearSEMValid M = true)
    (x ξ : VecQ0 d) :
    subVec x (matVec M.B x) = ξ ↔ x = matVec M.S ξ := by
  unfold checkLinearSEMValid at hM
  simp only [Bool.and_eq_true, matEqBool_iff] at hM
  rcases hM with ⟨⟨_, hIBS⟩, hSIB⟩
  have hlhs : subVec x (matVec M.B x) = matVec (subMat (idMat d) M.B) x := by
    rw [subMat_vec, idMat_vec]
  rw [hlhs]
  constructor
  · intro heq
    calc
      x = matVec (idMat d) x := (idMat_vec x).symm
      _ = matVec (matMul M.S (subMat (idMat d) M.B)) x := by rw [hSIB]
      _ = matVec M.S (matVec (subMat (idMat d) M.B) x) := matVec_matMul _ _ _
      _ = matVec M.S ξ := by rw [heq]
  · intro hx
    rw [hx, ← matVec_matMul, hIBS, idMat_vec]

/-! ### Part 2: Surgical `do(X_i := u)` Row-Zeroing Operator (`doZeroRow`) -/

/-- Surgical row-zeroing operator severing all incoming structural/confounder edges into `i`. -/
def doZeroRow {d k : Nat} (A : MatQ0 d k) (i : Fin d) : MatQ0 d k :=
  fun r c => if r = i then 0 else A r c

/-- Target Theorem `thm_doZeroRow_preserves_DAG`:
    Surgical clamping `do(X_i := u)` preserves strict DAG topological ordering. -/
theorem thm_doZeroRow_preserves_DAG {d : Nat} (B : MatQ0 d d) (tau : Fin d → Nat) (i : Fin d)
    (hdag : checkDAGTopologicalOrder B tau = true) :
    checkDAGTopologicalOrder (doZeroRow B i) tau = true := by
  unfold checkDAGTopologicalOrder at hdag ⊢
  rw [allFin_iff] at hdag ⊢
  intro r
  rw [allFin_iff]
  intro c
  have hrc := (allFin_iff d _).mp (hdag r) c
  unfold doZeroRow
  by_cases hri : r = i
  · simp [hri]
  · simp only [if_neg hri]
    exact hrc

/-- Standard basis vector `e_i ∈ ℚ^d`. -/
def unitBasisVec (d : Nat) (i : Fin d) : VecQ0 d :=
  fun r => if r = i then 1 else 0

theorem lem_matVec_scale_unitBasis {d : Nat} (A : MatQ0 d d) (i : Fin d) (u : Rat) :
    matVec A (scaleVec u (unitBasisVec d i)) = fun r => u * A r i := by
  funext r
  unfold matVec scaleVec unitBasisVec
  have heq : (finSum d fun j => A r j * (u * if j = i then (1 : Rat) else 0)) =
      u * finSum d (fun j => A r j * (if j = i then (1 : Rat) else 0)) := by
    rw [finSum_mul_left]
    apply finSum_ext
    intro j
    grind
  rw [heq, finSum_delta_right]

/-- Whitebox surgical `do(X_{iDo} := u)` resolvent certificate. -/
structure SurgicalDoCertQ0 (d : Nat) where
  iDo : Fin d
  Sdo : MatQ0 d d

def checkSurgicalDoCert {d : Nat} (M : LinearSEMQ0 d) (sc : SurgicalDoCertQ0 d) : Bool :=
  checkLinearSEMValid M &&
  matEqBool (matMul (subMat (idMat d) (doZeroRow M.B sc.iDo)) sc.Sdo) (idMat d) &&
  matEqBool (matMul sc.Sdo (subMat (idMat d) (doZeroRow M.B sc.iDo))) (idMat d)

/-- Deterministic unit interventional causal effect of `do(X_{sc.iDo} := 1)` on `X_j`. -/
def interventionalUnitEffect {d : Nat} (sc : SurgicalDoCertQ0 d) (j : Fin d) : Rat :=
  sc.Sdo j sc.iDo

/-- Target Theorem `thm_surgical_do_clamp_response`:
    Under `checkSurgicalDoCert M sc = true`, clamping `X_{sc.iDo} := u` produces the unique
    post-intervention state `x_u = S_do (u · e_{iDo})` satisfying `x_u[sc.iDo] = u` and
    `x_u[j] = u · interventionalUnitEffect sc j`. -/
theorem thm_surgical_do_clamp_response {d : Nat}
    (M : LinearSEMQ0 d) (sc : SurgicalDoCertQ0 d)
    (hsc : checkSurgicalDoCert M sc = true) (u : Rat) :
    let x_u := matVec sc.Sdo (scaleVec u (unitBasisVec d sc.iDo))
    matVec (subMat (idMat d) (doZeroRow M.B sc.iDo)) x_u = scaleVec u (unitBasisVec d sc.iDo) ∧
    x_u sc.iDo = u ∧
    ∀ j : Fin d, x_u j = u * interventionalUnitEffect sc j := by
  unfold checkSurgicalDoCert at hsc
  simp only [Bool.and_eq_true, matEqBool_iff] at hsc
  rcases hsc with ⟨⟨_, hIB_Sdo⟩, _⟩
  dsimp only
  have hsol : matVec (subMat (idMat d) (doZeroRow M.B sc.iDo))
      (matVec sc.Sdo (scaleVec u (unitBasisVec d sc.iDo))) =
        scaleVec u (unitBasisVec d sc.iDo) := by
    rw [← matVec_matMul, hIB_Sdo, idMat_vec]
  have hcoord : ∀ j : Fin d,
      matVec sc.Sdo (scaleVec u (unitBasisVec d sc.iDo)) j = u * interventionalUnitEffect sc j := by
    intro j
    rw [lem_matVec_scale_unitBasis]
    rfl
  have hclamp : matVec sc.Sdo (scaleVec u (unitBasisVec d sc.iDo)) sc.iDo = u := by
    have hrow := congrFun hsol sc.iDo
    rw [subMat_vec, idMat_vec] at hrow
    have hzero_row : matVec (doZeroRow M.B sc.iDo)
        (matVec sc.Sdo (scaleVec u (unitBasisVec d sc.iDo))) sc.iDo = 0 := by
      unfold matVec doZeroRow
      simp only [↓reduceIte]
      rw [finSum_ext (g := fun _ => 0)]
      · exact finSum_zero d
      · intro j; exact Rat.zero_mul _
    dsimp [subVec, scaleVec, unitBasisVec] at hrow
    rw [hzero_row] at hrow
    simp only [↓reduceIte] at hrow
    grind
  exact ⟨hsol, hclamp, hcoord⟩

/-! ### Part 3: Confounding Observational-vs-Interventional No-Go Theorem -/

structure ConfoundingTwinCertQ0 (d : Nat) where
  M1      : LinearSEMQ0 d
  M2      : LinearSEMQ0 d
  sc1     : SurgicalDoCertQ0 d
  sc2     : SurgicalDoCertQ0 d
  iCause  : Fin d
  jTarget : Fin d

def checkConfoundingTwinCert {d : Nat} (tc : ConfoundingTwinCertQ0 d) : Bool :=
  decide (tc.sc1.iDo = tc.iCause) &&
  decide (tc.sc2.iDo = tc.iCause) &&
  checkSurgicalDoCert tc.M1 tc.sc1 &&
  checkSurgicalDoCert tc.M2 tc.sc2 &&
  matEqBool tc.M1.SigmaObs tc.M2.SigmaObs &&
  decide (interventionalUnitEffect tc.sc1 tc.jTarget ≠ interventionalUnitEffect tc.sc2 tc.jTarget)

/-- Target Theorem `thm_confounding_twin_obs_eq_do_neq`:
    Certifies two valid acyclic PSD-noise structural models `M₁, M₂` that generate
    IDENTICAL passive observational covariance `Σ_obs(M₁) = Σ_obs(M₂)` while exhibiting
    STRICTLY DIFFERENT interventional effects under `do(X_{iCause} := 1)`. -/
theorem thm_confounding_twin_obs_eq_do_neq {d : Nat}
    (tc : ConfoundingTwinCertQ0 d)
    (hchk : checkConfoundingTwinCert tc = true) :
    checkSurgicalDoCert tc.M1 tc.sc1 = true ∧
    checkSurgicalDoCert tc.M2 tc.sc2 = true ∧
    tc.M1.SigmaObs = tc.M2.SigmaObs ∧
    interventionalUnitEffect tc.sc1 tc.jTarget ≠ interventionalUnitEffect tc.sc2 tc.jTarget := by
  unfold checkConfoundingTwinCert at hchk
  simp only [Bool.and_eq_true, decide_eq_true_eq, matEqBool_iff] at hchk
  exact ⟨hchk.1.1.1.2, hchk.1.1.2, hchk.1.2, hchk.2⟩

/-! ### Part 4: Restricted Canonical 3-Node Linear IV (`Tribunal F-E04`) -/

def ivIdx0 : Fin 3 := ⟨0, by decide⟩
def ivIdx1 : Fin 3 := ⟨1, by decide⟩
def ivIdx2 : Fin 3 := ⟨2, by decide⟩

theorem finSum_three (f : Fin 3 → Rat) :
    finSum 3 f = f ivIdx0 + f ivIdx1 + f ivIdx2 := by
  simp only [finSum]
  change f ivIdx0 + (f ivIdx1 + (f ivIdx2 + 0)) = f ivIdx0 + f ivIdx1 + f ivIdx2
  grind

/-- Explicit 4-part hypothesis checker for the Restricted Canonical 3-Node Linear IV System
    `(Z, X, Y) = (0, 1, 2)` (`Tribunal F-E04`):
      1. Canonical triangular 3-node support (`B[0,*] = 0`, `B[1,1] = B[1,2] = 0`, `B[2,2] = 0`),
      2. Exclusion restriction `B[2,0] = 0` (`Z ↛ Y` directly; no 4th mediator exists in `d = 3`),
      3. Instrument-outcome error orthogonality `Ω[0,2] = 0` (`Cov(ξ_Z, ξ_Y) = 0`, allowing `Ω[1,2] ≠ 0`),
      4. Non-zero instrument relevance `Σ_obs[0,1] ≠ 0` (`Cov(Z, X) ≠ 0`). -/
def checkCanonicalIV3Assumptions (M : LinearSEMQ0 3) (sc1 : SurgicalDoCertQ0 3) : Bool :=
  decide (sc1.iDo = ivIdx1) &&
  checkSurgicalDoCert M sc1 &&
  (M.B ivIdx0 ivIdx0 == 0) && (M.B ivIdx0 ivIdx1 == 0) && (M.B ivIdx0 ivIdx2 == 0) &&
  (M.B ivIdx1 ivIdx1 == 0) && (M.B ivIdx1 ivIdx2 == 0) && (M.B ivIdx2 ivIdx2 == 0) &&
  (M.B ivIdx2 ivIdx0 == 0) &&
  (M.Omega ivIdx0 ivIdx2 == 0) &&
  decide (M.SigmaObs ivIdx0 ivIdx1 ≠ 0)

/-- Target Theorem `thm_canonical_iv3_wald_identifies_do_effect` (`Tribunal F-E04`):
    Under `checkCanonicalIV3Assumptions M sc1 = true`, despite arbitrary latent confounding
    `Ω[1,2] = Cov(ξ_X, ξ_Y)`, the observational moments satisfy `Σ_obs[0,2] = β · Σ_obs[0,1]`
    and the Wald ratio `Σ_obs[0,2] / Σ_obs[0,1]` equals the exact surgical `do(X := 1)`
    causal effect `interventionalUnitEffect sc1 ivIdx2 = B[2,1]`. -/
theorem thm_canonical_iv3_wald_identifies_do_effect
    (M : LinearSEMQ0 3) (sc1 : SurgicalDoCertQ0 3)
    (hiv : checkCanonicalIV3Assumptions M sc1 = true) :
    M.SigmaObs ivIdx0 ivIdx1 ≠ 0 ∧
    interventionalUnitEffect sc1 ivIdx2 = M.B ivIdx2 ivIdx1 ∧
    M.SigmaObs ivIdx0 ivIdx2 = M.B ivIdx2 ivIdx1 * M.SigmaObs ivIdx0 ivIdx1 ∧
    M.SigmaObs ivIdx0 ivIdx2 / M.SigmaObs ivIdx0 ivIdx1 = interventionalUnitEffect sc1 ivIdx2 := by
  unfold checkCanonicalIV3Assumptions at hiv
  simp only [Bool.and_eq_true, decide_eq_true_eq, beq_iff_eq] at hiv
  rcases hiv with ⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨hido, hsc⟩, hb00⟩, hb01⟩, hb02⟩, hb11⟩, hb12⟩, hb22⟩, hb20⟩, hom02⟩, hrel⟩
  have hsc_raw := hsc
  unfold checkSurgicalDoCert checkLinearSEMValid at hsc_raw
  simp only [Bool.and_eq_true, matEqBool_iff] at hsc_raw
  rcases hsc_raw with ⟨⟨⟨⟨_, hIBS⟩, _⟩, hIBdo_Sdo⟩, _⟩
  have entry_IBS : ∀ (r c : Fin 3),
      (subMat (idMat 3) M.B r ivIdx0) * M.S ivIdx0 c +
      (subMat (idMat 3) M.B r ivIdx1) * M.S ivIdx1 c +
      (subMat (idMat 3) M.B r ivIdx2) * M.S ivIdx2 c = idMat 3 r c := by
    intro r c
    have h := congrFun (congrFun hIBS r) c
    dsimp [matMul] at h
    rw [finSum_three] at h
    grind
  have hs00 : M.S ivIdx0 ivIdx0 = 1 := by
    have h := entry_IBS ivIdx0 ivIdx0
    dsimp [subMat, idMat, ivIdx0, ivIdx1, ivIdx2] at h hb00 hb01 hb02 ⊢
    grind
  have hs01 : M.S ivIdx0 ivIdx1 = 0 := by
    have h := entry_IBS ivIdx0 ivIdx1
    dsimp [subMat, idMat, ivIdx0, ivIdx1, ivIdx2] at h hb00 hb01 hb02 ⊢
    grind
  have hs02 : M.S ivIdx0 ivIdx2 = 0 := by
    have h := entry_IBS ivIdx0 ivIdx2
    dsimp [subMat, idMat, ivIdx0, ivIdx1, ivIdx2] at h hb00 hb01 hb02 ⊢
    grind
  have hs10 : M.S ivIdx1 ivIdx0 = M.B ivIdx1 ivIdx0 := by
    have h := entry_IBS ivIdx1 ivIdx0
    dsimp [subMat, idMat, ivIdx0, ivIdx1, ivIdx2] at h hb11 hb12 hs00 ⊢
    grind
  have hs11 : M.S ivIdx1 ivIdx1 = 1 := by
    have h := entry_IBS ivIdx1 ivIdx1
    dsimp [subMat, idMat, ivIdx0, ivIdx1, ivIdx2] at h hb11 hb12 hs01 ⊢
    grind
  have hs12 : M.S ivIdx1 ivIdx2 = 0 := by
    have h := entry_IBS ivIdx1 ivIdx2
    dsimp [subMat, idMat, ivIdx0, ivIdx1, ivIdx2] at h hb11 hb12 hs02 ⊢
    grind
  have hs20 : M.S ivIdx2 ivIdx0 = M.B ivIdx2 ivIdx1 * M.B ivIdx1 ivIdx0 := by
    have h := entry_IBS ivIdx2 ivIdx0
    dsimp [subMat, idMat, ivIdx0, ivIdx1, ivIdx2] at h hb20 hb22 hs00 hs10 ⊢
    grind
  have hs21 : M.S ivIdx2 ivIdx1 = M.B ivIdx2 ivIdx1 := by
    have h := entry_IBS ivIdx2 ivIdx1
    dsimp [subMat, idMat, ivIdx0, ivIdx1, ivIdx2] at h hb20 hb22 hs01 hs11 ⊢
    grind
  have hs22 : M.S ivIdx2 ivIdx2 = 1 := by
    have h := entry_IBS ivIdx2 ivIdx2
    dsimp [subMat, idMat, ivIdx0, ivIdx1, ivIdx2] at h hb20 hb22 hs02 hs12 ⊢
    grind
  have entry_IBdo : ∀ (r : Fin 3),
      (subMat (idMat 3) (doZeroRow M.B sc1.iDo) r ivIdx0) * sc1.Sdo ivIdx0 ivIdx1 +
      (subMat (idMat 3) (doZeroRow M.B sc1.iDo) r ivIdx1) * sc1.Sdo ivIdx1 ivIdx1 +
      (subMat (idMat 3) (doZeroRow M.B sc1.iDo) r ivIdx2) * sc1.Sdo ivIdx2 ivIdx1 =
        idMat 3 r ivIdx1 := by
    intro r
    have h := congrFun (congrFun hIBdo_Sdo r) ivIdx1
    dsimp [matMul] at h
    rw [finSum_three] at h
    grind
  have hsdo11 : sc1.Sdo ivIdx1 ivIdx1 = 1 := by
    have h := entry_IBdo ivIdx1
    rw [hido] at h
    dsimp [subMat, idMat, doZeroRow, ivIdx0, ivIdx1, ivIdx2] at h ⊢
    grind
  have hsdo21 : sc1.Sdo ivIdx2 ivIdx1 = M.B ivIdx2 ivIdx1 := by
    have h := entry_IBdo ivIdx2
    rw [hido] at h
    dsimp [subMat, idMat, doZeroRow, ivIdx0, ivIdx1, ivIdx2] at h hb20 hb22 hsdo11 ⊢
    grind
  have hdo_eq : interventionalUnitEffect sc1 ivIdx2 = M.B ivIdx2 ivIdx1 := by
    unfold interventionalUnitEffect
    rw [hido]
    exact hsdo21
  have hSO0 : ∀ k : Fin 3, matMul M.S M.Omega ivIdx0 k = M.Omega ivIdx0 k := by
    intro k
    dsimp [matMul]
    rw [finSum_three, hs00, hs01, hs02]
    grind
  have hsig01 : M.SigmaObs ivIdx0 ivIdx1 =
      M.Omega ivIdx0 ivIdx0 * M.B ivIdx1 ivIdx0 + M.Omega ivIdx0 ivIdx1 := by
    change finSum 3 (fun s => matMul M.S M.Omega ivIdx0 s * M.S ivIdx1 s) =
      M.Omega ivIdx0 ivIdx0 * M.B ivIdx1 ivIdx0 + M.Omega ivIdx0 ivIdx1
    rw [finSum_three, hSO0 ivIdx0, hSO0 ivIdx1, hSO0 ivIdx2, hs10, hs11, hs12]
    grind
  have hsig02 : M.SigmaObs ivIdx0 ivIdx2 =
      M.B ivIdx2 ivIdx1 * M.SigmaObs ivIdx0 ivIdx1 := by
    rw [hsig01]
    change finSum 3 (fun s => matMul M.S M.Omega ivIdx0 s * M.S ivIdx2 s) =
      M.B ivIdx2 ivIdx1 * (M.Omega ivIdx0 ivIdx0 * M.B ivIdx1 ivIdx0 + M.Omega ivIdx0 ivIdx1)
    rw [finSum_three, hSO0 ivIdx0, hSO0 ivIdx1, hSO0 ivIdx2, hs20, hs21, hs22, hom02]
    grind
  have hdiv : M.SigmaObs ivIdx0 ivIdx2 / M.SigmaObs ivIdx0 ivIdx1 =
      interventionalUnitEffect sc1 ivIdx2 := by
    rw [hsig02, hdo_eq]
    grind
  exact ⟨hrel, hdo_eq, hsig02, hdiv⟩

/-! ### Part 5: Domain-Separated Differential Slope Identification & `∀ b ∈ ℚ` Refutation (`Tribunal F-E08 Lock 2`) -/

/-- Exact rational absolute value `|x| ∈ ℚ` (`0` external dependencies). -/
def ratAbs (x : Rat) : Rat :=
  if 0 ≤ x then x else -x

def finZeroOfP1 (D : AffineObservationDesignQ0) (hp : D.p = 1) : Fin D.p :=
  ⟨0, by change 0 < D.p; omega⟩

def finZeroOfM1 (D : AffineObservationDesignQ0) (hm : D.m = 1) : Fin D.m :=
  ⟨0, by change 0 < D.m; omega⟩

theorem lem_matVec_one_col {m p : Nat} (Phi : MatQ0 m p) (hp : p = 1)
    (j0 : Fin p) (β : Rat) (r : Fin m) :
    matVec Phi (fun _ => β) r = Phi r j0 * β := by
  subst hp
  have hj0 : j0 = ⟨0, by decide⟩ := by
    apply Fin.ext
    have := j0.isLt
    omega
  subst hj0
  unfold matVec
  simp only [finSum]
  exact Rat.add_zero _

/-- Domain A (`Tribunal F-E08 Lock 2A`):
    1-parameter clamp design equipped with an arbitrary uniform constant baseline intercept `d_{0,r} = b`. -/
def constOffsetDesign (D : AffineObservationDesignQ0) (b : Rat) : AffineObservationDesignQ0 :=
  { D with d0 := fun _ => b }

/-- Domain B (`Tribunal F-E08 Lock 2B`):
    1-parameter clamp design equipped with TCB-attested channel-specific pre-calibrated offsets `d₀^cal`
    plus an arbitrary unknown uniform baseline drift `b ∈ ℚ` (`d_{0,r} = d_{0,r}^cal + b`). -/
def shiftedCalibratedDesign (D : AffineObservationDesignQ0) (d0Cal : VecQ0 D.m) (b : Rat) :
    AffineObservationDesignQ0 :=
  { D with d0 := fun r => d0Cal r + b }

/-- Computable differential violation check for Uniform Constant-Intercept Domain A (`F-E08 Lock 2A`):
    Verifies distinct clamp levels `u_{r1} ≠ u_{r2}` AND `|(y₂ - y₁) - (u₂ - u₁)β| > ε₁ + ε₂`. -/
def checkConstantOffsetDiffRefutation
    (D : AffineObservationDesignQ0) (hp : D.p = 1)
    (r1 r2 : Fin D.m) (yObs eps : VecQ0 D.m) (β : Rat) : Bool :=
  let j0 := finZeroOfP1 D hp
  let u1 := D.Phi r1 j0
  let u2 := D.Phi r2 j0
  decide (u1 ≠ u2) &&
  decide (eps r1 + eps r2 < ratAbs ((yObs r2 - yObs r1) - (u2 - u1) * β))

/-- Computable calibrated-offset-stripped differential violation check for Domain B (`F-E08 Lock 2B`):
    First strips TCB-attested channel offsets `y^corr_r := y^obs_r - d_{0,r}^cal`, then verifies
    distinct clamp levels `u_{r1} ≠ u_{r2}` AND `|(y^corr₂ - y^corr₁) - (u₂ - u₁)β| > ε₁ + ε₂`. -/
def checkCalibratedOffsetDiffRefutation
    (D : AffineObservationDesignQ0) (hp : D.p = 1)
    (r1 r2 : Fin D.m) (d0Cal yObs eps : VecQ0 D.m) (β : Rat) : Bool :=
  let j0 := finZeroOfP1 D hp
  let u1 := D.Phi r1 j0
  let u2 := D.Phi r2 j0
  let yCorr1 := yObs r1 - d0Cal r1
  let yCorr2 := yObs r2 - d0Cal r2
  decide (u1 ≠ u2) &&
  decide (eps r1 + eps r2 < ratAbs ((yCorr2 - yCorr1) - (u2 - u1) * β))

/-- Target Theorem `thm_active_do_diff_refutes_all_constant_offsets` (`Tribunal F-E08 Lock 2A`):
    In the Uniform Constant-Intercept Domain (`d_{0,r} = b`), whenever two distinct surgical clamp
    levels `u_{r1} ≠ u_{r2}` satisfy `|(y₂ - y₁) - (u₂ - u₁)β| > ε₁ + ε₂`, the candidate causal slope
    `β` violates BOTH `InResidualEnvelope` and `InFeasibleParameterSet` universally across ALL
    common constant offsets `∀ b ∈ ℚ`.
    (Deterministic sufficient condition for refutation conditional on `|e_r| ≤ ε_r`.) -/
theorem thm_active_do_diff_refutes_all_constant_offsets
    (D : AffineObservationDesignQ0) (hp : D.p = 1)
    (r1 r2 : Fin D.m) (yObs eps : VecQ0 D.m) (β : Rat)
    (href : checkConstantOffsetDiffRefutation D hp r1 r2 yObs eps β = true) :
    D.Phi r1 (finZeroOfP1 D hp) ≠ D.Phi r2 (finZeroOfP1 D hp) ∧
    ∀ b : Rat,
      ¬ InResidualEnvelope (constOffsetDesign D b) yObs eps (fun _ => β) ∧
      ¬ InFeasibleParameterSet (constOffsetDesign D b) yObs eps (fun _ => β) := by
  unfold checkConstantOffsetDiffRefutation at href
  dsimp only at href
  simp only [Bool.and_eq_true, decide_eq_true_eq] at href
  rcases href with ⟨hu_ne, hgt⟩
  refine ⟨hu_ne, fun b => ?_⟩
  have hnot_env : ¬ InResidualEnvelope (constOffsetDesign D b) yObs eps (fun _ => β) := by
    intro henv
    have h1 := henv r1
    have h2 := henv r2
    dsimp [constOffsetDesign, AffineObservationDesignQ0.predict, addVec] at h1 h2
    have hm1 := lem_matVec_one_col D.Phi hp (finZeroOfP1 D hp) β r1
    have hm2 := lem_matVec_one_col D.Phi hp (finZeroOfP1 D hp) β r2
    rw [hm1] at h1
    rw [hm2] at h2
    unfold ratAbs at hgt
    by_cases hnonneg :
        0 ≤ (yObs r2 - yObs r1) -
            (D.Phi r2 (finZeroOfP1 D hp) - D.Phi r1 (finZeroOfP1 D hp)) * β
    · simp only [hnonneg, ↓reduceIte] at hgt
      rcases h1 with ⟨h1a, _⟩
      rcases h2 with ⟨_, h2b⟩
      grind
    · simp only [hnonneg, ↓reduceIte] at hgt
      rcases h1 with ⟨_, h1b⟩
      rcases h2 with ⟨h2a, _⟩
      grind
  exact ⟨hnot_env, fun hfeas => hnot_env hfeas.2⟩

/-- Target Theorem `thm_active_do_calibrated_diff_refutes_all_uniform_drifts` (`Tribunal F-E08 Lock 2B`):
    In the General Channel-Calibrated Domain (`d₀^cal ∈ ℚ^m`), after stripping the pre-committed
    calibrated offsets (`y^corr_r := y^obs_r - d_{0,r}^cal`), whenever two distinct surgical clamp
    levels `u_{r1} ≠ u_{r2}` satisfy `|(y^corr₂ - y^corr₁) - (u₂ - u₁)β| > ε₁ + ε₂`, the candidate
    causal slope `β` violates `InResidualEnvelope` and `InFeasibleParameterSet` across `d₀^cal + b·1`
    for ALL residual uniform drifts `∀ b ∈ ℚ` (and in particular at `b = 0`, i.e., `D.d0 = d₀^cal`). -/
theorem thm_active_do_calibrated_diff_refutes_all_uniform_drifts
    (D : AffineObservationDesignQ0) (hp : D.p = 1)
    (r1 r2 : Fin D.m) (d0Cal yObs eps : VecQ0 D.m) (β : Rat)
    (href : checkCalibratedOffsetDiffRefutation D hp r1 r2 d0Cal yObs eps β = true) :
    D.Phi r1 (finZeroOfP1 D hp) ≠ D.Phi r2 (finZeroOfP1 D hp) ∧
    (∀ b : Rat,
      ¬ InResidualEnvelope (shiftedCalibratedDesign D d0Cal b) yObs eps (fun _ => β) ∧
      ¬ InFeasibleParameterSet (shiftedCalibratedDesign D d0Cal b) yObs eps (fun _ => β)) ∧
    (D.d0 = d0Cal →
      ¬ InResidualEnvelope D yObs eps (fun _ => β) ∧
      ¬ InFeasibleParameterSet D yObs eps (fun _ => β)) := by
  unfold checkCalibratedOffsetDiffRefutation at href
  dsimp only at href
  simp only [Bool.and_eq_true, decide_eq_true_eq] at href
  rcases href with ⟨hu_ne, hgt⟩
  have hall : ∀ b : Rat,
      ¬ InResidualEnvelope (shiftedCalibratedDesign D d0Cal b) yObs eps (fun _ => β) := by
    intro b henv
    have h1 := henv r1
    have h2 := henv r2
    dsimp [shiftedCalibratedDesign, AffineObservationDesignQ0.predict, addVec] at h1 h2
    have hm1 := lem_matVec_one_col D.Phi hp (finZeroOfP1 D hp) β r1
    have hm2 := lem_matVec_one_col D.Phi hp (finZeroOfP1 D hp) β r2
    rw [hm1] at h1
    rw [hm2] at h2
    unfold ratAbs at hgt
    by_cases hnonneg :
        0 ≤ ((yObs r2 - d0Cal r2) - (yObs r1 - d0Cal r1)) -
            (D.Phi r2 (finZeroOfP1 D hp) - D.Phi r1 (finZeroOfP1 D hp)) * β
    · simp only [hnonneg, ↓reduceIte] at hgt
      rcases h1 with ⟨h1a, _⟩
      rcases h2 with ⟨_, h2b⟩
      grind
    · simp only [hnonneg, ↓reduceIte] at hgt
      rcases h1 with ⟨_, h1b⟩
      rcases h2 with ⟨h2a, _⟩
      grind
  refine ⟨hu_ne, fun b => ⟨hall b, fun hfeas => hall b hfeas.2⟩, ?_⟩
  intro hd0
  have hnot0 : ¬ InResidualEnvelope D yObs eps (fun _ => β) := by
    intro henv
    apply hall 0
    intro r
    have hr := henv r
    dsimp [shiftedCalibratedDesign, AffineObservationDesignQ0.predict, addVec] at hr ⊢
    rw [hd0] at hr
    have hz : d0Cal r + 0 = d0Cal r := Rat.add_zero (d0Cal r)
    rw [hz]
    exact hr
  exact ⟨hnot0, fun hfeas => hnot0 hfeas.2⟩

end GrandZero.StageE
