/-
  GRANDZERO Ω — Stage E-R2 (Identifiability, Bounded-Error Set-Membership,
                            Surgical SEM Interventions & Conditional Empirical Qualification Gate)
  Module E-4 (R2): Q0ConditionalEmpiricalQualificationGate.lean
  Scope:
    1. Detached External Provenance & Pre-Committed Calibration Cut (`Tribunal F-E05, F-E06 & F-E08 Lock 1`):
       - Separates untrusted `EmpiricalDatasetAnchorQ0` from evaluator-TCB `ExternalEmpiricalTrustCtxQ0`,
         binding experiment/dataset ID, payload SHA-256, calibration certificate ID, pre-committed
         calibration SHA-256 (`d0CalibrationSha256Hex`), strict pre-observation sequence order
         (`calSeq < obsSeq`), `ExperimentRegimeSpecQ0`, `obsVars`, `d0Calibrated`, `yObs`, and `eps`.
       - Epistemic Scope Note (Tribunal §2): Inside Lean, `calSeq < obsSeq` is a formal comparison on
         attested record indices and `isLowerSha256Hex` checks syntactic hash format + record equality;
         physical pre-measurement timing and raw file pre-image hashing are explicit external TCB obligations.
    2. Unconditional Positive Qualification Provenance & `(1, 1, 0)` Gate (`Tribunal F-E06` + `F-E08 Lock 1`):
       - Every positive empirical qualification outcome (`.verifiedConditionallyEmpiricallyQualified`,
         `.verifiedQueryConditionallyQualified`, `.verifiedActiveDoConditionallyQualified`,
         `.verifiedCanonicalIVConditionallyQualified`) unconditionally enforces
         `checkEmpiricalQualificationProvenance tcb S = true` (`verifyExternalProvenance`, `d0 == d0Calibrated`,
         holdout provenance/offset binding, and `claimedAuth = (1, 1, 0)`).
    3. Active Surgical `do` & Canonical 3-Node IV Data-to-SEM Binding (`Tribunal F-E07` + `F-E08 Lock 2`):
       - Dedicated `.verifiedActiveDoConditionallyQualified` enforces `activeSurgicalClamp` protocol match,
         exact clamp schedule `Φ[r,0] = u_r`, two distinct clamp levels `u_{r1} ≠ u_{r2}`, `rc.k = 0`,
         and direct `θ_SEM ∈ Θ_feas` membership.
       - `canonicalRestrictedIV3` enforces `passiveObservational`, centered zero-offset `d₀ = 0`,
         exact first-stage covariance `Φ[0,0] = Σ_obs[0,1]`, and `θ_IV ∈ Θ_feas`.
    4. Master Soundness & Mutual-Exclusion Theorems (`0 sorry`, `0 admit`, `0 custom axiom`).
-/

import StageE.Q0SurgicalSEMAndConfoundingGate

namespace GrandZero.StageE

open GrandZero.StageA
open GrandZero.StageB
open GrandZero.StageC
open GrandZero.StageD

/-! ### Part 1: Detached External Provenance, Regime Protocol, & Pre-Committed Offset Cut (`F-E05 ~ F-E08`) -/

inductive DataOriginTagQ0 where
  | externalCalibratedMeasurement
  | syntheticSimulation
  | unverifiedOrigin
  deriving DecidableEq, Repr, Inhabited

/-- Protocol-level experimental regime specification bound inside TCB records (`Tribunal F-E07`). -/
inductive ExperimentRegimeSpecQ0 where
  | passiveObservational
  | activeSurgicalClamp
      (iClamp      : Nat)
      (jTarget     : Nat)
      (clampLevels : List Rat)
  deriving DecidableEq, Repr, Inhabited

/-- Untrusted proposer's empirical dataset & pre-calibration anchor (`Origin & Calibration Claim`). -/
structure EmpiricalDatasetAnchorQ0 (m : Nat) where
  claimedOrigin          : DataOriginTagQ0
  datasetId              : String
  payloadSha256Hex       : String
  calibrationCertId      : String
  d0CalibrationSha256Hex : String
  calSeq                 : Nat
  obsSeq                 : Nat
  attesterId             : String
  regimeSpec             : ExperimentRegimeSpecQ0
  obsVars                : VarCtxQ0
  d0Calibrated           : VecQ0 m
  yObs                   : VecQ0 m
  eps                    : VecQ0 m

/-- Independently attested dataset & pre-calibration record inside evaluator TCB (`F-E05 ~ F-E08 Lock 1`). -/
structure AttestedDatasetRecordQ0 where
  datasetId              : String
  payloadSha256Hex       : String
  calibrationCertId      : String
  d0CalibrationSha256Hex : String
  calSeq                 : Nat
  obsSeq                 : Nat
  attesterId             : String
  regimeSpec             : ExperimentRegimeSpecQ0
  obsVars                : VarCtxQ0
  d0CalibratedList       : List Rat
  yObsList               : List Rat
  epsList                : List Rat
  deriving DecidableEq, Repr, Inhabited

/-- Evaluator TCB's external provenance & formal-baseline trust context. -/
structure ExternalEmpiricalTrustCtxQ0 where
  sysModelAuth    : AuthorityVecQ0
  attestedRecords : List AttestedDatasetRecordQ0
  deriving DecidableEq, Repr, Inhabited

def isLowerHexChar (c : Char) : Bool :=
  ('0' ≤ c && c ≤ '9') || ('a' ≤ c && c ≤ 'f')

def isLowerSha256Hex (s : String) : Bool :=
  decide (s.length = 64) && s.toList.all isLowerHexChar

/-- Exact 12-field verbatim match between `anc` and a TCB `AttestedDatasetRecordQ0` (`F-E05 ~ F-E08 Lock 1`). -/
def recordMatchesAnchor {m : Nat} (anc : EmpiricalDatasetAnchorQ0 m)
    (rec : AttestedDatasetRecordQ0) : Bool :=
  decide (anc.datasetId = rec.datasetId) &&
  decide (anc.payloadSha256Hex = rec.payloadSha256Hex) &&
  decide (anc.calibrationCertId = rec.calibrationCertId) &&
  decide (anc.d0CalibrationSha256Hex = rec.d0CalibrationSha256Hex) &&
  decide (anc.calSeq = rec.calSeq) &&
  decide (anc.obsSeq = rec.obsSeq) &&
  decide (anc.attesterId = rec.attesterId) &&
  decide (anc.regimeSpec = rec.regimeSpec) &&
  decide (anc.obsVars = rec.obsVars) &&
  decide (vecToList anc.d0Calibrated = rec.d0CalibratedList) &&
  decide (vecToList anc.yObs = rec.yObsList) &&
  decide (vecToList anc.eps = rec.epsList)

/-- Computable TCB provenance & pre-committed calibration check (`F-E05, F-E06 & F-E08 Lock 1`):
    Verifies external calibrated origin, non-empty identifiers, 64-hex payload & calibration hashes,
    strict pre-observation sequence precedence `calSeq < obsSeq`, and verbatim TCB record match. -/
def verifyExternalProvenance {m : Nat}
    (tcb : ExternalEmpiricalTrustCtxQ0) (anc : EmpiricalDatasetAnchorQ0 m) : Bool :=
  decide (anc.claimedOrigin = .externalCalibratedMeasurement) &&
  decide (anc.datasetId ≠ "") &&
  decide (anc.calibrationCertId ≠ "") &&
  decide (anc.attesterId ≠ "") &&
  isLowerSha256Hex anc.payloadSha256Hex &&
  isLowerSha256Hex anc.d0CalibrationSha256Hex &&
  decide (anc.calSeq < anc.obsSeq) &&
  tcb.attestedRecords.any (recordMatchesAnchor anc)

def effectiveEmpiricalAuth {m : Nat}
    (tcb : ExternalEmpiricalTrustCtxQ0) (anc : EmpiricalDatasetAnchorQ0 m) : Nat :=
  if verifyExternalProvenance tcb anc then 1 else 0

/-- Maximum authority ceiling conditionally achievable by coupling `modelAuth` with `anc`
    under `tcb : ExternalEmpiricalTrustCtxQ0` (`institutional := 0` identically!). -/
def maxConditionallyQualifiedAuth {m : Nat}
    (tcb : ExternalEmpiricalTrustCtxQ0) (modelAuth : AuthorityVecQ0)
    (anc : EmpiricalDatasetAnchorQ0 m) : AuthorityVecQ0 :=
  { formal        := Nat.min 1 modelAuth.formal
    empirical     := effectiveEmpiricalAuth tcb anc
    institutional := 0 }

/-- Target Theorem `thm_unattested_origin_cannot_mint_empirical_auth` (`Tribunal F-E05`):
    Whenever `verifyExternalProvenance tcb anc = false`, `effectiveEmpiricalAuth = 0`
    and NO `claimedAuth` with `empirical ≥ 1` can pass `checkAuthorityLe`. -/
theorem thm_unattested_origin_cannot_mint_empirical_auth {m : Nat}
    (tcb : ExternalEmpiricalTrustCtxQ0) (modelAuth claimedAuth : AuthorityVecQ0)
    (anc : EmpiricalDatasetAnchorQ0 m)
    (hunatt : verifyExternalProvenance tcb anc = false) :
    effectiveEmpiricalAuth tcb anc = 0 ∧
    (maxConditionallyQualifiedAuth tcb modelAuth anc).empirical = 0 ∧
    (1 ≤ claimedAuth.empirical →
      checkAuthorityLe claimedAuth (maxConditionallyQualifiedAuth tcb modelAuth anc) = false) := by
  have heff : effectiveEmpiricalAuth tcb anc = 0 := by
    unfold effectiveEmpiricalAuth
    simp [hunatt]
  refine ⟨heff, heff, ?_⟩
  intro hemp1
  cases hle : checkAuthorityLe claimedAuth (maxConditionallyQualifiedAuth tcb modelAuth anc) with
  | false => rfl
  | true =>
      have hprop := (lem_checkAuthorityLe_iff _ _).mp hle
      have h2 := hprop.2.1
      dsimp [maxConditionallyQualifiedAuth] at h2
      rw [heff] at h2
      omega

/-- Target Theorem `thm_synthetic_origin_always_zero_empirical`:
    Any dataset whose `claimedOrigin ≠ .externalCalibratedMeasurement` (such as
    `syntheticSimulation`) ALWAYS receives `effectiveEmpiricalAuth = 0`. -/
theorem thm_synthetic_origin_always_zero_empirical {m : Nat}
    (tcb : ExternalEmpiricalTrustCtxQ0) (anc : EmpiricalDatasetAnchorQ0 m)
    (hsyn : anc.claimedOrigin ≠ .externalCalibratedMeasurement) :
    verifyExternalProvenance tcb anc = false ∧
    effectiveEmpiricalAuth tcb anc = 0 := by
  have hv : verifyExternalProvenance tcb anc = false := by
    unfold verifyExternalProvenance
    simp [hsyn]
  exact ⟨hv, by unfold effectiveEmpiricalAuth; simp [hv]⟩

/-- Target Theorem `thm_posthoc_calibration_always_zero_empirical` (`Tribunal F-E08 Lock 1`):
    Any anchor whose calibration commitment sequence does NOT strictly precede observation
    (`¬ (anc.calSeq < anc.obsSeq)`) ALWAYS fails `verifyExternalProvenance` and yields `a_E = 0`. -/
theorem thm_posthoc_calibration_always_zero_empirical {m : Nat}
    (tcb : ExternalEmpiricalTrustCtxQ0) (anc : EmpiricalDatasetAnchorQ0 m)
    (hpost : ¬ (anc.calSeq < anc.obsSeq)) :
    verifyExternalProvenance tcb anc = false ∧
    effectiveEmpiricalAuth tcb anc = 0 := by
  have hv : verifyExternalProvenance tcb anc = false := by
    unfold verifyExternalProvenance
    simp [hpost]
  exact ⟨hv, by unfold effectiveEmpiricalAuth; simp [hv]⟩

/-- Target Theorem `thm_stageE_institutional_firewall_zero`:
    Across ALL `tcb`, `modelAuth`, and `anc`, `maxConditionallyQualifiedAuth.institutional = 0`,
    so NO combination of formal proofs and empirical datasets can ever grant `institutional ≥ 1`. -/
theorem thm_stageE_institutional_firewall_zero {m : Nat}
    (tcb : ExternalEmpiricalTrustCtxQ0) (modelAuth claimedAuth : AuthorityVecQ0)
    (anc : EmpiricalDatasetAnchorQ0 m) :
    (maxConditionallyQualifiedAuth tcb modelAuth anc).institutional = 0 ∧
    (checkAuthorityLe claimedAuth (maxConditionallyQualifiedAuth tcb modelAuth anc) = true →
      claimedAuth.institutional = 0) := by
  refine ⟨rfl, ?_⟩
  intro hle
  have hprop := (lem_checkAuthorityLe_iff _ _).mp hle
  have hi := hprop.2.2
  dsimp [maxConditionallyQualifiedAuth] at hi
  omega

/-! ### Part 2: Stage E-R2 Specification, Causal Modes (`F-E04 & F-E07`), & Attested Holdout (`F-E06`) -/

/-- Out-of-sample holdout dataset carrying a full `EmpiricalDatasetAnchorQ0` (`F-E06 & F-E08 Lock 1`). -/
structure HoldoutDatasetSpecQ0 (thetaCtx : ContextQ0) where
  obsVars    : VarCtxQ0
  Phi        : MatQ0 obsVars.length thetaCtx.vars.length
  d0         : VecQ0 obsVars.length
  unitPhi    : Fin obsVars.length → Fin thetaCtx.vars.length → UnitSpecQ0
  unitD0     : Fin obsVars.length → UnitSpecQ0
  anchorHold : EmpiricalDatasetAnchorQ0 obsVars.length

namespace HoldoutDatasetSpecQ0

abbrev toDesign {thetaCtx : ContextQ0} (H : HoldoutDatasetSpecQ0 thetaCtx) :
    AffineObservationDesignQ0 :=
  { thetaCtx := thetaCtx
    obsVars  := H.obsVars
    Phi      := H.Phi
    d0       := H.d0
    unitPhi  := H.unitPhi
    unitD0   := H.unitD0 }

abbrev yHold {thetaCtx : ContextQ0} (H : HoldoutDatasetSpecQ0 thetaCtx) : VecQ0 H.obsVars.length :=
  H.anchorHold.yObs

abbrev epsHold {thetaCtx : ContextQ0} (H : HoldoutDatasetSpecQ0 thetaCtx) : VecQ0 H.obsVars.length :=
  H.anchorHold.eps

end HoldoutDatasetSpecQ0

/-- Strictly separated causal evidence modes (`Tribunal F-E04 & F-E07`):
    active surgical `do`-clamping on `(sc.iDo, jTarget)`, passive interventional claim,
    and restricted canonical 3-node IV are kept on distinct constructors. -/
inductive CausalClaimModeQ0 where
  | predictiveObservational
  | interventionalActiveDo     (d : Nat) (sem : LinearSEMQ0 d) (sc : SurgicalDoCertQ0 d) (jTarget : Fin d)
  | interventionalPassiveClaim (d : Nat)
  | canonicalRestrictedIV3     (sem3 : LinearSEMQ0 3) (sc1 : SurgicalDoCertQ0 3)

def checkCausalModeStatic : CausalClaimModeQ0 → Bool
  | .predictiveObservational          => true
  | .interventionalActiveDo _ M sc jT => decide (sc.iDo ≠ jT) && checkSurgicalDoCert M sc
  | .interventionalPassiveClaim _     => true
  | .canonicalRestrictedIV3 M3 sc1    => checkCanonicalIV3Assumptions M3 sc1

def isPassivePredictiveMode : CausalClaimModeQ0 → Bool
  | .predictiveObservational => true
  | _                        => false

structure StageESpecQ0 where
  design      : AffineObservationDesignQ0
  anchor      : EmpiricalDatasetAnchorQ0 design.m
  cQuery      : VecQ0 design.p
  causalMode  : CausalClaimModeQ0
  optHoldout  : Option (HoldoutDatasetSpecQ0 design.thetaCtx)
  modelAuth   : AuthorityVecQ0
  claimedAuth : AuthorityVecQ0

inductive StageEInvalidReasonQ0 where
  | illTypedObservation
  | invalidUncertaintySpec
  | invalidSEMOrIVAssumptions
  | authorityEscalation
  deriving DecidableEq, Repr, Inhabited

inductive StageEGateOutcomeQ0 where
  | verifiedEmptyParameterPrior
  | verifiedConditionallyEmpiricallyQualified
  | verifiedQueryConditionallyQualified
  | verifiedActiveDoConditionallyQualified
  | verifiedCanonicalIVConditionallyQualified
  | verifiedUnderdeterminedCompatibility
  | verifiedEmpiricalFarkasFalsification
  | verifiedHoldoutExtrapolationFalsified
  | verifiedConfoundingCausalObstruction
  | rejectedInvalidEmpiricalSpec : StageEInvalidReasonQ0 → StageEGateOutcomeQ0
  | rejectedUnattestedEmpiricalQualification
  | rejectedInvalidCertificate
  deriving DecidableEq, Repr, Inhabited

def isPositivelyQualifiedOutcome : StageEGateOutcomeQ0 → Bool
  | .verifiedConditionallyEmpiricallyQualified => true
  | .verifiedQueryConditionallyQualified       => true
  | .verifiedActiveDoConditionallyQualified    => true
  | .verifiedCanonicalIVConditionallyQualified => true
  | _                                          => false

def checkHoldoutUnits {thetaCtx : ContextQ0} : Option (HoldoutDatasetSpecQ0 thetaCtx) → Bool
  | none   => true
  | some H => checkAffineObservationUnits H.toDesign && decide (H.obsVars = H.anchorHold.obsVars)

def checkHoldoutEpsPos {thetaCtx : ContextQ0} : Option (HoldoutDatasetSpecQ0 thetaCtx) → Bool
  | none   => true
  | some H => vecPosBool H.epsHold

def checkHoldoutPointFeasible {thetaCtx : ContextQ0} (θ : VecQ0 thetaCtx.vars.length) :
    Option (HoldoutDatasetSpecQ0 thetaCtx) → Bool
  | none   => true
  | some H => checkFeasibleParameter H.toDesign H.yHold H.epsHold θ

def verifyOptHoldoutProvenanceAndOffset {thetaCtx : ContextQ0}
    (tcb : ExternalEmpiricalTrustCtxQ0) : Option (HoldoutDatasetSpecQ0 thetaCtx) → Bool
  | none   => true
  | some H => verifyExternalProvenance tcb H.anchorHold &&
              vecEqBool H.d0 H.anchorHold.d0Calibrated

/-- Unconditional positive qualification provenance, pre-committed offset equality, holdout
    provenance, and `(1, 1, 0)` authority gate (`Tribunal F-E06 & F-E08 Lock 1`). -/
def checkEmpiricalQualificationProvenance
    (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0) : Bool :=
  verifyExternalProvenance tcb S.anchor &&
  vecEqBool S.design.d0 S.anchor.d0Calibrated &&
  verifyOptHoldoutProvenanceAndOffset tcb S.optHoldout &&
  decide (S.claimedAuth = AuthorityVecQ0.formalEmpirical)

/-- Deterministic 4-step static validator (`validateStageESpec`). -/
def validateStageESpec (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0) :
    Option StageEInvalidReasonQ0 :=
  if !(checkAffineObservationUnits S.design &&
       decide (S.design.obsVars = S.anchor.obsVars) &&
       checkHoldoutUnits S.optHoldout) then
    some .illTypedObservation
  else if !(vecPosBool S.anchor.eps && checkHoldoutEpsPos S.optHoldout) then
    some .invalidUncertaintySpec
  else if !checkCausalModeStatic S.causalMode then
    some .invalidSEMOrIVAssumptions
  else if !(checkAuthorityLe S.modelAuth tcb.sysModelAuth &&
            checkAuthorityLe S.claimedAuth
              (maxConditionallyQualifiedAuth tcb S.modelAuth S.anchor)) then
    some .authorityEscalation
  else
    none

theorem lem_validateStageESpec_none_authority
    {tcb : ExternalEmpiricalTrustCtxQ0} {S : StageESpecQ0}
    (hv : validateStageESpec tcb S = none) :
    AuthorityLe S.modelAuth tcb.sysModelAuth ∧
    AuthorityLe S.claimedAuth (maxConditionallyQualifiedAuth tcb S.modelAuth S.anchor) ∧
    S.claimedAuth.institutional = 0 := by
  unfold validateStageESpec at hv
  split at hv
  · contradiction
  · split at hv
    · contradiction
    · split at hv
      · contradiction
      · split at hv
        · contradiction
        · rename_i h1 h2 h3 h4
          have hb : checkAuthorityLe S.modelAuth tcb.sysModelAuth = true ∧
              checkAuthorityLe S.claimedAuth
                (maxConditionallyQualifiedAuth tcb S.modelAuth S.anchor) = true := by
            cases bm : checkAuthorityLe S.modelAuth tcb.sysModelAuth <;>
            cases bc : checkAuthorityLe S.claimedAuth
                (maxConditionallyQualifiedAuth tcb S.modelAuth S.anchor) <;>
            simp [bm, bc] at h4 ⊢
          exact ⟨(lem_checkAuthorityLe_iff _ _).mp hb.1,
                 (lem_checkAuthorityLe_iff _ _).mp hb.2,
                 (thm_stageE_institutional_firewall_zero tcb S.modelAuth S.claimedAuth S.anchor).2 hb.2⟩

/-! ### Part 3: Certificate Bundles & Deterministic `auditStageEEmpiricalGate` (`R2`) -/

def checkOptTightCert (D : AffineObservationDesignQ0) (yObs eps : VecQ0 D.m)
    (cQuery : VecQ0 D.p) : Option (TightQueryIntervalCertQ0 D) → Bool
  | none    => true
  | some tc => checkTightQueryIntervalCert D yObs eps cQuery tc

inductive StageECertBundleQ0 (S : StageESpecQ0) where
  | emptyPrior
      (ec : EmptyOverlapCertQ0)
  | fullPointQualified
      (rc       : RankNullityCertQ0 S.design.m S.design.p)
      (lpCert   : QueryEnclosingCertQ0 S.design)
      (optTight : Option (TightQueryIntervalCertQ0 S.design))
  | queryOnlyQualified
      (rc       : RankNullityCertQ0 S.design.m S.design.p)
      (lpCert   : QueryEnclosingCertQ0 S.design)
      (optTight : Option (TightQueryIntervalCertQ0 S.design))
  | activeDoQualified
      (r1       : Fin S.design.m)
      (r2       : Fin S.design.m)
      (rc       : RankNullityCertQ0 S.design.m S.design.p)
      (lpCert   : QueryEnclosingCertQ0 S.design)
      (optTight : Option (TightQueryIntervalCertQ0 S.design))
  | canonicalIV3Qualified
      (rc     : RankNullityCertQ0 S.design.m S.design.p)
      (lpCert : QueryEnclosingCertQ0 S.design)
  | underdeterminedTwin
      (tw : TwinUnidentifiableWitnessQ0 S.design.p)
  | empiricalFarkas
      (fc : EmpiricalFalsificationCertQ0 S.design)
  | holdoutDisjoint
      (hcGen : ∀ H : HoldoutDatasetSpecQ0 S.design.thetaCtx,
                 S.optHoldout = some H → HoldoutDisjointCertQ0 S.design H.toDesign)
  | confoundingTwin
      {d : Nat} (tc : ConfoundingTwinCertQ0 d)

def checkFullPointCore (S : StageESpecQ0)
    (rc : RankNullityCertQ0 S.design.m S.design.p)
    (lpCert : QueryEnclosingCertQ0 S.design)
    (optTight : Option (TightQueryIntervalCertQ0 S.design)) : Bool :=
  isPassivePredictiveMode S.causalMode &&
  decide (S.anchor.regimeSpec = .passiveObservational) &&
  checkRankNullityCert S.design.Phi rc &&
  decide (rc.k = 0) &&
  checkQueryEnclosingCert S.design S.anchor.yObs S.anchor.eps S.cQuery lpCert &&
  checkOptTightCert S.design S.anchor.yObs S.anchor.eps S.cQuery optTight &&
  checkHoldoutPointFeasible lpCert.thetaHat S.optHoldout

def checkFullPointBundle (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (rc : RankNullityCertQ0 S.design.m S.design.p)
    (lpCert : QueryEnclosingCertQ0 S.design)
    (optTight : Option (TightQueryIntervalCertQ0 S.design)) : Bool :=
  checkEmpiricalQualificationProvenance tcb S &&
  checkFullPointCore S rc lpCert optTight

def checkQueryOnlyCore (S : StageESpecQ0)
    (rc : RankNullityCertQ0 S.design.m S.design.p)
    (lpCert : QueryEnclosingCertQ0 S.design)
    (optTight : Option (TightQueryIntervalCertQ0 S.design)) : Bool :=
  isPassivePredictiveMode S.causalMode &&
  decide (S.anchor.regimeSpec = .passiveObservational) &&
  decide (0 < rc.k) &&
  checkQueryOrthogonalKernel S.design rc S.cQuery &&
  checkQueryEnclosingCert S.design S.anchor.yObs S.anchor.eps S.cQuery lpCert &&
  checkOptTightCert S.design S.anchor.yObs S.anchor.eps S.cQuery optTight &&
  checkHoldoutPointFeasible lpCert.thetaHat S.optHoldout

def checkQueryOnlyBundle (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (rc : RankNullityCertQ0 S.design.m S.design.p)
    (lpCert : QueryEnclosingCertQ0 S.design)
    (optTight : Option (TightQueryIntervalCertQ0 S.design)) : Bool :=
  checkEmpiricalQualificationProvenance tcb S &&
  checkQueryOnlyCore S rc lpCert optTight

/-- Core active surgical `do` protocol, clamp schedule, distinct-clamp, & SEM envelope check (`F-E07 & F-E08`). -/
def checkActiveDoCore (S : StageESpecQ0)
    (r1 r2 : Fin S.design.m)
    (rc : RankNullityCertQ0 S.design.m S.design.p)
    (lpCert : QueryEnclosingCertQ0 S.design)
    (optTight : Option (TightQueryIntervalCertQ0 S.design)) : Bool :=
  match S.causalMode with
  | .interventionalActiveDo _ sem sc jTarget =>
      if hp : S.design.p = 1 then
        let j0 := finZeroOfP1 S.design hp
        let θSem : VecQ0 S.design.p := fun _ => interventionalUnitEffect sc jTarget
        match S.anchor.regimeSpec with
        | .activeSurgicalClamp iClamp jT clampLevels =>
            decide (sc.iDo ≠ jTarget) &&
            checkSurgicalDoCert sem sc &&
            decide (iClamp = sc.iDo.val) &&
            decide (jT = jTarget.val) &&
            decide (vecToList (fun r : Fin S.design.m => S.design.Phi r j0) = clampLevels) &&
            decide (S.cQuery j0 = 1) &&
            decide (S.design.Phi r1 j0 ≠ S.design.Phi r2 j0) &&
            checkRankNullityCert S.design.Phi rc &&
            decide (rc.k = 0) &&
            checkFeasibleParameter S.design S.anchor.yObs S.anchor.eps θSem &&
            checkHoldoutPointFeasible θSem S.optHoldout &&
            checkQueryEnclosingCert S.design S.anchor.yObs S.anchor.eps S.cQuery lpCert &&
            checkOptTightCert S.design S.anchor.yObs S.anchor.eps S.cQuery optTight &&
            checkHoldoutPointFeasible lpCert.thetaHat S.optHoldout
        | _ => false
      else false
  | _ => false

def checkActiveDoBundle (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (r1 r2 : Fin S.design.m)
    (rc : RankNullityCertQ0 S.design.m S.design.p)
    (lpCert : QueryEnclosingCertQ0 S.design)
    (optTight : Option (TightQueryIntervalCertQ0 S.design)) : Bool :=
  checkEmpiricalQualificationProvenance tcb S &&
  checkActiveDoCore S r1 r2 rc lpCert optTight

/-- Core canonical 3-node IV covariance moment, zero-offset, & Wald SEM feasibility check (`F-E04, F-E07 & F-E08`). -/
def checkCanonicalIV3Core (S : StageESpecQ0)
    (rc : RankNullityCertQ0 S.design.m S.design.p)
    (lpCert : QueryEnclosingCertQ0 S.design) : Bool :=
  match S.causalMode with
  | .canonicalRestrictedIV3 sem3 sc1 =>
      if hm : S.design.m = 1 then
        if hp : S.design.p = 1 then
          let i0 := finZeroOfM1 S.design hm
          let j0 := finZeroOfP1 S.design hp
          let θIV : VecQ0 S.design.p := fun _ => interventionalUnitEffect sc1 ivIdx2
          decide (S.anchor.regimeSpec = .passiveObservational) &&
          vecEqBool S.design.d0 (zeroVec S.design.m) &&
          checkCanonicalIV3Assumptions sem3 sc1 &&
          decide (S.cQuery j0 = 1) &&
          decide (S.design.Phi i0 j0 = sem3.SigmaObs ivIdx0 ivIdx1) &&
          checkRankNullityCert S.design.Phi rc &&
          decide (rc.k = 0) &&
          checkFeasibleParameter S.design S.anchor.yObs S.anchor.eps θIV &&
          checkHoldoutPointFeasible θIV S.optHoldout &&
          checkQueryEnclosingCert S.design S.anchor.yObs S.anchor.eps S.cQuery lpCert &&
          checkHoldoutPointFeasible lpCert.thetaHat S.optHoldout
        else false
      else false
  | _ => false

def checkCanonicalIV3Bundle (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (rc : RankNullityCertQ0 S.design.m S.design.p)
    (lpCert : QueryEnclosingCertQ0 S.design) : Bool :=
  checkEmpiricalQualificationProvenance tcb S &&
  checkCanonicalIV3Core S rc lpCert

def checkUnderdeterminedBundle (S : StageESpecQ0)
    (tw : TwinUnidentifiableWitnessQ0 S.design.p) : Bool :=
  checkTwinDomainIndistinguishable S.design S.cQuery tw &&
  checkFeasibleParameter S.design S.anchor.yObs S.anchor.eps tw.theta1 &&
  checkFeasibleParameter S.design S.anchor.yObs S.anchor.eps tw.theta2

def checkHoldoutDisjointBundle (S : StageESpecQ0)
    (hcGen : ∀ H : HoldoutDatasetSpecQ0 S.design.thetaCtx,
               S.optHoldout = some H → HoldoutDisjointCertQ0 S.design H.toDesign) : Bool :=
  match hOpt : S.optHoldout with
  | none => false
  | some H =>
      checkHoldoutDisjointCert S.design H.toDesign rfl
        S.anchor.yObs S.anchor.eps H.yHold H.epsHold (hcGen H hOpt)

theorem lem_checkHoldoutDisjointBundle_sound (S : StageESpecQ0)
    (hcGen : ∀ H : HoldoutDatasetSpecQ0 S.design.thetaCtx,
               S.optHoldout = some H → HoldoutDisjointCertQ0 S.design H.toDesign)
    (hc : checkHoldoutDisjointBundle S hcGen = true) :
    ∃ H : HoldoutDatasetSpecQ0 S.design.thetaCtx,
      S.optHoldout = some H ∧
      (∃ θ_cal : VecQ0 S.design.p,
        InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ_cal) ∧
      ∀ θ : VecQ0 S.design.p,
        ¬ (InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ ∧
           InFeasibleParameterSet H.toDesign H.yHold H.epsHold θ) := by
  cases S with
  | mk design anc cq cm optH ma ca =>
    cases optH with
    | none =>
        unfold checkHoldoutDisjointBundle at hc
        contradiction
    | some H =>
        unfold checkHoldoutDisjointBundle at hc
        dsimp only at hc
        rcases thm_holdout_disjoint_falsification
          design H.toDesign rfl anc.yObs anc.eps H.yHold H.epsHold (hcGen H rfl) hc with
          ⟨hcal, hdisj⟩
        exact ⟨H, rfl, ⟨_, hcal⟩, hdisj⟩

def checkConfoundingBundle (S : StageESpecQ0) {d : Nat} (tc : ConfoundingTwinCertQ0 d) : Bool :=
  match S.causalMode with
  | .interventionalPassiveClaim dSpec => decide (d = dSpec) && checkConfoundingTwinCert tc
  | _ => false

/-- Trusted Deterministic Stage E-R2 Conditional Empirical Qualification Gate. -/
def auditStageEEmpiricalGate
    (tcb : ExternalEmpiricalTrustCtxQ0)
    (S : StageESpecQ0)
    (bundle : StageECertBundleQ0 S) : StageEGateOutcomeQ0 :=
  match validateStageESpec tcb S with
  | some reason => .rejectedInvalidEmpiricalSpec reason
  | none =>
      match bundle with
      | .emptyPrior ec =>
          if checkEmptyOverlapCert S.design.thetaCtx ec then .verifiedEmptyParameterPrior
          else .rejectedInvalidCertificate
      | .fullPointQualified rc lpCert optTight =>
          if !checkEmpiricalQualificationProvenance tcb S then
            .rejectedUnattestedEmpiricalQualification
          else if checkFullPointCore S rc lpCert optTight then
            .verifiedConditionallyEmpiricallyQualified
          else .rejectedInvalidCertificate
      | .queryOnlyQualified rc lpCert optTight =>
          if !checkEmpiricalQualificationProvenance tcb S then
            .rejectedUnattestedEmpiricalQualification
          else if checkQueryOnlyCore S rc lpCert optTight then
            .verifiedQueryConditionallyQualified
          else .rejectedInvalidCertificate
      | .activeDoQualified r1 r2 rc lpCert optTight =>
          if !checkEmpiricalQualificationProvenance tcb S then
            .rejectedUnattestedEmpiricalQualification
          else if checkActiveDoCore S r1 r2 rc lpCert optTight then
            .verifiedActiveDoConditionallyQualified
          else .rejectedInvalidCertificate
      | .canonicalIV3Qualified rc lpCert =>
          if !checkEmpiricalQualificationProvenance tcb S then
            .rejectedUnattestedEmpiricalQualification
          else if checkCanonicalIV3Core S rc lpCert then
            .verifiedCanonicalIVConditionallyQualified
          else .rejectedInvalidCertificate
      | .underdeterminedTwin tw =>
          if checkUnderdeterminedBundle S tw then .verifiedUnderdeterminedCompatibility
          else .rejectedInvalidCertificate
      | .empiricalFarkas fc =>
          if checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc then
            .verifiedEmpiricalFarkasFalsification
          else .rejectedInvalidCertificate
      | .holdoutDisjoint hcGen =>
          if checkHoldoutDisjointBundle S hcGen then .verifiedHoldoutExtrapolationFalsified
          else .rejectedInvalidCertificate
      | .confoundingTwin tc =>
          if checkConfoundingBundle S tc then .verifiedConfoundingCausalObstruction
          else .rejectedInvalidCertificate

/-! ### Part 4: Master Unconditional Provenance, Soundness, & Mutual-Exclusion Theorems (`R2`) -/

/-- Target Theorem `thm_stageE_invalid_spec_universal_reject`:
    Any statically invalid `StageESpecQ0` is rejected across ALL possible certificate bundles. -/
theorem thm_stageE_invalid_spec_universal_reject
    (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (reason : StageEInvalidReasonQ0)
    (hinv : validateStageESpec tcb S = some reason) :
    ∀ bundle : StageECertBundleQ0 S,
      auditStageEEmpiricalGate tcb S bundle = .rejectedInvalidEmpiricalSpec reason := by
  intro bundle
  unfold auditStageEEmpiricalGate
  rw [hinv]

/-- Target Theorem `thm_stageE_r2_qualified_unconditional_provenance` (`Tribunal F-E06 & F-E08 Lock 1`):
    Whenever `auditStageEEmpiricalGate tcb S bundle` produces ANY of the four positive empirical
    qualification outcomes (`isPositivelyQualifiedOutcome = true`), UNCONDITIONALLY (with ZERO
    `1 ≤ claimedAuth.empirical` premise):
      1. `verifyExternalProvenance tcb S.anchor = true`,
      2. `S.claimedAuth = AuthorityVecQ0.formalEmpirical` (`(1, 1, 0)`),
      3. `S.design.d0 = S.anchor.d0Calibrated`,
      4. `∃ rec ∈ tcb.attestedRecords` matching `S.anchor` with `vecToList S.design.d0 = rec.d0CalibratedList`,
         `rec.calSeq < rec.obsSeq`, and `isLowerSha256Hex rec.d0CalibrationSha256Hex = true`,
      5. `∀ H, S.optHoldout = some H → verifyExternalProvenance tcb H.anchorHold = true ∧ H.d0 = H.anchorHold.d0Calibrated`,
      6. `1 ≤ S.modelAuth.formal ∧ AuthorityLe S.modelAuth tcb.sysModelAuth`. -/
theorem thm_stageE_r2_qualified_unconditional_provenance
    (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (bundle : StageECertBundleQ0 S)
    (hqual : isPositivelyQualifiedOutcome (auditStageEEmpiricalGate tcb S bundle) = true) :
    verifyExternalProvenance tcb S.anchor = true ∧
    S.claimedAuth = AuthorityVecQ0.formalEmpirical ∧
    S.design.d0 = S.anchor.d0Calibrated ∧
    (∃ rec ∈ tcb.attestedRecords,
      recordMatchesAnchor S.anchor rec = true ∧
      vecToList S.design.d0 = rec.d0CalibratedList ∧
      rec.calSeq < rec.obsSeq ∧
      isLowerSha256Hex rec.d0CalibrationSha256Hex = true) ∧
    (∀ H : HoldoutDatasetSpecQ0 S.design.thetaCtx,
      S.optHoldout = some H →
        verifyExternalProvenance tcb H.anchorHold = true ∧
        H.d0 = H.anchorHold.d0Calibrated) ∧
    1 ≤ S.modelAuth.formal ∧
    AuthorityLe S.modelAuth tcb.sysModelAuth := by
  unfold auditStageEEmpiricalGate at hqual
  cases hv : validateStageESpec tcb S with
  | some r =>
      rw [hv] at hqual
      contradiction
  | none =>
      rw [hv] at hqual
      dsimp only at hqual
      rcases lem_validateStageESpec_none_authority hv with ⟨hm_le, hc_le, _⟩
      have hprov_gate : checkEmpiricalQualificationProvenance tcb S = true := by
        cases bundle with
        | emptyPrior ec =>
            by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;> simp [hc, isPositivelyQualifiedOutcome] at hqual
        | fullPointQualified rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S with
            | true => rfl
            | false => simp [hp, isPositivelyQualifiedOutcome] at hqual
        | queryOnlyQualified rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S with
            | true => rfl
            | false => simp [hp, isPositivelyQualifiedOutcome] at hqual
        | activeDoQualified r1 r2 rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S with
            | true => rfl
            | false => simp [hp, isPositivelyQualifiedOutcome] at hqual
        | canonicalIV3Qualified rc lp =>
            cases hp : checkEmpiricalQualificationProvenance tcb S with
            | true => rfl
            | false => simp [hp, isPositivelyQualifiedOutcome] at hqual
        | underdeterminedTwin tw =>
            by_cases hc : checkUnderdeterminedBundle S tw = true <;> simp [hc, isPositivelyQualifiedOutcome] at hqual
        | empiricalFarkas fc =>
            by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true <;>
              simp [hc, isPositivelyQualifiedOutcome] at hqual
        | holdoutDisjoint hcGen =>
            by_cases hc : checkHoldoutDisjointBundle S hcGen = true <;> simp [hc, isPositivelyQualifiedOutcome] at hqual
        | confoundingTwin tc =>
            by_cases hc : checkConfoundingBundle S tc = true <;> simp [hc, isPositivelyQualifiedOutcome] at hqual
      unfold checkEmpiricalQualificationProvenance at hprov_gate
      simp only [Bool.and_eq_true, vecEqBool_iff, decide_eq_true_eq] at hprov_gate
      rcases hprov_gate with ⟨⟨⟨hv_anc, hd0_eq⟩, hhold_ok⟩, hauth_110⟩
      have hv_raw := hv_anc
      unfold verifyExternalProvenance at hv_raw
      simp only [Bool.and_eq_true, decide_eq_true_eq, List.any_eq_true] at hv_raw
      rcases hv_raw with ⟨⟨⟨hprev, hd0_sha⟩, hseq_lt⟩, ⟨rec, hmem, hmatch⟩⟩
      have hmatch_raw := hmatch
      unfold recordMatchesAnchor at hmatch_raw
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hmatch_raw
      rcases hmatch_raw with ⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨_, _⟩, _⟩, hd0_sha_eq⟩, hcal_eq⟩, hobs_eq⟩, _⟩, _⟩, _⟩, hd0_list_eq⟩, _⟩, _⟩
      have hrec_d0 : vecToList S.design.d0 = rec.d0CalibratedList := by
        rw [hd0_eq, hd0_list_eq]
      have hrec_seq : rec.calSeq < rec.obsSeq := by
        rw [← hcal_eq, ← hobs_eq]
        exact hseq_lt
      have hrec_sha : isLowerSha256Hex rec.d0CalibrationSha256Hex = true := by
        rw [← hd0_sha_eq]
        exact hd0_sha
      have hhold_prop : ∀ H : HoldoutDatasetSpecQ0 S.design.thetaCtx,
          S.optHoldout = some H →
            verifyExternalProvenance tcb H.anchorHold = true ∧
            H.d0 = H.anchorHold.d0Calibrated := by
        intro H hOpt
        rw [hOpt] at hhold_ok
        unfold verifyOptHoldoutProvenanceAndOffset at hhold_ok
        simp only [Bool.and_eq_true, vecEqBool_iff] at hhold_ok
        exact hhold_ok
      have hmod1 : 1 ≤ S.modelAuth.formal := by
        have h1 := hc_le.1
        rw [hauth_110] at h1
        dsimp [AuthorityVecQ0.formalEmpirical, maxConditionallyQualifiedAuth] at h1
        exact Nat.le_trans h1 (Nat.min_le_right 1 S.modelAuth.formal)
      exact ⟨hv_anc, hauth_110, hd0_eq, ⟨rec, hmem, hmatch, hrec_d0, hrec_seq, hrec_sha⟩,
             hhold_prop, hmod1, hm_le⟩

/-- Target Theorem `thm_empty_tcb_blocks_all_qualified_outcomes` (`Direct F-E06 Resolution`):
    Whenever `verifyExternalProvenance tcb S.anchor = false` (in particular whenever
    `tcb.attestedRecords = []`), for EVERY `S` (including `claimedAuth = (1, 0, 0)`) and EVERY
    certificate bundle `bundle`, `auditStageEEmpiricalGate tcb S bundle` NEVER equals any of
    the four positive `*Qualified` outcomes! -/
theorem thm_empty_tcb_blocks_all_qualified_outcomes
    (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (hunatt : verifyExternalProvenance tcb S.anchor = false)
    (bundle : StageECertBundleQ0 S) :
    isPositivelyQualifiedOutcome (auditStageEEmpiricalGate tcb S bundle) = false ∧
    auditStageEEmpiricalGate tcb S bundle ≠ .verifiedConditionallyEmpiricallyQualified ∧
    auditStageEEmpiricalGate tcb S bundle ≠ .verifiedQueryConditionallyQualified ∧
    auditStageEEmpiricalGate tcb S bundle ≠ .verifiedActiveDoConditionallyQualified ∧
    auditStageEEmpiricalGate tcb S bundle ≠ .verifiedCanonicalIVConditionallyQualified := by
  have hfalse : isPositivelyQualifiedOutcome (auditStageEEmpiricalGate tcb S bundle) = false := by
    cases hq : isPositivelyQualifiedOutcome (auditStageEEmpiricalGate tcb S bundle) with
    | false => rfl
    | true =>
        have hv := (thm_stageE_r2_qualified_unconditional_provenance tcb S bundle hq).1
        rw [hunatt] at hv
        contradiction
  refine ⟨hfalse, ?_, ?_, ?_, ?_⟩ <;>
  · intro heq
    rw [heq] at hfalse
    contradiction

/-- Helper extracting a feasible parameter `θ_hat ∈ Θ_feas` (on both calibration and holdout)
    from any of the four positively qualified outcomes. -/
theorem lem_qualified_outcomes_have_feasible_witness
    {tcb : ExternalEmpiricalTrustCtxQ0} {S : StageESpecQ0} {b : StageECertBundleQ0 S}
    (hqual : isPositivelyQualifiedOutcome (auditStageEEmpiricalGate tcb S b) = true) :
    ∃ θ : VecQ0 S.design.p,
      InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ ∧
      checkHoldoutPointFeasible θ S.optHoldout = true := by
  unfold auditStageEEmpiricalGate at hqual
  cases hv : validateStageESpec tcb S with
  | some r => rw [hv] at hqual; contradiction
  | none =>
      rw [hv] at hqual
      dsimp only at hqual
      cases b with
      | emptyPrior ec =>
          by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;>
            simp [hc, isPositivelyQualifiedOutcome] at hqual
      | fullPointQualified rc lp optT =>
          cases hp : checkEmpiricalQualificationProvenance tcb S with
          | false => simp [hp, isPositivelyQualifiedOutcome] at hqual
          | true =>
              simp only [hp, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hqual
              cases hc : checkFullPointCore S rc lp optT with
              | false => simp [hc, isPositivelyQualifiedOutcome] at hqual
              | true =>
                  unfold checkFullPointCore at hc
                  simp only [Bool.and_eq_true] at hc
                  have hfeas := (thm_query_enclosing_interval_sound
                    S.design S.anchor.yObs S.anchor.eps S.cQuery lp hc.1.1.2).1
                  exact ⟨lp.thetaHat, hfeas, hc.2⟩
      | queryOnlyQualified rc lp optT =>
          cases hp : checkEmpiricalQualificationProvenance tcb S with
          | false => simp [hp, isPositivelyQualifiedOutcome] at hqual
          | true =>
              simp only [hp, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hqual
              cases hc : checkQueryOnlyCore S rc lp optT with
              | false => simp [hc, isPositivelyQualifiedOutcome] at hqual
              | true =>
                  unfold checkQueryOnlyCore at hc
                  simp only [Bool.and_eq_true] at hc
                  have hfeas := (thm_query_enclosing_interval_sound
                    S.design S.anchor.yObs S.anchor.eps S.cQuery lp hc.1.1.2).1
                  exact ⟨lp.thetaHat, hfeas, hc.2⟩
      | activeDoQualified r1 r2 rc lp optT =>
          cases hp : checkEmpiricalQualificationProvenance tcb S with
          | false => simp [hp, isPositivelyQualifiedOutcome] at hqual
          | true =>
              simp only [hp, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hqual
              cases hc : checkActiveDoCore S r1 r2 rc lp optT with
              | false => simp [hc, isPositivelyQualifiedOutcome] at hqual
              | true =>
                  unfold checkActiveDoCore at hc
                  cases hcm : S.causalMode with
                  | predictiveObservational => rw [hcm] at hc; contradiction
                  | interventionalPassiveClaim _ => rw [hcm] at hc; contradiction
                  | canonicalRestrictedIV3 _ _ => rw [hcm] at hc; contradiction
                  | interventionalActiveDo d sem sc jTarget =>
                      rw [hcm] at hc
                      dsimp only at hc
                      by_cases hdim : S.design.p = 1
                      · simp only [hdim, ↓reduceDIte] at hc
                        cases hreg : S.anchor.regimeSpec with
                        | passiveObservational => rw [hreg] at hc; contradiction
                        | activeSurgicalClamp iC jT cl =>
                            rw [hreg] at hc
                            dsimp only at hc
                            simp only [Bool.and_eq_true] at hc
                            have hfeas := (thm_query_enclosing_interval_sound
                              S.design S.anchor.yObs S.anchor.eps S.cQuery lp hc.1.1.2).1
                            exact ⟨lp.thetaHat, hfeas, hc.2⟩
                      · simp [hdim] at hc
      | canonicalIV3Qualified rc lp =>
          cases hp : checkEmpiricalQualificationProvenance tcb S with
          | false => simp [hp, isPositivelyQualifiedOutcome] at hqual
          | true =>
              simp only [hp, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hqual
              cases hc : checkCanonicalIV3Core S rc lp with
              | false => simp [hc, isPositivelyQualifiedOutcome] at hqual
              | true =>
                  unfold checkCanonicalIV3Core at hc
                  cases hcm : S.causalMode with
                  | predictiveObservational => rw [hcm] at hc; contradiction
                  | interventionalActiveDo _ _ _ _ => rw [hcm] at hc; contradiction
                  | interventionalPassiveClaim _ => rw [hcm] at hc; contradiction
                  | canonicalRestrictedIV3 sem3 sc1 =>
                      rw [hcm] at hc
                      dsimp only at hc
                      by_cases hm1 : S.design.m = 1
                      · simp only [hm1, ↓reduceDIte] at hc
                        by_cases hp1 : S.design.p = 1
                        · simp only [hp1, ↓reduceDIte, Bool.and_eq_true] at hc
                          have hfeas := (thm_query_enclosing_interval_sound
                            S.design S.anchor.yObs S.anchor.eps S.cQuery lp hc.1.2).1
                          exact ⟨lp.thetaHat, hfeas, hc.2⟩
                        · simp [hp1] at hc
                      · simp [hm1] at hc
      | underdeterminedTwin tw =>
          by_cases hc : checkUnderdeterminedBundle S tw = true <;>
            simp [hc, isPositivelyQualifiedOutcome] at hqual
      | empiricalFarkas fc =>
          by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true <;>
            simp [hc, isPositivelyQualifiedOutcome] at hqual
      | holdoutDisjoint hcGen =>
          by_cases hc : checkHoldoutDisjointBundle S hcGen = true <;>
            simp [hc, isPositivelyQualifiedOutcome] at hqual
      | confoundingTwin tc =>
          by_cases hc : checkConfoundingBundle S tc = true <;>
            simp [hc, isPositivelyQualifiedOutcome] at hqual

/-- Target Theorem `thm_stageE_conditionally_qualified_sound` (`Tribunal F-E01 ~ F-E08`):
    Whenever `auditStageEEmpiricalGate tcb S bundle = .verifiedConditionallyEmpiricallyQualified`:
      1. `verifyExternalProvenance tcb S.anchor = true` & `S.claimedAuth = (1, 1, 0)` & `S.design.d0 = S.anchor.d0Calibrated` (UNCONDITIONALLY!),
      2. `S.causalMode = .predictiveObservational` & `S.anchor.regimeSpec = .passiveObservational`,
      3. Global point identifiability (`∀ θ₁ θ₂, predict θ₁ = predict θ₂ → θ₁ = θ₂`), and
      4. Certified enclosing interval `[qLb, qUb]` over `Θ_feas`. -/
theorem thm_stageE_conditionally_qualified_sound
    (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (bundle : StageECertBundleQ0 S)
    (haud : auditStageEEmpiricalGate tcb S bundle = .verifiedConditionallyEmpiricallyQualified) :
    verifyExternalProvenance tcb S.anchor = true ∧
    S.claimedAuth = AuthorityVecQ0.formalEmpirical ∧
    S.design.d0 = S.anchor.d0Calibrated ∧
    S.causalMode = .predictiveObservational ∧
    S.anchor.regimeSpec = .passiveObservational ∧
    (∀ θ1 θ2 : VecQ0 S.design.p, S.design.predict θ1 = S.design.predict θ2 → θ1 = θ2) ∧
    (∃ lpCert : QueryEnclosingCertQ0 S.design,
      InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps lpCert.thetaHat ∧
      ∀ θ : VecQ0 S.design.p, InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ →
        lpCert.qLb S.anchor.yObs S.anchor.eps ≤ dotVec S.cQuery θ ∧
        dotVec S.cQuery θ ≤ lpCert.qUb S.anchor.yObs S.anchor.eps) := by
  have hqual : isPositivelyQualifiedOutcome (auditStageEEmpiricalGate tcb S bundle) = true := by
    rw [haud]; rfl
  rcases thm_stageE_r2_qualified_unconditional_provenance tcb S bundle hqual with
    ⟨hv_anc, hauth_110, hd0_eq, _, _, _, _⟩
  unfold auditStageEEmpiricalGate at haud
  cases hv : validateStageESpec tcb S with
  | some r => rw [hv] at haud; contradiction
  | none =>
      rw [hv] at haud
      dsimp only at haud
      cases bundle with
      | emptyPrior ec =>
          by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;> simp [hc] at haud
      | fullPointQualified rc lp optT =>
          cases hp : checkEmpiricalQualificationProvenance tcb S with
          | false => simp [hp] at haud
          | true =>
              simp only [hp, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at haud
              cases hc : checkFullPointCore S rc lp optT with
              | false => simp [hc] at haud
              | true =>
                  unfold checkFullPointCore at hc
                  simp only [Bool.and_eq_true, decide_eq_true_eq] at hc
                  have hcm_eq : S.causalMode = .predictiveObservational := by
                    have hpm := hc.1.1.1.1.1.1
                    cases hcm : S.causalMode <;> simp [hcm, isPassivePredictiveMode] at hpm ⊢
                  have hreg_eq : S.anchor.regimeSpec = .passiveObservational := hc.1.1.1.1.1.2
                  have hid := (thm_affine_global_point_identifiable S.design rc hc.1.1.1.1.2 hc.1.1.1.2).2
                  have henc := thm_query_enclosing_interval_sound
                    S.design S.anchor.yObs S.anchor.eps S.cQuery lp hc.1.1.2
                  exact ⟨hv_anc, hauth_110, hd0_eq, hcm_eq, hreg_eq, hid, ⟨lp, henc.1, henc.2.1⟩⟩
      | queryOnlyQualified rc lp optT =>
          cases hp : checkEmpiricalQualificationProvenance tcb S <;>
          cases hc : checkQueryOnlyCore S rc lp optT <;> simp [hp, hc] at haud
      | activeDoQualified r1 r2 rc lp optT =>
          cases hp : checkEmpiricalQualificationProvenance tcb S <;>
          cases hc : checkActiveDoCore S r1 r2 rc lp optT <;> simp [hp, hc] at haud
      | canonicalIV3Qualified rc lp =>
          cases hp : checkEmpiricalQualificationProvenance tcb S <;>
          cases hc : checkCanonicalIV3Core S rc lp <;> simp [hp, hc] at haud
      | underdeterminedTwin tw =>
          by_cases hc : checkUnderdeterminedBundle S tw = true <;> simp [hc] at haud
      | empiricalFarkas fc =>
          by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true <;>
            simp [hc] at haud
      | holdoutDisjoint hcGen =>
          by_cases hc : checkHoldoutDisjointBundle S hcGen = true <;> simp [hc] at haud
      | confoundingTwin tc =>
          by_cases hc : checkConfoundingBundle S tc = true <;> simp [hc] at haud

/-- Target Theorem `thm_stageE_active_do_qualified_sound` (`Tribunal F-E06, F-E07 & F-E08`):
    Whenever `auditStageEEmpiricalGate tcb S bundle = .verifiedActiveDoConditionallyQualified`:
      1. Unconditional TCB provenance (`verifyExternalProvenance = true`), `claimedAuth = (1, 1, 0)`,
         and pre-committed offset equality `S.design.d0 = S.anchor.d0Calibrated`,
      2. Global point identifiability of `S.design`, AND
      3. `S.causalMode = .interventionalActiveDo d sem sc jTarget` with TCB-attested
         `activeSurgicalClamp sc.iDo.val jTarget.val clampLevels`, exact clamp schedule
         `vecToList (fun r => S.design.Phi r 0) = clampLevels`, two distinct clamp levels
         `S.design.Phi r1 0 ≠ S.design.Phi r2 0`, and direct feasibility of the SEM's surgical
         effect `θ_SEM = (fun _ => interventionalUnitEffect sc jTarget) ∈ Θ_feas`! -/
theorem thm_stageE_active_do_qualified_sound
    (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (bundle : StageECertBundleQ0 S)
    (haud : auditStageEEmpiricalGate tcb S bundle = .verifiedActiveDoConditionallyQualified) :
    verifyExternalProvenance tcb S.anchor = true ∧
    S.claimedAuth = AuthorityVecQ0.formalEmpirical ∧
    S.design.d0 = S.anchor.d0Calibrated ∧
    (∀ θ1 θ2 : VecQ0 S.design.p, S.design.predict θ1 = S.design.predict θ2 → θ1 = θ2) ∧
    ∃ (d : Nat) (sem : LinearSEMQ0 d) (sc : SurgicalDoCertQ0 d) (jTarget : Fin d)
      (clampLevels : List Rat) (hp : S.design.p = 1) (r1 r2 : Fin S.design.m),
      S.causalMode = .interventionalActiveDo d sem sc jTarget ∧
      sc.iDo ≠ jTarget ∧
      checkSurgicalDoCert sem sc = true ∧
      S.anchor.regimeSpec = .activeSurgicalClamp sc.iDo.val jTarget.val clampLevels ∧
      vecToList (fun r : Fin S.design.m => S.design.Phi r (finZeroOfP1 S.design hp)) = clampLevels ∧
      S.design.Phi r1 (finZeroOfP1 S.design hp) ≠ S.design.Phi r2 (finZeroOfP1 S.design hp) ∧
      InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps
        (fun _ => interventionalUnitEffect sc jTarget) := by
  have hqual : isPositivelyQualifiedOutcome (auditStageEEmpiricalGate tcb S bundle) = true := by
    rw [haud]; rfl
  rcases thm_stageE_r2_qualified_unconditional_provenance tcb S bundle hqual with
    ⟨hv_anc, hauth_110, hd0_eq, _, _, _, _⟩
  unfold auditStageEEmpiricalGate at haud
  cases hv : validateStageESpec tcb S with
  | some r => rw [hv] at haud; contradiction
  | none =>
      rw [hv] at haud
      dsimp only at haud
      cases bundle with
      | emptyPrior ec =>
          by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;> simp [hc] at haud
      | fullPointQualified rc lp optT =>
          cases hp : checkEmpiricalQualificationProvenance tcb S <;>
          cases hc : checkFullPointCore S rc lp optT <;> simp [hp, hc] at haud
      | queryOnlyQualified rc lp optT =>
          cases hp : checkEmpiricalQualificationProvenance tcb S <;>
          cases hc : checkQueryOnlyCore S rc lp optT <;> simp [hp, hc] at haud
      | activeDoQualified r1 r2 rc lp optT =>
          cases hp_gate : checkEmpiricalQualificationProvenance tcb S with
          | false => simp [hp_gate] at haud
          | true =>
              simp only [hp_gate, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at haud
              cases hc : checkActiveDoCore S r1 r2 rc lp optT with
              | false => simp [hc] at haud
              | true =>
                  unfold checkActiveDoCore at hc
                  cases hcm : S.causalMode with
                  | predictiveObservational => rw [hcm] at hc; contradiction
                  | interventionalPassiveClaim _ => rw [hcm] at hc; contradiction
                  | canonicalRestrictedIV3 _ _ => rw [hcm] at hc; contradiction
                  | interventionalActiveDo d sem sc jTarget =>
                      rw [hcm] at hc
                      dsimp only at hc
                      by_cases hdim : S.design.p = 1
                      · simp only [hdim, ↓reduceDIte] at hc
                        cases hreg : S.anchor.regimeSpec with
                        | passiveObservational => rw [hreg] at hc; contradiction
                        | activeSurgicalClamp iC jT clampLevels =>
                            rw [hreg] at hc
                            dsimp only at hc
                            simp only [Bool.and_eq_true, decide_eq_true_eq, lem_checkFeasibleParameter_iff] at hc
                            rcases hc with ⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨hido_ne, hsc⟩, hiC⟩, hjT⟩, hcl_eq⟩, _⟩, hu_ne⟩, hrc⟩, hk0⟩, hsem_feas⟩, _⟩, _⟩, _⟩, _⟩
                            have hid := (thm_affine_global_point_identifiable S.design rc hrc hk0).2
                            exact ⟨hv_anc, hauth_110, hd0_eq, hid,
                                   ⟨d, sem, sc, jTarget, clampLevels, hdim, r1, r2,
                                    rfl, hido_ne, hsc, by rw [hiC, hjT], hcl_eq, hu_ne, hsem_feas⟩⟩
                      · simp [hdim] at hc
      | canonicalIV3Qualified rc lp =>
          cases hp : checkEmpiricalQualificationProvenance tcb S <;>
          cases hc : checkCanonicalIV3Core S rc lp <;> simp [hp, hc] at haud
      | underdeterminedTwin tw =>
          by_cases hc : checkUnderdeterminedBundle S tw = true <;> simp [hc] at haud
      | empiricalFarkas fc =>
          by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true <;>
            simp [hc] at haud
      | holdoutDisjoint hcGen =>
          by_cases hc : checkHoldoutDisjointBundle S hcGen = true <;> simp [hc] at haud
      | confoundingTwin tc =>
          by_cases hc : checkConfoundingBundle S tc = true <;> simp [hc] at haud

/-- Target Theorem `thm_stageE_canonical_iv3_qualified_sound` (`Tribunal F-E04, F-E06, F-E07 & F-E08`):
    Whenever `auditStageEEmpiricalGate tcb S bundle = .verifiedCanonicalIVConditionallyQualified`,
    `verifyExternalProvenance = true`, `claimedAuth = (1, 1, 0)`, `S.design.d0 = 0`, `S.anchor.regimeSpec = .passiveObservational`,
    and the canonical 3-node IV SEM's Wald causal effect `Σ_obs[0,2]/Σ_obs[0,1] = interventionalUnitEffect sc1 ivIdx2`
    lies directly inside `Θ_feas`! -/
theorem thm_stageE_canonical_iv3_qualified_sound
    (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (bundle : StageECertBundleQ0 S)
    (haud : auditStageEEmpiricalGate tcb S bundle = .verifiedCanonicalIVConditionallyQualified) :
    verifyExternalProvenance tcb S.anchor = true ∧
    S.claimedAuth = AuthorityVecQ0.formalEmpirical ∧
    S.design.d0 = zeroVec S.design.m ∧
    S.anchor.regimeSpec = .passiveObservational ∧
    ∃ (sem3 : LinearSEMQ0 3) (sc1 : SurgicalDoCertQ0 3) (hm : S.design.m = 1) (hp : S.design.p = 1),
      S.causalMode = .canonicalRestrictedIV3 sem3 sc1 ∧
      sem3.SigmaObs ivIdx0 ivIdx2 / sem3.SigmaObs ivIdx0 ivIdx1 = interventionalUnitEffect sc1 ivIdx2 ∧
      S.design.Phi (finZeroOfM1 S.design hm) (finZeroOfP1 S.design hp) = sem3.SigmaObs ivIdx0 ivIdx1 ∧
      InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps
        (fun _ => interventionalUnitEffect sc1 ivIdx2) := by
  have hqual : isPositivelyQualifiedOutcome (auditStageEEmpiricalGate tcb S bundle) = true := by
    rw [haud]; rfl
  rcases thm_stageE_r2_qualified_unconditional_provenance tcb S bundle hqual with
    ⟨hv_anc, hauth_110, _, _, _, _, _⟩
  unfold auditStageEEmpiricalGate at haud
  cases hv : validateStageESpec tcb S with
  | some r => rw [hv] at haud; contradiction
  | none =>
      rw [hv] at haud
      dsimp only at haud
      cases bundle with
      | emptyPrior ec =>
          by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;> simp [hc] at haud
      | fullPointQualified rc lp optT =>
          cases hp : checkEmpiricalQualificationProvenance tcb S <;>
          cases hc : checkFullPointCore S rc lp optT <;> simp [hp, hc] at haud
      | queryOnlyQualified rc lp optT =>
          cases hp : checkEmpiricalQualificationProvenance tcb S <;>
          cases hc : checkQueryOnlyCore S rc lp optT <;> simp [hp, hc] at haud
      | activeDoQualified r1 r2 rc lp optT =>
          cases hp : checkEmpiricalQualificationProvenance tcb S <;>
          cases hc : checkActiveDoCore S r1 r2 rc lp optT <;> simp [hp, hc] at haud
      | canonicalIV3Qualified rc lp =>
          cases hp_gate : checkEmpiricalQualificationProvenance tcb S with
          | false => simp [hp_gate] at haud
          | true =>
              simp only [hp_gate, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at haud
              cases hc : checkCanonicalIV3Core S rc lp with
              | false => simp [hc] at haud
              | true =>
                  unfold checkCanonicalIV3Core at hc
                  cases hcm : S.causalMode with
                  | predictiveObservational => rw [hcm] at hc; contradiction
                  | interventionalActiveDo _ _ _ _ => rw [hcm] at hc; contradiction
                  | interventionalPassiveClaim _ => rw [hcm] at hc; contradiction
                  | canonicalRestrictedIV3 sem3 sc1 =>
                      rw [hcm] at hc
                      dsimp only at hc
                      by_cases hm1 : S.design.m = 1
                      · simp only [hm1, ↓reduceDIte] at hc
                        by_cases hp1 : S.design.p = 1
                        · simp only [hp1, ↓reduceDIte, Bool.and_eq_true, decide_eq_true_eq,
                                     vecEqBool_iff, lem_checkFeasibleParameter_iff] at hc
                          rcases hc with ⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨hreg, hd0_zero⟩, hiv⟩, _⟩, hphi_cov⟩, _⟩, _⟩, hiv_feas⟩, _⟩, _⟩, _⟩
                          have hwald := (thm_canonical_iv3_wald_identifies_do_effect sem3 sc1 hiv).2.2.2
                          exact ⟨hv_anc, hauth_110, hd0_zero, hreg,
                                 ⟨sem3, sc1, hm1, hp1, rfl, hwald, hphi_cov, hiv_feas⟩⟩
                        · simp [hp1] at hc
                      · simp [hm1] at hc
      | underdeterminedTwin tw =>
          by_cases hc : checkUnderdeterminedBundle S tw = true <;> simp [hc] at haud
      | empiricalFarkas fc =>
          by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true <;>
            simp [hc] at haud
      | holdoutDisjoint hcGen =>
          by_cases hc : checkHoldoutDisjointBundle S hcGen = true <;> simp [hc] at haud
      | confoundingTwin tc =>
          by_cases hc : checkConfoundingBundle S tc = true <;> simp [hc] at haud

/-- Target Theorem `thm_stageE_farkas_falsified_sound_and_exclusive`:
    Whenever `auditStageEEmpiricalGate tcb S bundle = .verifiedEmpiricalFarkasFalsification`:
      1. `Θ_feas = ∅`, AND
      2. NO certificate bundle `b_any` can produce ANY of the four positive `*Qualified` outcomes
         or `.verifiedUnderdeterminedCompatibility`! -/
theorem thm_stageE_farkas_falsified_sound_and_exclusive
    (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (bundle : StageECertBundleQ0 S)
    (haud : auditStageEEmpiricalGate tcb S bundle = .verifiedEmpiricalFarkasFalsification) :
    (∀ θ : VecQ0 S.design.p, ¬ InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ) ∧
    (∀ b_any : StageECertBundleQ0 S,
      isPositivelyQualifiedOutcome (auditStageEEmpiricalGate tcb S b_any) = false ∧
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedUnderdeterminedCompatibility) := by
  have hunsat : ∀ θ : VecQ0 S.design.p,
      ¬ InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ := by
    unfold auditStageEEmpiricalGate at haud
    cases hv : validateStageESpec tcb S with
    | some r => rw [hv] at haud; contradiction
    | none =>
        rw [hv] at haud
        dsimp only at haud
        cases bundle with
        | emptyPrior ec =>
            by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;> simp [hc] at haud
        | fullPointQualified rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkFullPointCore S rc lp optT <;> simp [hp, hc] at haud
        | queryOnlyQualified rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkQueryOnlyCore S rc lp optT <;> simp [hp, hc] at haud
        | activeDoQualified r1 r2 rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkActiveDoCore S r1 r2 rc lp optT <;> simp [hp, hc] at haud
        | canonicalIV3Qualified rc lp =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkCanonicalIV3Core S rc lp <;> simp [hp, hc] at haud
        | underdeterminedTwin tw =>
            by_cases hc : checkUnderdeterminedBundle S tw = true <;> simp [hc] at haud
        | empiricalFarkas fc =>
            by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true
            · exact thm_empirical_farkas_falsification S.design S.anchor.yObs S.anchor.eps fc hc
            · simp [hc] at haud
        | holdoutDisjoint hcGen =>
            by_cases hc : checkHoldoutDisjointBundle S hcGen = true <;> simp [hc] at haud
        | confoundingTwin tc =>
            by_cases hc : checkConfoundingBundle S tc = true <;> simp [hc] at haud
  refine ⟨hunsat, fun b_any => ⟨?_, ?_⟩⟩
  · cases hq : isPositivelyQualifiedOutcome (auditStageEEmpiricalGate tcb S b_any) with
    | false => rfl
    | true =>
        rcases lem_qualified_outcomes_have_feasible_witness hq with ⟨θ, hfeas, _⟩
        exact False.elim (hunsat θ hfeas)
  · intro hu
    unfold auditStageEEmpiricalGate at hu
    cases hv : validateStageESpec tcb S with
    | some r => rw [hv] at hu; contradiction
    | none =>
        rw [hv] at hu
        dsimp only at hu
        cases b_any with
        | underdeterminedTwin tw =>
            by_cases hc : checkUnderdeterminedBundle S tw = true
            · unfold checkUnderdeterminedBundle at hc
              simp only [Bool.and_eq_true, lem_checkFeasibleParameter_iff] at hc
              exact hunsat tw.theta1 hc.1.2
            · simp [hc] at hu
        | emptyPrior ec =>
            by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;> simp [hc] at hu
        | fullPointQualified rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkFullPointCore S rc lp optT <;> simp [hp, hc] at hu
        | queryOnlyQualified rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkQueryOnlyCore S rc lp optT <;> simp [hp, hc] at hu
        | activeDoQualified r1 r2 rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkActiveDoCore S r1 r2 rc lp optT <;> simp [hp, hc] at hu
        | canonicalIV3Qualified rc lp =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkCanonicalIV3Core S rc lp <;> simp [hp, hc] at hu
        | empiricalFarkas fc =>
            by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true <;>
              simp [hc] at hu
        | holdoutDisjoint hcGen =>
            by_cases hc : checkHoldoutDisjointBundle S hcGen = true <;> simp [hc] at hu
        | confoundingTwin tc =>
            by_cases hc : checkConfoundingBundle S tc = true <;> simp [hc] at hu

/-- Target Theorem `thm_stageE_underdetermined_blocks_qualified`:
    Whenever `auditStageEEmpiricalGate tcb S bundle = .verifiedUnderdeterminedCompatibility`,
    NO certificate bundle `b_any` can claim `.verifiedConditionallyEmpiricallyQualified`,
    `.verifiedQueryConditionallyQualified`, `.verifiedActiveDoConditionallyQualified`,
    or `.verifiedEmpiricalFarkasFalsification`! -/
theorem thm_stageE_underdetermined_blocks_qualified
    (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (bundle : StageECertBundleQ0 S)
    (haud : auditStageEEmpiricalGate tcb S bundle = .verifiedUnderdeterminedCompatibility) :
    (∃ θ1 θ2 : VecQ0 S.design.p,
      θ1 ≠ θ2 ∧
      InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ1 ∧
      InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ2 ∧
      S.design.predict θ1 = S.design.predict θ2 ∧
      dotVec S.cQuery θ1 ≠ dotVec S.cQuery θ2) ∧
    (∀ b_any : StageECertBundleQ0 S,
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedConditionallyEmpiricallyQualified ∧
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedQueryConditionallyQualified ∧
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedActiveDoConditionallyQualified ∧
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedEmpiricalFarkasFalsification) := by
  have htw_prop : ∃ θ1 θ2 : VecQ0 S.design.p,
      θ1 ≠ θ2 ∧
      InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ1 ∧
      InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ2 ∧
      S.design.predict θ1 = S.design.predict θ2 ∧
      dotVec S.cQuery θ1 ≠ dotVec S.cQuery θ2 := by
    unfold auditStageEEmpiricalGate at haud
    cases hv : validateStageESpec tcb S with
    | some r => rw [hv] at haud; contradiction
    | none =>
        rw [hv] at haud
        dsimp only at haud
        cases bundle with
        | underdeterminedTwin tw =>
            by_cases hc : checkUnderdeterminedBundle S tw = true
            · unfold checkUnderdeterminedBundle at hc
              simp only [Bool.and_eq_true, lem_checkFeasibleParameter_iff] at hc
              rcases thm_twin_witness_blocks_query_identifiability S.design S.cQuery tw hc.1.1 with
                ⟨hne, _, _, hpred, hq_ne, _, _⟩
              exact ⟨tw.theta1, tw.theta2, hne, hc.1.2, hc.2, hpred, hq_ne⟩
            · simp [hc] at haud
        | emptyPrior ec =>
            by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;> simp [hc] at haud
        | fullPointQualified rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkFullPointCore S rc lp optT <;> simp [hp, hc] at haud
        | queryOnlyQualified rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkQueryOnlyCore S rc lp optT <;> simp [hp, hc] at haud
        | activeDoQualified r1 r2 rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkActiveDoCore S r1 r2 rc lp optT <;> simp [hp, hc] at haud
        | canonicalIV3Qualified rc lp =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkCanonicalIV3Core S rc lp <;> simp [hp, hc] at haud
        | empiricalFarkas fc =>
            by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true <;>
              simp [hc] at haud
        | holdoutDisjoint hcGen =>
            by_cases hc : checkHoldoutDisjointBundle S hcGen = true <;> simp [hc] at haud
        | confoundingTwin tc =>
            by_cases hc : checkConfoundingBundle S tc = true <;> simp [hc] at haud
  rcases htw_prop with ⟨θ1, θ2, hne, hf1, hf2, hpred, hq_ne⟩
  refine ⟨⟨θ1, θ2, hne, hf1, hf2, hpred, hq_ne⟩, fun b_any => ⟨?_, ?_, ?_, ?_⟩⟩
  · intro hfull
    have hinj := (thm_stageE_conditionally_qualified_sound tcb S b_any hfull).2.2.2.2.2.1
    exact hne (hinj θ1 θ2 hpred)
  · intro hq_only
    unfold auditStageEEmpiricalGate at hq_only
    cases hv : validateStageESpec tcb S with
    | some r => rw [hv] at hq_only; contradiction
    | none =>
        rw [hv] at hq_only
        dsimp only at hq_only
        cases b_any with
        | queryOnlyQualified rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S with
            | false => simp [hp] at hq_only
            | true =>
                simp only [hp, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hq_only
                cases hc : checkQueryOnlyCore S rc lp optT with
                | false => simp [hc] at hq_only
                | true =>
                    unfold checkQueryOnlyCore at hc
                    simp only [Bool.and_eq_true] at hc
                    have hsid := thm_structural_query_identifiable_of_orth_kernel
                      S.design rc S.cQuery hc.1.1.1.2
                    exact hq_ne (hsid θ1 θ2 hpred)
        | emptyPrior ec =>
            by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;> simp [hc] at hq_only
        | fullPointQualified rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkFullPointCore S rc lp optT <;> simp [hp, hc] at hq_only
        | activeDoQualified r1 r2 rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkActiveDoCore S r1 r2 rc lp optT <;> simp [hp, hc] at hq_only
        | canonicalIV3Qualified rc lp =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkCanonicalIV3Core S rc lp <;> simp [hp, hc] at hq_only
        | underdeterminedTwin tw =>
            by_cases hc : checkUnderdeterminedBundle S tw = true <;> simp [hc] at hq_only
        | empiricalFarkas fc =>
            by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true <;>
              simp [hc] at hq_only
        | holdoutDisjoint hcGen =>
            by_cases hc : checkHoldoutDisjointBundle S hcGen = true <;> simp [hc] at hq_only
        | confoundingTwin tc =>
            by_cases hc : checkConfoundingBundle S tc = true <;> simp [hc] at hq_only
  · intro hact
    have hinj := (thm_stageE_active_do_qualified_sound tcb S b_any hact).2.2.2.1
    exact hne (hinj θ1 θ2 hpred)
  · intro hfark
    exact (thm_stageE_farkas_falsified_sound_and_exclusive tcb S b_any hfark).2 bundle |>.2 haud

/-- Target Theorem `thm_stageE_holdout_falsified_sound_and_exclusive`:
    Whenever `auditStageEEmpiricalGate tcb S bundle = .verifiedHoldoutExtrapolationFalsified`:
      1. Calibration is feasible (`∃ θ_cal ∈ Θ_feas(cal)`), AND
      2. Calibration and holdout feasible sets are disjoint, so ALL FOUR positive `*Qualified`
         outcomes AND `.verifiedEmpiricalFarkasFalsification` are impossible for EVERY `b_any`! -/
theorem thm_stageE_holdout_falsified_sound_and_exclusive
    (tcb : ExternalEmpiricalTrustCtxQ0) (S : StageESpecQ0)
    (bundle : StageECertBundleQ0 S)
    (haud : auditStageEEmpiricalGate tcb S bundle = .verifiedHoldoutExtrapolationFalsified) :
    (∃ θ_cal : VecQ0 S.design.p,
      InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ_cal) ∧
    (∀ b_any : StageECertBundleQ0 S,
      isPositivelyQualifiedOutcome (auditStageEEmpiricalGate tcb S b_any) = false ∧
      auditStageEEmpiricalGate tcb S b_any ≠ .verifiedEmpiricalFarkasFalsification) := by
  have hcore : (∃ H : HoldoutDatasetSpecQ0 S.design.thetaCtx,
      S.optHoldout = some H ∧
      (∃ θ_cal : VecQ0 S.design.p,
        InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ_cal) ∧
      ∀ θ : VecQ0 S.design.p,
        ¬ (InFeasibleParameterSet S.design S.anchor.yObs S.anchor.eps θ ∧
           InFeasibleParameterSet H.toDesign H.yHold H.epsHold θ)) := by
    unfold auditStageEEmpiricalGate at haud
    cases hv : validateStageESpec tcb S with
    | some r => rw [hv] at haud; contradiction
    | none =>
        rw [hv] at haud
        dsimp only at haud
        cases bundle with
        | holdoutDisjoint hcGen =>
            by_cases hc : checkHoldoutDisjointBundle S hcGen = true
            · exact lem_checkHoldoutDisjointBundle_sound S hcGen hc
            · simp [hc] at haud
        | emptyPrior ec =>
            by_cases hc : checkEmptyOverlapCert S.design.thetaCtx ec = true <;> simp [hc] at haud
        | fullPointQualified rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkFullPointCore S rc lp optT <;> simp [hp, hc] at haud
        | queryOnlyQualified rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkQueryOnlyCore S rc lp optT <;> simp [hp, hc] at haud
        | activeDoQualified r1 r2 rc lp optT =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkActiveDoCore S r1 r2 rc lp optT <;> simp [hp, hc] at haud
        | canonicalIV3Qualified rc lp =>
            cases hp : checkEmpiricalQualificationProvenance tcb S <;>
            cases hc : checkCanonicalIV3Core S rc lp <;> simp [hp, hc] at haud
        | underdeterminedTwin tw =>
            by_cases hc : checkUnderdeterminedBundle S tw = true <;> simp [hc] at haud
        | empiricalFarkas fc =>
            by_cases hc : checkEmpiricalFalsificationCert S.design S.anchor.yObs S.anchor.eps fc = true <;>
              simp [hc] at haud
        | confoundingTwin tc =>
            by_cases hc : checkConfoundingBundle S tc = true <;> simp [hc] at haud
  rcases hcore with ⟨H, hOpt, ⟨θ_cal, hcal_f⟩, hdisj⟩
  refine ⟨⟨θ_cal, hcal_f⟩, fun b_any => ⟨?_, ?_⟩⟩
  · cases hq : isPositivelyQualifiedOutcome (auditStageEEmpiricalGate tcb S b_any) with
    | false => rfl
    | true =>
        rcases lem_qualified_outcomes_have_feasible_witness hq with ⟨θ, hf_cal, hf_hold_b⟩
        rw [hOpt] at hf_hold_b
        dsimp [checkHoldoutPointFeasible] at hf_hold_b
        have hf_hold := (lem_checkFeasibleParameter_iff _ _ _ _).mp hf_hold_b
        exact False.elim (hdisj θ ⟨hf_cal, hf_hold⟩)
  · intro hfark
    have hunsat := (thm_stageE_farkas_falsified_sound_and_exclusive tcb S b_any hfark).1
    exact hunsat θ_cal hcal_f

end GrandZero.StageE
