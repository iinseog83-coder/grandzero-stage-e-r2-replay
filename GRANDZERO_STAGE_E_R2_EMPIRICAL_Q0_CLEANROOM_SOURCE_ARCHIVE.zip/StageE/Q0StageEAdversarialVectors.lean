/-
  GRANDZERO Ω — Stage E-R2 (Identifiability, Bounded-Error Set-Membership,
                            Surgical SEM Interventions & Conditional Empirical Qualification Gate)
  Module E-5 (R2): Q0StageEAdversarialVectors.lean
  Scope:
    Mechanized formal proofs (`0 sorry`) for all 18 Stage E-R2 adversarial sub-vectors
    (`TE-01 ~ TE-08d`) binding `Tribunal F-E01 ~ F-E08 Dual-Lock`:
      - `TE-01 ~ TE-07c`: All 14 foundational vectors upgraded to `R2` pre-committed calibration
        records (`TE-04b` routed to dedicated `.verifiedActiveDoConditionallyQualified`).
      - `TE-08a`: `F-E06` Unattested `(1, 0, 0)` Qualification Counterexample & Unattested Holdout Block.
      - `TE-08b`: `F-E07 & F-E08 Lock 2` Passive-as-Active Protocol Smuggling, Clamp Schedule Mismatch,
        and Degenerate Identical-Clamp Rejection.
      - `TE-08c`: `F-E07 & F-E08 Lock 2A/2B` Confounded Zero-Effect SEM `M₂` Rejected + Universal
        `∀ b ∈ ℚ` Refutation across Both Constant-Intercept (Domain A) and Channel-Calibrated (Domain B) Models.
      - `TE-08d`: `F-E08 Lock 1` Proposer Offset-Laundering (`d₀ = [1, 2]`), Tampered `d0Calibrated`,
        and Post-Hoc Calibration Sequence (`calSeq ≥ obsSeq`) Deterministically Blocked.
-/

import StageE.Q0ConditionalEmpiricalQualificationGate

namespace GrandZero.StageE

open GrandZero.StageA
open GrandZero.StageB
open GrandZero.StageC
open GrandZero.StageD

/-! ### Shared Physical Units & TCB Pre-Committed Provenance Registry (`F-E05 ~ F-E08 Lock 1`) -/

def uStiff   : UnitSpecQ0 := { dim := { M := 1, T := -2 }, kind := .canonical }
def uForce   : UnitSpecQ0 := { dim := { L := 1, M := 1, T := -2 }, kind := .canonical }
def uMass    : UnitSpecQ0 := { dim := { M := 1 }, kind := .canonical }
def uInvMass : UnitSpecQ0 := { dim := { M := -1 }, kind := .canonical }

def shaTe01     : String := "a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90"
def shaTe01Cal  : String := "1111222233334444555566667777888899990000aaaabbbbccccddddeeeeffff"
def shaTe01Hold : String := "aaaa1111bbbb2222cccc3333dddd4444eeee5555ffff66660000777788889999"
def shaTe02     : String := "b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90a1"
def shaTe02Cal  : String := "222233334444555566667777888899990000aaaabbbbccccddddeeeeffff1111"
def shaTe04b    : String := "c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2"
def shaTe04bCal : String := "33334444555566667777888899990000aaaabbbbccccddddeeeeffff11112222"
def shaTe08bObs : String := "e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4"
def shaTe04c    : String := "d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3"
def shaTe04cCal : String := "4444555566667777888899990000aaaabbbbccccddddeeeeffff111122223333"

def stageE_tcb : ExternalEmpiricalTrustCtxQ0 :=
  { sysModelAuth := AuthorityVecQ0.formalOnly
    attestedRecords :=
      [ { datasetId              := "GZ-CAL-HOOKE-2026-01"
          payloadSha256Hex       := shaTe01
          calibrationCertId      := "NIST-FORCE-CAL-01"
          d0CalibrationSha256Hex := shaTe01Cal
          calSeq                 := 10
          obsSeq                 := 20
          attesterId             := "EXT-METROLOGY-LAB-A"
          regimeSpec             := .passiveObservational
          obsVars                := [uForce, uForce]
          d0CalibratedList       := [3, 3]
          yObsList               := [18, 28]
          epsList                := [1, 1] },
        { datasetId              := "GZ-HOLD-HOOKE-2026-01H"
          payloadSha256Hex       := shaTe01Hold
          calibrationCertId      := "NIST-FORCE-CAL-01"
          d0CalibrationSha256Hex := shaTe01Cal
          calSeq                 := 10
          obsSeq                 := 30
          attesterId             := "EXT-METROLOGY-LAB-A"
          regimeSpec             := .passiveObservational
          obsVars                := [uForce]
          d0CalibratedList       := [3]
          yObsList               := [38]
          epsList                := [1] },
        { datasetId              := "GZ-CAL-SUM-2026-02"
          payloadSha256Hex       := shaTe02
          calibrationCertId      := "NIST-COND-CAL-02"
          d0CalibrationSha256Hex := shaTe02Cal
          calSeq                 := 11
          obsSeq                 := 21
          attesterId             := "EXT-METROLOGY-LAB-A"
          regimeSpec             := .passiveObservational
          obsVars                := [UnitSpecQ0.unitless]
          d0CalibratedList       := [2]
          yObsList               := [12]
          epsList                := [1] },
        { datasetId              := "GZ-DO-CLAMP-2026-04B"
          payloadSha256Hex       := shaTe04b
          calibrationCertId      := "LAB-SURGICAL-CLAMP-04"
          d0CalibrationSha256Hex := shaTe04bCal
          calSeq                 := 12
          obsSeq                 := 22
          attesterId             := "EXT-INTERVENTION-LAB-B"
          regimeSpec             := .activeSurgicalClamp 0 1 [1, 2]
          obsVars                := [UnitSpecQ0.unitless, UnitSpecQ0.unitless]
          d0CalibratedList       := [0, 0]
          yObsList               := [1, 2]
          epsList                := [1 / 4, 1 / 4] },
        { datasetId              := "GZ-OBS-PASSIVE-2026-08B"
          payloadSha256Hex       := shaTe08bObs
          calibrationCertId      := "LAB-PASSIVE-SENSOR-08B"
          d0CalibrationSha256Hex := shaTe04bCal
          calSeq                 := 12
          obsSeq                 := 22
          attesterId             := "EXT-INTERVENTION-LAB-B"
          regimeSpec             := .passiveObservational
          obsVars                := [UnitSpecQ0.unitless, UnitSpecQ0.unitless]
          d0CalibratedList       := [0, 0]
          yObsList               := [1, 2]
          epsList                := [1 / 4, 1 / 4] },
        { datasetId              := "GZ-IV3-COVMOM-2026-04C"
          payloadSha256Hex       := shaTe04c
          calibrationCertId      := "LAB-IV3-MOMENT-04C"
          d0CalibrationSha256Hex := shaTe04cCal
          calSeq                 := 15
          obsSeq                 := 25
          attesterId             := "EXT-ECONOMETRICS-AUDIT-C"
          regimeSpec             := .passiveObservational
          obsVars                := [UnitSpecQ0.unitless]
          d0CalibratedList       := [0]
          yObsList               := [6]
          epsList                := [1 / 2] } ] }

/-! ### Vector `TE-01`: Full-Rank Affine Calibration (`d₀ = [3, 3]`, `F-E01, F-E02, F-E05, F-E06, F-E08`) -/

def te01_ctx : ContextQ0 :=
  { vars   := [uStiff, uForce]
    hyps   := []
    guards := [.pos (.bvar 0)] }

def te01_design : AffineObservationDesignQ0 :=
  { thetaCtx := te01_ctx
    obsVars  := [uForce, uForce]
    Phi      := matOfLists 2 2 [[1, 1], [2, 1]]
    d0       := vecOfList 2 [3, 3]
    unitPhi  := fun _ j => if j.val == 0 then UnitSpecQ0.meter else UnitSpecQ0.unitless
    unitD0   := fun _ => uForce }

def te01_anchor : EmpiricalDatasetAnchorQ0 2 :=
  { claimedOrigin          := .externalCalibratedMeasurement
    datasetId              := "GZ-CAL-HOOKE-2026-01"
    payloadSha256Hex       := shaTe01
    calibrationCertId      := "NIST-FORCE-CAL-01"
    d0CalibrationSha256Hex := shaTe01Cal
    calSeq                 := 10
    obsSeq                 := 20
    attesterId             := "EXT-METROLOGY-LAB-A"
    regimeSpec             := .passiveObservational
    obsVars                := [uForce, uForce]
    d0Calibrated           := vecOfList 2 [3, 3]
    yObs                   := vecOfList 2 [18, 28]
    eps                    := vecOfList 2 [1, 1] }

def te01_holdoutAnchor : EmpiricalDatasetAnchorQ0 1 :=
  { claimedOrigin          := .externalCalibratedMeasurement
    datasetId              := "GZ-HOLD-HOOKE-2026-01H"
    payloadSha256Hex       := shaTe01Hold
    calibrationCertId      := "NIST-FORCE-CAL-01"
    d0CalibrationSha256Hex := shaTe01Cal
    calSeq                 := 10
    obsSeq                 := 30
    attesterId             := "EXT-METROLOGY-LAB-A"
    regimeSpec             := .passiveObservational
    obsVars                := [uForce]
    d0Calibrated           := vecOfList 1 [3]
    yObs                   := vecOfList 1 [38]
    eps                    := vecOfList 1 [1] }

def te01_holdout : HoldoutDatasetSpecQ0 te01_ctx :=
  { obsVars    := [uForce]
    Phi        := matOfLists 1 2 [[3, 1]]
    d0         := vecOfList 1 [3]
    unitPhi    := fun _ j => if j.val == 0 then UnitSpecQ0.meter else UnitSpecQ0.unitless
    unitD0     := fun _ => uForce
    anchorHold := te01_holdoutAnchor }

def te01_rc : RankNullityCertQ0 2 2 :=
  { r := 2
    k := 0
    U := idMat 2
    B := matOfLists 2 2 [[1, 1], [2, 1]]
    L := matOfLists 2 2 [[-1, 1], [2, -1]]
    K := fun _ j => j.elim0
    R := fun i _ => i.elim0 }

def te01_lpEnclosing : QueryEnclosingCertQ0 te01_design :=
  { thetaHat := vecOfList 2 [10, 5]
    domRows  := emptyDomainAffineBundle 2
    wLb      := vecOfList 4 [1, 0, 0, 1]
    wUb      := vecOfList 4 [0, 1, 1, 0] }

def te01_lpTight : TightQueryIntervalCertQ0 te01_design :=
  { enclosing := te01_lpEnclosing
    thetaMin  := vecOfList 2 [8, 8]
    thetaMax  := vecOfList 2 [12, 2] }

def te01_spec : StageESpecQ0 :=
  { design      := te01_design
    anchor      := te01_anchor
    cQuery      := vecOfList 2 [1, 0]
    causalMode  := .predictiveObservational
    optHoldout  := some te01_holdout
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalEmpirical }

def te01_bundle : StageECertBundleQ0 te01_spec :=
  .fullPointQualified te01_rc te01_lpEnclosing (some te01_lpTight)

theorem te01_affine_full_rank_qualified :
    te01_design.d0 ⟨0, by decide⟩ = 3 ∧
    verifyExternalProvenance stageE_tcb te01_anchor = true ∧
    verifyExternalProvenance stageE_tcb te01_holdoutAnchor = true ∧
    te01_lpEnclosing.qLb te01_anchor.yObs te01_anchor.eps = 8 ∧
    te01_lpEnclosing.qUb te01_anchor.yObs te01_anchor.eps = 12 ∧
    checkTightQueryIntervalCert te01_design te01_anchor.yObs te01_anchor.eps
      te01_spec.cQuery te01_lpTight = true ∧
    auditStageEEmpiricalGate stageE_tcb te01_spec te01_bundle =
      .verifiedConditionallyEmpiricallyQualified := by
  refine ⟨by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl⟩

/-! ### Vectors `TE-02a` & `TE-02b`: Collinear Sloppiness vs. Gauge-Invariant Query (`F-E02 & F-E03`) -/

def te02_ctx : ContextQ0 :=
  { vars   := [UnitSpecQ0.unitless, UnitSpecQ0.unitless]
    hyps   := []
    guards := [.pos (.bvar 0), .pos (.bvar 1)] }

def te02_design : AffineObservationDesignQ0 :=
  { thetaCtx := te02_ctx
    obsVars  := [UnitSpecQ0.unitless]
    Phi      := matOfLists 1 2 [[1, 1]]
    d0       := vecOfList 1 [2]
    unitPhi  := fun _ _ => UnitSpecQ0.unitless
    unitD0   := fun _ => UnitSpecQ0.unitless }

def te02_anchor : EmpiricalDatasetAnchorQ0 1 :=
  { claimedOrigin          := .externalCalibratedMeasurement
    datasetId              := "GZ-CAL-SUM-2026-02"
    payloadSha256Hex       := shaTe02
    calibrationCertId      := "NIST-COND-CAL-02"
    d0CalibrationSha256Hex := shaTe02Cal
    calSeq                 := 11
    obsSeq                 := 21
    attesterId             := "EXT-METROLOGY-LAB-A"
    regimeSpec             := .passiveObservational
    obsVars                := [UnitSpecQ0.unitless]
    d0Calibrated           := vecOfList 1 [2]
    yObs                   := vecOfList 1 [12]
    eps                    := vecOfList 1 [1] }

def te02_rc : RankNullityCertQ0 1 2 :=
  { r := 1
    k := 1
    U := matOfLists 2 1 [[1], [0]]
    B := matOfLists 1 1 [[1]]
    L := matOfLists 1 1 [[1]]
    K := matOfLists 2 1 [[-1], [1]]
    R := matOfLists 1 2 [[0, 1]] }

def te02a_spec : StageESpecQ0 :=
  { design      := te02_design
    anchor      := te02_anchor
    cQuery      := vecOfList 2 [1, 0]
    causalMode  := .predictiveObservational
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalOnly }

def te02a_twin : TwinUnidentifiableWitnessQ0 2 :=
  { theta1 := vecOfList 2 [4, 6]
    theta2 := vecOfList 2 [7, 3] }

def te02a_bundle : StageECertBundleQ0 te02a_spec :=
  .underdeterminedTwin te02a_twin

theorem te02a_collinear_parameter_underdetermined :
    auditStageEEmpiricalGate stageE_tcb te02a_spec te02a_bundle =
      .verifiedUnderdeterminedCompatibility ∧
    (∀ b_any : StageECertBundleQ0 te02a_spec,
      auditStageEEmpiricalGate stageE_tcb te02a_spec b_any ≠ .verifiedConditionallyEmpiricallyQualified ∧
      auditStageEEmpiricalGate stageE_tcb te02a_spec b_any ≠ .verifiedQueryConditionallyQualified ∧
      auditStageEEmpiricalGate stageE_tcb te02a_spec b_any ≠ .verifiedActiveDoConditionallyQualified ∧
      auditStageEEmpiricalGate stageE_tcb te02a_spec b_any ≠ .verifiedEmpiricalFarkasFalsification) := by
  have haud : auditStageEEmpiricalGate stageE_tcb te02a_spec te02a_bundle =
      .verifiedUnderdeterminedCompatibility := by
    with_unfolding_all rfl
  exact ⟨haud, (thm_stageE_underdetermined_blocks_qualified stageE_tcb te02a_spec te02a_bundle haud).2⟩

def te02b_cQuery : VecQ0 2 := vecOfList 2 [1, 1]

def te02b_lpEnclosing : QueryEnclosingCertQ0 te02_design :=
  { thetaHat := vecOfList 2 [5, 5]
    domRows  := emptyDomainAffineBundle 2
    wLb      := vecOfList 2 [0, 1]
    wUb      := vecOfList 2 [1, 0] }

def te02b_lpTight : TightQueryIntervalCertQ0 te02_design :=
  { enclosing := te02b_lpEnclosing
    thetaMin  := vecOfList 2 [4, 5]
    thetaMax  := vecOfList 2 [5, 6] }

def te02b_spec : StageESpecQ0 :=
  { design      := te02_design
    anchor      := te02_anchor
    cQuery      := te02b_cQuery
    causalMode  := .predictiveObservational
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalEmpirical }

def te02b_bundle : StageECertBundleQ0 te02b_spec :=
  .queryOnlyQualified te02_rc te02b_lpEnclosing (some te02b_lpTight)

theorem te02b_invariant_query_structural_vs_noisy_width :
    StructuralQueryIdentifiable te02_design te02b_cQuery ∧
    te02b_lpEnclosing.qLb te02_anchor.yObs te02_anchor.eps = 9 ∧
    te02b_lpEnclosing.qUb te02_anchor.yObs te02_anchor.eps = 11 ∧
    te02b_lpEnclosing.width te02_anchor.yObs te02_anchor.eps = 2 ∧
    0 < te02b_lpEnclosing.width te02_anchor.yObs te02_anchor.eps ∧
    auditStageEEmpiricalGate stageE_tcb te02b_spec te02b_bundle =
      .verifiedQueryConditionallyQualified := by
  have horth : checkQueryOrthogonalKernel te02_design te02_rc te02b_cQuery = true := by
    with_unfolding_all rfl
  have hsid := thm_structural_query_identifiable_of_orth_kernel te02_design te02_rc te02b_cQuery horth
  have hlb : te02b_lpEnclosing.qLb te02_anchor.yObs te02_anchor.eps = 9 := by with_unfolding_all rfl
  have hub : te02b_lpEnclosing.qUb te02_anchor.yObs te02_anchor.eps = 11 := by with_unfolding_all rfl
  have hw  : te02b_lpEnclosing.width te02_anchor.yObs te02_anchor.eps = 2 := by with_unfolding_all rfl
  have hpos : 0 < te02b_lpEnclosing.width te02_anchor.yObs te02_anchor.eps := by
    rw [hw]; decide
  exact ⟨hsid, hlb, hub, hw, hpos, by with_unfolding_all rfl⟩

/-! ### Vectors `TE-03a` & `TE-03b`: Direct & Guard-Augmented Farkas Falsification -/

def te03a_ctx : ContextQ0 :=
  { vars := [UnitSpecQ0.unitless], hyps := [], guards := [] }

def te03a_design : AffineObservationDesignQ0 :=
  { thetaCtx := te03a_ctx
    obsVars  := [UnitSpecQ0.unitless, UnitSpecQ0.unitless]
    Phi      := matOfLists 2 1 [[1], [1]]
    d0       := vecOfList 2 [1, 1]
    unitPhi  := fun _ _ => UnitSpecQ0.unitless
    unitD0   := fun _ => UnitSpecQ0.unitless }

def te03a_anchor : EmpiricalDatasetAnchorQ0 2 :=
  { claimedOrigin          := .unverifiedOrigin
    datasetId              := "TE03A-CONFLICT"
    payloadSha256Hex       := ""
    calibrationCertId      := ""
    d0CalibrationSha256Hex := ""
    calSeq                 := 0
    obsSeq                 := 0
    attesterId             := ""
    regimeSpec             := .passiveObservational
    obsVars                := [UnitSpecQ0.unitless, UnitSpecQ0.unitless]
    d0Calibrated           := vecOfList 2 [1, 1]
    yObs                   := vecOfList 2 [2, 8]
    eps                    := vecOfList 2 [1, 1] }

def te03a_spec : StageESpecQ0 :=
  { design      := te03a_design
    anchor      := te03a_anchor
    cQuery      := vecOfList 1 [1]
    causalMode  := .predictiveObservational
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalOnly }

def te03a_fc : EmpiricalFalsificationCertQ0 te03a_design :=
  { domRows := emptyDomainAffineBundle 1
    wDual   := vecOfList 4 [1, 0, 0, 1] }

def te03a_bundle : StageECertBundleQ0 te03a_spec :=
  .empiricalFarkas te03a_fc

theorem te03a_contradictory_measurements_falsified :
    auditStageEEmpiricalGate stageE_tcb te03a_spec te03a_bundle =
      .verifiedEmpiricalFarkasFalsification ∧
    (∀ θ : VecQ0 1, ¬ InFeasibleParameterSet te03a_design te03a_anchor.yObs te03a_anchor.eps θ) ∧
    (∀ b_any : StageECertBundleQ0 te03a_spec,
      isPositivelyQualifiedOutcome (auditStageEEmpiricalGate stageE_tcb te03a_spec b_any) = false ∧
      auditStageEEmpiricalGate stageE_tcb te03a_spec b_any ≠ .verifiedUnderdeterminedCompatibility) := by
  have haud : auditStageEEmpiricalGate stageE_tcb te03a_spec te03a_bundle =
      .verifiedEmpiricalFarkasFalsification := by
    with_unfolding_all rfl
  rcases thm_stageE_farkas_falsified_sound_and_exclusive stageE_tcb te03a_spec te03a_bundle haud with
    ⟨hunsat, hexcl⟩
  exact ⟨haud, hunsat, hexcl⟩

def te03b_ctx : ContextQ0 :=
  { vars   := [uMass]
    hyps   := []
    guards := [.pos (.bvar 0)] }

def te03b_design : AffineObservationDesignQ0 :=
  { thetaCtx := te03b_ctx
    obsVars  := [uMass]
    Phi      := matOfLists 1 1 [[1]]
    d0       := vecOfList 1 [0]
    unitPhi  := fun _ _ => UnitSpecQ0.unitless
    unitD0   := fun _ => uMass }

def te03b_anchor : EmpiricalDatasetAnchorQ0 1 :=
  { claimedOrigin          := .unverifiedOrigin
    datasetId              := "TE03B-NEG-MASS"
    payloadSha256Hex       := ""
    calibrationCertId      := ""
    d0CalibrationSha256Hex := ""
    calSeq                 := 0
    obsSeq                 := 0
    attesterId             := ""
    regimeSpec             := .passiveObservational
    obsVars                := [uMass]
    d0Calibrated           := vecOfList 1 [0]
    yObs                   := vecOfList 1 [-5]
    eps                    := vecOfList 1 [1] }

def te03b_posRowCert : NonnegCertQ0 :=
  { c0        := 0
    posTerms  := [{ weight := 1
                    weightUnit := uInvMass
                    expr := .bvar 0
                    proof := .fromStageA (.gActiveMem 0) }]
    nnegTerms := []
    eqTerms   := []
    eqProof   := .gprAstCert [.gRatLit, .gRatLit] [] }

def te03b_domBundle : DomainAffineBundleQ0 1 :=
  { qDom     := 1
    Gdom     := matOfLists 1 1 [[1]]
    g0       := vecOfList 1 [0]
    rowCerts := fun _ => te03b_posRowCert }

def te03b_spec : StageESpecQ0 :=
  { design      := te03b_design
    anchor      := te03b_anchor
    cQuery      := vecOfList 1 [1]
    causalMode  := .predictiveObservational
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalOnly }

def te03b_fc : EmpiricalFalsificationCertQ0 te03b_design :=
  { domRows := te03b_domBundle
    wDual   := vecOfList 3 [1, 0, 1] }

def te03b_bundle : StageECertBundleQ0 te03b_spec :=
  .empiricalFarkas te03b_fc

theorem te03b_physical_guard_vs_envelope_falsified :
    VecLe (matVec (boxMat te03b_design) (vecOfList 1 [-5]))
          (boxRhs te03b_design te03b_anchor.yObs te03b_anchor.eps) ∧
    auditStageEEmpiricalGate stageE_tcb te03b_spec te03b_bundle =
      .verifiedEmpiricalFarkasFalsification ∧
    (∀ θ : VecQ0 1, ¬ InFeasibleParameterSet te03b_design te03b_anchor.yObs te03b_anchor.eps θ) := by
  have hbox_alone : VecLe (matVec (boxMat te03b_design) (vecOfList 1 [-5]))
      (boxRhs te03b_design te03b_anchor.yObs te03b_anchor.eps) :=
    (lem_vecLeBool_iff _ _).mp (by with_unfolding_all rfl)
  have haud : auditStageEEmpiricalGate stageE_tcb te03b_spec te03b_bundle =
      .verifiedEmpiricalFarkasFalsification := by
    with_unfolding_all rfl
  exact ⟨hbox_alone, haud,
         (thm_stageE_farkas_falsified_sound_and_exclusive stageE_tcb te03b_spec te03b_bundle haud).1⟩

/-! ### Vectors `TE-04a`, `TE-04b`, `TE-04c`: Confounding vs. Active `do` (`R2`) vs. Canonical IV3 (`F-E04 ~ F-E08`) -/

def te04_M1 : LinearSEMQ0 2 :=
  { rNoise := 2
    B      := matOfLists 2 2 [[0, 0], [1, 0]]
    tau    := fun i => i.val
    S      := matOfLists 2 2 [[1, 0], [1, 1]]
    Lomega := matOfLists 2 2 [[1, 0], [0, 1]] }

def te04_M2 : LinearSEMQ0 2 :=
  { rNoise := 2
    B      := matOfLists 2 2 [[0, 0], [0, 0]]
    tau    := fun i => i.val
    S      := matOfLists 2 2 [[1, 0], [0, 1]]
    Lomega := matOfLists 2 2 [[1, 0], [1, 1]] }

def te04_sc1 : SurgicalDoCertQ0 2 :=
  { iDo := ⟨0, by decide⟩
    Sdo := matOfLists 2 2 [[1, 0], [1, 1]] }

def te04_sc2 : SurgicalDoCertQ0 2 :=
  { iDo := ⟨0, by decide⟩
    Sdo := matOfLists 2 2 [[1, 0], [0, 1]] }

def te04a_twinCert : ConfoundingTwinCertQ0 2 :=
  { M1      := te04_M1
    M2      := te04_M2
    sc1     := te04_sc1
    sc2     := te04_sc2
    iCause  := ⟨0, by decide⟩
    jTarget := ⟨1, by decide⟩ }

def te04b_ctx : ContextQ0 :=
  { vars := [UnitSpecQ0.unitless], hyps := [], guards := [] }

def te04b_design : AffineObservationDesignQ0 :=
  { thetaCtx := te04b_ctx
    obsVars  := [UnitSpecQ0.unitless, UnitSpecQ0.unitless]
    Phi      := matOfLists 2 1 [[1], [2]]
    d0       := vecOfList 2 [0, 0]
    unitPhi  := fun _ _ => UnitSpecQ0.unitless
    unitD0   := fun _ => UnitSpecQ0.unitless }

def te04b_anchor : EmpiricalDatasetAnchorQ0 2 :=
  { claimedOrigin          := .externalCalibratedMeasurement
    datasetId              := "GZ-DO-CLAMP-2026-04B"
    payloadSha256Hex       := shaTe04b
    calibrationCertId      := "LAB-SURGICAL-CLAMP-04"
    d0CalibrationSha256Hex := shaTe04bCal
    calSeq                 := 12
    obsSeq                 := 22
    attesterId             := "EXT-INTERVENTION-LAB-B"
    regimeSpec             := .activeSurgicalClamp 0 1 [1, 2]
    obsVars                := [UnitSpecQ0.unitless, UnitSpecQ0.unitless]
    d0Calibrated           := vecOfList 2 [0, 0]
    yObs                   := vecOfList 2 [1, 2]
    eps                    := vecOfList 2 [1 / 4, 1 / 4] }

def te04a_spec : StageESpecQ0 :=
  { design      := te04b_design
    anchor      := te04b_anchor
    cQuery      := vecOfList 1 [1]
    causalMode  := .interventionalPassiveClaim 2
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalOnly }

def te04a_bundle : StageECertBundleQ0 te04a_spec :=
  .confoundingTwin te04a_twinCert

theorem te04a_passive_confounding_obstruction :
    te04_M1.SigmaObs = te04_M2.SigmaObs ∧
    interventionalUnitEffect te04_sc1 ⟨1, by decide⟩ = 1 ∧
    interventionalUnitEffect te04_sc2 ⟨1, by decide⟩ = 0 ∧
    auditStageEEmpiricalGate stageE_tcb te04a_spec te04a_bundle =
      .verifiedConfoundingCausalObstruction := by
  have htw : checkConfoundingTwinCert te04a_twinCert = true := by with_unfolding_all rfl
  have hsig := (thm_confounding_twin_obs_eq_do_neq te04a_twinCert htw).2.2.1
  exact ⟨hsig, by with_unfolding_all rfl, by with_unfolding_all rfl, by with_unfolding_all rfl⟩

def te04b_rc : RankNullityCertQ0 2 1 :=
  { r := 1
    k := 0
    U := matOfLists 1 1 [[1]]
    B := matOfLists 2 1 [[1], [2]]
    L := matOfLists 1 2 [[1, 0]]
    K := fun _ j => j.elim0
    R := fun i _ => i.elim0 }

def te04b_lp : QueryEnclosingCertQ0 te04b_design :=
  { thetaHat := vecOfList 1 [1]
    domRows  := emptyDomainAffineBundle 1
    wLb      := vecOfList 4 [0, 0, 0, 1 / 2]
    wUb      := vecOfList 4 [0, 1 / 2, 0, 0] }

def te04b_spec : StageESpecQ0 :=
  { design      := te04b_design
    anchor      := te04b_anchor
    cQuery      := vecOfList 1 [1]
    causalMode  := .interventionalActiveDo 2 te04_M1 te04_sc1 ⟨1, by decide⟩
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalEmpirical }

def te04b_bundle : StageECertBundleQ0 te04b_spec :=
  .activeDoQualified ⟨0, by decide⟩ ⟨1, by decide⟩ te04b_rc te04b_lp none

theorem te04b_active_surgical_do_qualified :
    te04b_design.Phi ⟨0, by decide⟩ ⟨0, by decide⟩ ≠ te04b_design.Phi ⟨1, by decide⟩ ⟨0, by decide⟩ ∧
    auditStageEEmpiricalGate stageE_tcb te04b_spec te04b_bundle =
      .verifiedActiveDoConditionallyQualified := by
  refine ⟨by decide, by with_unfolding_all rfl⟩

def te04c_M3 : LinearSEMQ0 3 :=
  { rNoise := 3
    B      := matOfLists 3 3 [[0, 0, 0], [2, 0, 0], [0, 3, 0]]
    tau    := fun i => i.val
    S      := matOfLists 3 3 [[1, 0, 0], [2, 1, 0], [6, 3, 1]]
    Lomega := matOfLists 3 3 [[1, 0, 0], [0, 1, 1], [0, 0, 1]] }

def te04c_sc1 : SurgicalDoCertQ0 3 :=
  { iDo := ivIdx1
    Sdo := matOfLists 3 3 [[1, 0, 0], [0, 1, 0], [0, 3, 1]] }

def te04c_design : AffineObservationDesignQ0 :=
  { thetaCtx := te04b_ctx
    obsVars  := [UnitSpecQ0.unitless]
    Phi      := matOfLists 1 1 [[2]]
    d0       := vecOfList 1 [0]
    unitPhi  := fun _ _ => UnitSpecQ0.unitless
    unitD0   := fun _ => UnitSpecQ0.unitless }

def te04c_anchor : EmpiricalDatasetAnchorQ0 1 :=
  { claimedOrigin          := .externalCalibratedMeasurement
    datasetId              := "GZ-IV3-COVMOM-2026-04C"
    payloadSha256Hex       := shaTe04c
    calibrationCertId      := "LAB-IV3-MOMENT-04C"
    d0CalibrationSha256Hex := shaTe04cCal
    calSeq                 := 15
    obsSeq                 := 25
    attesterId             := "EXT-ECONOMETRICS-AUDIT-C"
    regimeSpec             := .passiveObservational
    obsVars                := [UnitSpecQ0.unitless]
    d0Calibrated           := vecOfList 1 [0]
    yObs                   := vecOfList 1 [6]
    eps                    := vecOfList 1 [1 / 2] }

def te04c_rc : RankNullityCertQ0 1 1 :=
  { r := 1
    k := 0
    U := matOfLists 1 1 [[1 / 2]]
    B := matOfLists 1 1 [[1]]
    L := matOfLists 1 1 [[1]]
    K := fun _ j => j.elim0
    R := fun i _ => i.elim0 }

def te04c_lp : QueryEnclosingCertQ0 te04c_design :=
  { thetaHat := vecOfList 1 [3]
    domRows  := emptyDomainAffineBundle 1
    wLb      := vecOfList 2 [0, 1 / 2]
    wUb      := vecOfList 2 [1 / 2, 0] }

def te04c_spec : StageESpecQ0 :=
  { design      := te04c_design
    anchor      := te04c_anchor
    cQuery      := vecOfList 1 [1]
    causalMode  := .canonicalRestrictedIV3 te04c_M3 te04c_sc1
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalEmpirical }

def te04c_bundle : StageECertBundleQ0 te04c_spec :=
  .canonicalIV3Qualified te04c_rc te04c_lp

def te04c_badExclusionM3 : LinearSEMQ0 3 :=
  { rNoise := 3
    B      := matOfLists 3 3 [[0, 0, 0], [2, 0, 0], [1, 3, 0]]
    tau    := fun i => i.val
    S      := matOfLists 3 3 [[1, 0, 0], [2, 1, 0], [7, 3, 1]]
    Lomega := matOfLists 3 3 [[1, 0, 0], [0, 1, 1], [0, 0, 1]] }

theorem te04c_canonical_iv3_wald_and_invalid_iv_blocked :
    te04c_M3.Omega ivIdx1 ivIdx2 = 1 ∧
    te04c_M3.SigmaObs ivIdx1 ivIdx2 / te04c_M3.SigmaObs ivIdx1 ivIdx1 = 19 / 6 ∧
    te04c_M3.SigmaObs ivIdx0 ivIdx2 / te04c_M3.SigmaObs ivIdx0 ivIdx1 = 3 ∧
    interventionalUnitEffect te04c_sc1 ivIdx2 = 3 ∧
    checkCanonicalIV3Assumptions te04c_badExclusionM3 te04c_sc1 = false ∧
    auditStageEEmpiricalGate stageE_tcb te04c_spec te04c_bundle =
      .verifiedCanonicalIVConditionallyQualified := by
  refine ⟨by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl⟩

/-! ### Vector `TE-05`: Calibration Fit vs. Out-of-Sample Holdout Falsification + `Stage D` Escape -/

def te05_designCal : AffineObservationDesignQ0 :=
  { thetaCtx := te04b_ctx
    obsVars  := [UnitSpecQ0.unitless]
    Phi      := matOfLists 1 1 [[1]]
    d0       := vecOfList 1 [0]
    unitPhi  := fun _ _ => UnitSpecQ0.unitless
    unitD0   := fun _ => UnitSpecQ0.unitless }

def te05_anchorCal : EmpiricalDatasetAnchorQ0 1 :=
  { claimedOrigin          := .unverifiedOrigin
    datasetId              := "TE05-CAL"
    payloadSha256Hex       := ""
    calibrationCertId      := ""
    d0CalibrationSha256Hex := ""
    calSeq                 := 0
    obsSeq                 := 0
    attesterId             := ""
    regimeSpec             := .passiveObservational
    obsVars                := [UnitSpecQ0.unitless]
    d0Calibrated           := vecOfList 1 [0]
    yObs                   := vecOfList 1 [2]
    eps                    := vecOfList 1 [1] }

def te05_anchorHold : EmpiricalDatasetAnchorQ0 1 :=
  { claimedOrigin          := .unverifiedOrigin
    datasetId              := "TE05-HOLD"
    payloadSha256Hex       := ""
    calibrationCertId      := ""
    d0CalibrationSha256Hex := ""
    calSeq                 := 0
    obsSeq                 := 0
    attesterId             := ""
    regimeSpec             := .passiveObservational
    obsVars                := [UnitSpecQ0.unitless]
    d0Calibrated           := vecOfList 1 [0]
    yObs                   := vecOfList 1 [20]
    eps                    := vecOfList 1 [1] }

def te05_holdout : HoldoutDatasetSpecQ0 te04b_ctx :=
  { obsVars    := [UnitSpecQ0.unitless]
    Phi        := matOfLists 1 1 [[4]]
    d0         := vecOfList 1 [0]
    unitPhi    := fun _ _ => UnitSpecQ0.unitless
    unitD0     := fun _ => UnitSpecQ0.unitless
    anchorHold := te05_anchorHold }

def te05_spec : StageESpecQ0 :=
  { design      := te05_designCal
    anchor      := te05_anchorCal
    cQuery      := vecOfList 1 [1]
    causalMode  := .predictiveObservational
    optHoldout  := some te05_holdout
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalOnly }

def te05_disjointCert : HoldoutDisjointCertQ0 te05_designCal te05_holdout.toDesign :=
  { thetaCal  := vecOfList 1 [2]
    domRows   := emptyDomainAffineBundle 1
    wDisjoint := vecOfList 4 [4, 0, 0, 1] }

def te05_bundle : StageECertBundleQ0 te05_spec :=
  .holdoutDisjoint (fun H hEq => by
    change some te05_holdout = some H at hEq
    injection hEq with hH
    subst hH
    exact te05_disjointCert)

theorem te05_calibration_fit_yet_holdout_falsified :
    auditStageEEmpiricalGate stageE_tcb te05_spec te05_bundle =
      .verifiedHoldoutExtrapolationFalsified ∧
    checkDynHoldoutResidualEscape td02_dyn td01_H [2, 0, 1, 1] 1 2 (1 / 2) = true ∧
    (∃ θ_cal : VecQ0 1, InFeasibleParameterSet te05_designCal te05_anchorCal.yObs te05_anchorCal.eps θ_cal) ∧
    (∀ b_any : StageECertBundleQ0 te05_spec,
      isPositivelyQualifiedOutcome (auditStageEEmpiricalGate stageE_tcb te05_spec b_any) = false ∧
      auditStageEEmpiricalGate stageE_tcb te05_spec b_any ≠ .verifiedEmpiricalFarkasFalsification) := by
  have haud : auditStageEEmpiricalGate stageE_tcb te05_spec te05_bundle =
      .verifiedHoldoutExtrapolationFalsified := by
    with_unfolding_all rfl
  have hdyn : checkDynHoldoutResidualEscape td02_dyn td01_H [2, 0, 1, 1] 1 2 (1 / 2) = true := by
    with_unfolding_all rfl
  rcases thm_stageE_holdout_falsified_sound_and_exclusive stageE_tcb te05_spec te05_bundle haud with
    ⟨hcal, hexcl⟩
  exact ⟨haud, hdyn, hcal, hexcl⟩

/-! ### Vector `TE-06`: Counterfeit Unattained Tight LP Certificate Rejected (`F-E02`) -/

def te06_forgedTight : TightQueryIntervalCertQ0 te01_design :=
  { enclosing := te01_lpEnclosing
    thetaMin  := vecOfList 2 [10, 5]   -- Forged! `q([10, 5]) = 10 ≠ 8 = qLb`
    thetaMax  := vecOfList 2 [12, 2] }

def te06_bundle : StageECertBundleQ0 te01_spec :=
  .fullPointQualified te01_rc te01_lpEnclosing (some te06_forgedTight)

theorem te06_forged_tight_lp_certificate_rejected :
    auditStageEEmpiricalGate stageE_tcb te01_spec te06_bundle =
      .rejectedInvalidCertificate := by
  with_unfolding_all rfl

/-! ### Vectors `TE-07a`, `TE-07b1`, `TE-07b2`, `TE-07c`: Unit, Synthetic, Provenance (`F-E05`) & `a_I` Gates -/

def te07a_ctx : ContextQ0 :=
  { vars := [UnitSpecQ0.energy], hyps := [], guards := [] }

def te07a_design : AffineObservationDesignQ0 :=
  { thetaCtx := te07a_ctx
    obsVars  := [UnitSpecQ0.torque]
    Phi      := matOfLists 1 1 [[1]]
    d0       := vecOfList 1 [0]
    unitPhi  := fun _ _ => UnitSpecQ0.unitless
    unitD0   := fun _ => UnitSpecQ0.torque }

def te07a_anchor : EmpiricalDatasetAnchorQ0 1 :=
  { claimedOrigin          := .unverifiedOrigin
    datasetId              := "TE07A-TORQUE-SMUGGLE"
    payloadSha256Hex       := ""
    calibrationCertId      := ""
    d0CalibrationSha256Hex := ""
    calSeq                 := 0
    obsSeq                 := 0
    attesterId             := ""
    regimeSpec             := .passiveObservational
    obsVars                := [UnitSpecQ0.torque]
    d0Calibrated           := vecOfList 1 [0]
    yObs                   := vecOfList 1 [10]
    eps                    := vecOfList 1 [1] }

def te07a_spec : StageESpecQ0 :=
  { design      := te07a_design
    anchor      := te07a_anchor
    cQuery      := vecOfList 1 [1]
    causalMode  := .predictiveObservational
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalOnly }

theorem te07a_torque_energy_sensor_smuggling_rejected :
    validateStageESpec stageE_tcb te07a_spec = some .illTypedObservation ∧
    ∀ bundle : StageECertBundleQ0 te07a_spec,
      auditStageEEmpiricalGate stageE_tcb te07a_spec bundle =
        .rejectedInvalidEmpiricalSpec .illTypedObservation := by
  have hv : validateStageESpec stageE_tcb te07a_spec = some .illTypedObservation := by
    with_unfolding_all rfl
  exact ⟨hv, thm_stageE_invalid_spec_universal_reject stageE_tcb te07a_spec .illTypedObservation hv⟩

def te07b1_syntheticAnchor : EmpiricalDatasetAnchorQ0 2 :=
  { te01_anchor with claimedOrigin := .syntheticSimulation }

def te07b1_spec : StageESpecQ0 :=
  { te01_spec with anchor := te07b1_syntheticAnchor }

theorem te07b1_synthetic_simulation_bootstrap_rejected :
    effectiveEmpiricalAuth stageE_tcb te07b1_syntheticAnchor = 0 ∧
    validateStageESpec stageE_tcb te07b1_spec = some .authorityEscalation ∧
    ∀ bundle : StageECertBundleQ0 te07b1_spec,
      auditStageEEmpiricalGate stageE_tcb te07b1_spec bundle =
        .rejectedInvalidEmpiricalSpec .authorityEscalation := by
  have heff : effectiveEmpiricalAuth stageE_tcb te07b1_syntheticAnchor = 0 := by
    with_unfolding_all rfl
  have hv : validateStageESpec stageE_tcb te07b1_spec = some .authorityEscalation := by
    with_unfolding_all rfl
  exact ⟨heff, hv, thm_stageE_invalid_spec_universal_reject stageE_tcb te07b1_spec .authorityEscalation hv⟩

def te07b2_forgedOriginAnchor : EmpiricalDatasetAnchorQ0 2 :=
  { te01_anchor with attesterId := "UNATTESTED-SELF-DECLARED-LAB" }

def te07b2_tamperedEpsAnchor : EmpiricalDatasetAnchorQ0 2 :=
  { te01_anchor with eps := vecOfList 2 [5, 5] }

def te07b2_spec : StageESpecQ0 :=
  { te01_spec with anchor := te07b2_forgedOriginAnchor }

theorem te07b2_forged_external_origin_and_tampered_eps_rejected :
    te07b2_forgedOriginAnchor.claimedOrigin = .externalCalibratedMeasurement ∧
    verifyExternalProvenance stageE_tcb te07b2_forgedOriginAnchor = false ∧
    verifyExternalProvenance stageE_tcb te07b2_tamperedEpsAnchor = false ∧
    effectiveEmpiricalAuth stageE_tcb te07b2_forgedOriginAnchor = 0 ∧
    validateStageESpec stageE_tcb te07b2_spec = some .authorityEscalation ∧
    ∀ bundle : StageECertBundleQ0 te07b2_spec,
      auditStageEEmpiricalGate stageE_tcb te07b2_spec bundle =
        .rejectedInvalidEmpiricalSpec .authorityEscalation := by
  have hv : validateStageESpec stageE_tcb te07b2_spec = some .authorityEscalation := by
    with_unfolding_all rfl
  refine ⟨rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          hv,
          thm_stageE_invalid_spec_universal_reject stageE_tcb te07b2_spec .authorityEscalation hv⟩

def te07c_spec : StageESpecQ0 :=
  { te01_spec with claimedAuth := { formal := 1, empirical := 1, institutional := 1 } }

theorem te07c_institutional_authority_escalation_rejected :
    verifyExternalProvenance stageE_tcb te07c_spec.anchor = true ∧
    validateStageESpec stageE_tcb te07c_spec = some .authorityEscalation ∧
    ∀ bundle : StageECertBundleQ0 te07c_spec,
      auditStageEEmpiricalGate stageE_tcb te07c_spec bundle =
        .rejectedInvalidEmpiricalSpec .authorityEscalation := by
  have hv : validateStageESpec stageE_tcb te07c_spec = some .authorityEscalation := by
    with_unfolding_all rfl
  refine ⟨by with_unfolding_all rfl,
          hv,
          thm_stageE_invalid_spec_universal_reject stageE_tcb te07c_spec .authorityEscalation hv⟩

/-! ### Vectors `TE-08a ~ TE-08d`: Orthogonal `F-E06`, `F-E07` & `F-E08 Dual-Lock` Adversarial Suite -/

/-- `TE-08a` (`Tribunal F-E06` Exact Counterexample):
    `TE-01`'s exact design and tight LP certificates submitted with `claimedAuth = (1, 0, 0)`
    against `empty_tcb` (`attestedRecords = []`), plus unattested holdout smuggling check. -/
def te08a_emptyTcb : ExternalEmpiricalTrustCtxQ0 :=
  { sysModelAuth    := AuthorityVecQ0.formalOnly
    attestedRecords := [] }

def te08a_spec : StageESpecQ0 :=
  { te01_spec with claimedAuth := AuthorityVecQ0.formalOnly }

def te08a_bundle : StageECertBundleQ0 te08a_spec :=
  .fullPointQualified te01_rc te01_lpEnclosing (some te01_lpTight)

def te08a_unattestedHoldout : HoldoutDatasetSpecQ0 te01_ctx :=
  { te01_holdout with anchorHold := { te01_holdoutAnchor with attesterId := "UNATTESTED-HOLD-LAB" } }

def te08a_badHoldoutSpec : StageESpecQ0 :=
  { te01_spec with optHoldout := some te08a_unattestedHoldout }

def te08a_badHoldoutBundle : StageECertBundleQ0 te08a_badHoldoutSpec :=
  .fullPointQualified te01_rc te01_lpEnclosing (some te01_lpTight)

theorem te08a_unattested_100_qualification_blocked :
    validateStageESpec te08a_emptyTcb te08a_spec = none ∧
    auditStageEEmpiricalGate te08a_emptyTcb te08a_spec te08a_bundle =
      .rejectedUnattestedEmpiricalQualification ∧
    auditStageEEmpiricalGate stageE_tcb te08a_badHoldoutSpec te08a_badHoldoutBundle =
      .rejectedUnattestedEmpiricalQualification ∧
    (∀ b_any : StageECertBundleQ0 te08a_spec,
      isPositivelyQualifiedOutcome (auditStageEEmpiricalGate te08a_emptyTcb te08a_spec b_any) = false) := by
  have hunatt : verifyExternalProvenance te08a_emptyTcb te08a_spec.anchor = false := by
    with_unfolding_all rfl
  refine ⟨by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          fun b_any => (thm_empty_tcb_blocks_all_qualified_outcomes te08a_emptyTcb te08a_spec hunatt b_any).1⟩

/-- `TE-08b` (`Tribunal F-E07 & F-E08 Lock 2`):
    Passive observational data smuggled as active `do`, mismatched clamp schedule `Φ ≠ u`,
    and degenerate identical clamp indices `r1 = r2` (`u_{r1} = u_{r2}`). -/
def te08b_passiveAnchor : EmpiricalDatasetAnchorQ0 2 :=
  { claimedOrigin          := .externalCalibratedMeasurement
    datasetId              := "GZ-OBS-PASSIVE-2026-08B"
    payloadSha256Hex       := shaTe08bObs
    calibrationCertId      := "LAB-PASSIVE-SENSOR-08B"
    d0CalibrationSha256Hex := shaTe04bCal
    calSeq                 := 12
    obsSeq                 := 22
    attesterId             := "EXT-INTERVENTION-LAB-B"
    regimeSpec             := .passiveObservational
    obsVars                := [UnitSpecQ0.unitless, UnitSpecQ0.unitless]
    d0Calibrated           := vecOfList 2 [0, 0]
    yObs                   := vecOfList 2 [1, 2]
    eps                    := vecOfList 2 [1 / 4, 1 / 4] }

def te08b_spec : StageESpecQ0 :=
  { te04b_spec with anchor := te08b_passiveAnchor }

def te08b_bundle : StageECertBundleQ0 te08b_spec :=
  .activeDoQualified ⟨0, by decide⟩ ⟨1, by decide⟩ te04b_rc te04b_lp none

def te08b_mismatchDesign : AffineObservationDesignQ0 :=
  { te04b_design with Phi := matOfLists 2 1 [[3], [2]] }

def te08b_mismatchLp : QueryEnclosingCertQ0 te08b_mismatchDesign :=
  { thetaHat := vecOfList 1 [1]
    domRows  := emptyDomainAffineBundle 1
    wLb      := vecOfList 4 [0, 0, 0, 1 / 2]
    wUb      := vecOfList 4 [0, 1 / 2, 0, 0] }

def te08b_mismatchSpec : StageESpecQ0 :=
  { design      := te08b_mismatchDesign
    anchor      := te04b_anchor
    cQuery      := vecOfList 1 [1]
    causalMode  := .interventionalActiveDo 2 te04_M1 te04_sc1 ⟨1, by decide⟩
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalEmpirical }

def te08b_mismatchBundle : StageECertBundleQ0 te08b_mismatchSpec :=
  .activeDoQualified ⟨0, by decide⟩ ⟨1, by decide⟩ te04b_rc te08b_mismatchLp none

def te08b_degenerateSameClampBundle : StageECertBundleQ0 te04b_spec :=
  .activeDoQualified ⟨0, by decide⟩ ⟨0, by decide⟩ te04b_rc te04b_lp none

theorem te08b_passive_as_active_and_degenerate_clamp_rejected :
    verifyExternalProvenance stageE_tcb te08b_passiveAnchor = true ∧
    auditStageEEmpiricalGate stageE_tcb te08b_spec te08b_bundle =
      .rejectedInvalidCertificate ∧
    auditStageEEmpiricalGate stageE_tcb te08b_mismatchSpec te08b_mismatchBundle =
      .rejectedInvalidCertificate ∧
    auditStageEEmpiricalGate stageE_tcb te04b_spec te08b_degenerateSameClampBundle =
      .rejectedInvalidCertificate := by
  refine ⟨by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl,
          by with_unfolding_all rfl⟩

/-- `TE-08c` (`Tribunal F-E07 & F-E08 Lock 2A / 2B`):
    Confounded zero-effect SEM `te04_M2` (`β_SEM = 0`) rejected on active clamp data `u = [1, 2], y = [1, 2]`,
    PLUS universal `∀ b ∈ ℚ` differential refutation in BOTH Constant-Intercept Domain A and
    Channel-Specific Calibrated Domain B (`d₀^cal = [10, -5]`, `y^obs = [11, -3]`). -/
def te08c_spec : StageESpecQ0 :=
  { te04b_spec with causalMode := .interventionalActiveDo 2 te04_M2 te04_sc2 ⟨1, by decide⟩ }

def te08c_bundle : StageECertBundleQ0 te08c_spec :=
  .activeDoQualified ⟨0, by decide⟩ ⟨1, by decide⟩ te04b_rc te04b_lp none

def te08c_d0Chan   : VecQ0 2 := vecOfList 2 [10, -5]
def te08c_yObsChan : VecQ0 2 := vecOfList 2 [11, -3]

def te08c_channelCalDesign : AffineObservationDesignQ0 :=
  { te04b_design with d0 := te08c_d0Chan }

theorem te08c_confounded_sem_refuted_and_all_const_offsets_blocked :
    auditStageEEmpiricalGate stageE_tcb te08c_spec te08c_bundle =
      .rejectedInvalidCertificate ∧
    (∀ b : Rat,
      ¬ InResidualEnvelope (constOffsetDesign te04b_design b) te04b_anchor.yObs te04b_anchor.eps
          (fun _ => interventionalUnitEffect te04_sc2 ⟨1, by decide⟩)) ∧
    (∀ b : Rat,
      ¬ InResidualEnvelope (shiftedCalibratedDesign te08c_channelCalDesign te08c_d0Chan b)
          te08c_yObsChan te04b_anchor.eps
          (fun _ => interventionalUnitEffect te04_sc2 ⟨1, by decide⟩)) := by
  have hrefA : checkConstantOffsetDiffRefutation te04b_design rfl
      ⟨0, by decide⟩ ⟨1, by decide⟩ te04b_anchor.yObs te04b_anchor.eps
      (interventionalUnitEffect te04_sc2 ⟨1, by decide⟩) = true := by
    with_unfolding_all rfl
  have hrefB : checkCalibratedOffsetDiffRefutation te08c_channelCalDesign rfl
      ⟨0, by decide⟩ ⟨1, by decide⟩ te08c_d0Chan te08c_yObsChan te04b_anchor.eps
      (interventionalUnitEffect te04_sc2 ⟨1, by decide⟩) = true := by
    with_unfolding_all rfl
  have hA := (thm_active_do_diff_refutes_all_constant_offsets te04b_design rfl
    ⟨0, by decide⟩ ⟨1, by decide⟩ te04b_anchor.yObs te04b_anchor.eps
    (interventionalUnitEffect te04_sc2 ⟨1, by decide⟩) hrefA).2
  have hB := (thm_active_do_calibrated_diff_refutes_all_uniform_drifts te08c_channelCalDesign rfl
    ⟨0, by decide⟩ ⟨1, by decide⟩ te08c_d0Chan te08c_yObsChan te04b_anchor.eps
    (interventionalUnitEffect te04_sc2 ⟨1, by decide⟩) hrefB).2.1
  exact ⟨by with_unfolding_all rfl, fun b => (hA b).1, fun b => (hB b).1⟩

/-- `TE-08d` (`Tribunal F-E08 Lock 1`):
    Proposer attempts offset laundering `d₀ := [1, 2]` so `u_r · 0 + d_{0,r} = yObs_r` (`0` residual!)
    to disguise `β_SEM(M₂) = 0`, OR mutates `anchor.d0Calibrated := [1, 2]`, OR submits post-hoc
    calibration (`calSeq = 25 ≥ obsSeq = 20`), OR injects `d₀ = [6]` into `canonicalRestrictedIV3`. -/
def te08d_launderedDesign : AffineObservationDesignQ0 :=
  { te04b_design with d0 := vecOfList 2 [1, 2] }

def te08d_launderedLp : QueryEnclosingCertQ0 te08d_launderedDesign :=
  { thetaHat := vecOfList 1 [0]
    domRows  := emptyDomainAffineBundle 1
    wLb      := vecOfList 4 [0, 0, 0, 1 / 2]
    wUb      := vecOfList 4 [0, 1 / 2, 0, 0] }

def te08d_spec : StageESpecQ0 :=
  { design      := te08d_launderedDesign
    anchor      := te04b_anchor
    cQuery      := vecOfList 1 [1]
    causalMode  := .interventionalActiveDo 2 te04_M2 te04_sc2 ⟨1, by decide⟩
    optHoldout  := none
    modelAuth   := AuthorityVecQ0.formalOnly
    claimedAuth := AuthorityVecQ0.formalEmpirical }

def te08d_bundle : StageECertBundleQ0 te08d_spec :=
  .activeDoQualified ⟨0, by decide⟩ ⟨1, by decide⟩ te04b_rc te08d_launderedLp none

def te08d_tamperedCalAnchor : EmpiricalDatasetAnchorQ0 2 :=
  { te04b_anchor with d0Calibrated := vecOfList 2 [1, 2] }

def te08d_posthocAnchor : EmpiricalDatasetAnchorQ0 2 :=
  { te04b_anchor with calSeq := 25, obsSeq := 20, d0Calibrated := vecOfList 2 [1, 2] }

def te08d_posthocTcb : ExternalEmpiricalTrustCtxQ0 :=
  { sysModelAuth    := AuthorityVecQ0.formalOnly
    attestedRecords :=
      [ { datasetId              := "GZ-DO-CLAMP-2026-04B"
          payloadSha256Hex       := shaTe04b
          calibrationCertId      := "LAB-SURGICAL-CLAMP-04"
          d0CalibrationSha256Hex := shaTe04bCal
          calSeq                 := 25
          obsSeq                 := 20
          attesterId             := "EXT-INTERVENTION-LAB-B"
          regimeSpec             := .activeSurgicalClamp 0 1 [1, 2]
          obsVars                := [UnitSpecQ0.unitless, UnitSpecQ0.unitless]
          d0CalibratedList       := [1, 2]
          yObsList               := [1, 2]
          epsList                := [1 / 4, 1 / 4] } ] }

theorem te08d_offset_laundering_and_posthoc_calibration_blocked :
    InResidualEnvelope te08d_launderedDesign te04b_anchor.yObs te04b_anchor.eps
      (fun _ => interventionalUnitEffect te04_sc2 ⟨1, by decide⟩) ∧
    auditStageEEmpiricalGate stageE_tcb te08d_spec te08d_bundle =
      .rejectedUnattestedEmpiricalQualification ∧
    verifyExternalProvenance stageE_tcb te08d_tamperedCalAnchor = false ∧
    verifyExternalProvenance te08d_posthocTcb te08d_posthocAnchor = false := by
  have hlaund_env : InResidualEnvelope te08d_launderedDesign te04b_anchor.yObs te04b_anchor.eps
      (fun _ => interventionalUnitEffect te04_sc2 ⟨1, by decide⟩) :=
    ((lem_checkFeasibleParameter_iff te08d_launderedDesign te04b_anchor.yObs te04b_anchor.eps
      (fun _ => interventionalUnitEffect te04_sc2 ⟨1, by decide⟩)).mp (by with_unfolding_all rfl)).2
  exact ⟨hlaund_env,
         by with_unfolding_all rfl,
         by with_unfolding_all rfl,
         by with_unfolding_all rfl⟩

/-! ### Runtime Structured Audit Table (`stageEVectorRecords` — `18` Vectors) -/

def formatStageEOutcome : StageEGateOutcomeQ0 → String
  | .verifiedEmptyParameterPrior                => "verifiedEmptyParameterPrior"
  | .verifiedConditionallyEmpiricallyQualified  => "verifiedConditionallyEmpiricallyQualified"
  | .verifiedQueryConditionallyQualified        => "verifiedQueryConditionallyQualified"
  | .verifiedActiveDoConditionallyQualified     => "verifiedActiveDoConditionallyQualified"
  | .verifiedCanonicalIVConditionallyQualified  => "verifiedCanonicalIVConditionallyQualified"
  | .verifiedUnderdeterminedCompatibility       => "verifiedUnderdeterminedCompatibility"
  | .verifiedEmpiricalFarkasFalsification       => "verifiedEmpiricalFarkasFalsification"
  | .verifiedHoldoutExtrapolationFalsified      => "verifiedHoldoutExtrapolationFalsified"
  | .verifiedConfoundingCausalObstruction       => "verifiedConfoundingCausalObstruction"
  | .rejectedInvalidEmpiricalSpec .illTypedObservation =>
      "rejectedInvalidEmpiricalSpec(illTypedObservation)"
  | .rejectedInvalidEmpiricalSpec .invalidUncertaintySpec =>
      "rejectedInvalidEmpiricalSpec(invalidUncertaintySpec)"
  | .rejectedInvalidEmpiricalSpec .invalidSEMOrIVAssumptions =>
      "rejectedInvalidEmpiricalSpec(invalidSEMOrIVAssumptions)"
  | .rejectedInvalidEmpiricalSpec .authorityEscalation =>
      "rejectedInvalidEmpiricalSpec(authorityEscalation)"
  | .rejectedUnattestedEmpiricalQualification   => "rejectedUnattestedEmpiricalQualification"
  | .rejectedInvalidCertificate                 => "rejectedInvalidCertificate"

structure StageEVectorRecord where
  vecId    : String
  expected : StageEGateOutcomeQ0
  actual   : StageEGateOutcomeQ0
  detail   : String

def stageEVectorRecords : List StageEVectorRecord :=
  [ { vecId    := "TE-01"
      expected := .verifiedConditionallyEmpiricallyQualified
      actual   := auditStageEEmpiricalGate stageE_tcb te01_spec te01_bundle
      detail   := "FullRankAffineHooke_PreCommittedD0_TightLP_AttestedHoldout_FE01_FE02_FE05_FE06_FE08" },
    { vecId    := "TE-02a"
      expected := .verifiedUnderdeterminedCompatibility
      actual   := auditStageEEmpiricalGate stageE_tcb te02a_spec te02a_bundle
      detail   := "CollinearSumGaugeNullspace_DomainValidTwinWitness_BlocksIndividualPromotion" },
    { vecId    := "TE-02b"
      expected := .verifiedQueryConditionallyQualified
      actual   := auditStageEEmpiricalGate stageE_tcb te02b_spec te02b_bundle
      detail   := "GaugeInvariantSumQuery_StructID_And_PositiveNoisyIntervalWidth2_FE02_FE03" },
    { vecId    := "TE-03a"
      expected := .verifiedEmpiricalFarkasFalsification
      actual   := auditStageEEmpiricalGate stageE_tcb te03a_spec te03a_bundle
      detail   := "MutuallyContradictoryAffineMeasurements_ExactFarkasDualRefutation" },
    { vecId    := "TE-03b"
      expected := .verifiedEmpiricalFarkasFalsification
      actual   := auditStageEEmpiricalGate stageE_tcb te03b_spec te03b_bundle
      detail   := "PhysicalPositivityGuard_StageDNonnegCert_RefutesNegativeEnvelope" },
    { vecId    := "TE-04a"
      expected := .verifiedConfoundingCausalObstruction
      actual   := auditStageEEmpiricalGate stageE_tcb te04a_spec te04a_bundle
      detail   := "PassiveObservationalClaim_ConfoundingTwinSameSigmaObs_DistinctDoEffect" },
    { vecId    := "TE-04b"
      expected := .verifiedActiveDoConditionallyQualified
      actual   := auditStageEEmpiricalGate stageE_tcb te04b_spec te04b_bundle
      detail   := "ActiveSurgicalDoClamp_DistinctClampLevels_SEMEffectBound_FE04_FE07_FE08" },
    { vecId    := "TE-04c"
      expected := .verifiedCanonicalIVConditionallyQualified
      actual   := auditStageEEmpiricalGate stageE_tcb te04c_spec te04c_bundle
      detail   := "Canonical3NodeLinearIV_ZeroOffsetMoment_WaldRecoversDoBeta3_FE04_FE07_FE08" },
    { vecId    := "TE-05"
      expected := .verifiedHoldoutExtrapolationFalsified
      actual   := auditStageEEmpiricalGate stageE_tcb te05_spec te05_bundle
      detail   := "InSampleCalibrationFeasible_StackedFarkasProvesUniversalHoldoutDisjointness" },
    { vecId    := "TE-06"
      expected := .rejectedInvalidCertificate
      actual   := auditStageEEmpiricalGate stageE_tcb te01_spec te06_bundle
      detail   := "CounterfeitTightLPCertificate_UnattainedLowerEndpoint_Rejected_FE02" },
    { vecId    := "TE-07a"
      expected := .rejectedInvalidEmpiricalSpec .illTypedObservation
      actual   := auditStageEEmpiricalGate stageE_tcb te07a_spec (.emptyPrior default)
      detail   := "TorqueSensorVsEnergyPrediction_KindTagSmuggling_StaticallyBlocked" },
    { vecId    := "TE-07b1"
      expected := .rejectedInvalidEmpiricalSpec .authorityEscalation
      actual   := auditStageEEmpiricalGate stageE_tcb te07b1_spec (.emptyPrior default)
      detail   := "SyntheticSimulationBootstrap_EmpiricalZeroCap_StaticallyBlocked" },
    { vecId    := "TE-07b2"
      expected := .rejectedInvalidEmpiricalSpec .authorityEscalation
      actual   := auditStageEEmpiricalGate stageE_tcb te07b2_spec (.emptyPrior default)
      detail   := "ForgedExternalOriginLabel_WithoutTCBAttestation_EmpiricalZeroCap_FE05" },
    { vecId    := "TE-07c"
      expected := .rejectedInvalidEmpiricalSpec .authorityEscalation
      actual   := auditStageEEmpiricalGate stageE_tcb te07c_spec (.emptyPrior default)
      detail   := "InstitutionalAuthorityEscalation_aI1_UnconditionallyBlocked" },
    { vecId    := "TE-08a"
      expected := .rejectedUnattestedEmpiricalQualification
      actual   := auditStageEEmpiricalGate te08a_emptyTcb te08a_spec te08a_bundle
      detail   := "UnattestedEmptyTCB_Claimed100_PositiveQualificationUnconditionallyBlocked_FE06" },
    { vecId    := "TE-08b"
      expected := .rejectedInvalidCertificate
      actual   := auditStageEEmpiricalGate stageE_tcb te08b_spec te08b_bundle
      detail   := "PassiveObservationalDataset_SmuggledAsActiveSurgicalDo_Blocked_FE07" },
    { vecId    := "TE-08c"
      expected := .rejectedInvalidCertificate
      actual   := auditStageEEmpiricalGate stageE_tcb te08c_spec te08c_bundle
      detail   := "ConfoundedZeroEffectSEM_RefutedAcrossAllConstantOffsets_FE07_FE08Lock2" },
    { vecId    := "TE-08d"
      expected := .rejectedUnattestedEmpiricalQualification
      actual   := auditStageEEmpiricalGate stageE_tcb te08d_spec te08d_bundle
      detail   := "ProposerOffsetLaundering_D0_1_2_BlockedByPreCommittedTCBCalibration_FE08Lock1" } ]

end GrandZero.StageE
