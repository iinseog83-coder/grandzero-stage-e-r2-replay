/-
  GRANDZERO Ω — Stage E (Identifiability, Bounded-Error Set-Membership,
                         Surgical SEM Interventions & Conditional Empirical Qualification Gate)
  Module E-2: Q0BoundedErrorPolytopeAndHoldoutGate.lean
  Scope:
    1. Offset-consistent Bounded-Error Box-Residual Polytope `M_box(Φ) θ ≤ b_box(y_obs, d₀, ε)`
       (`lem_boxPolytope_iff_absResidual`, `Tribunal F-E01`).
    2. `StageD.NonnegCertQ0`-certified domain affine rows `G_dom θ ≥ g₀` over `Real_ℚ(C_Θ)`
       via unitless normalized De Bruijn sums (`lem_domainAffineRows_sound`).
    3. Exact Finite-Sample Empirical Falsification via Farkas Dual (`thm_empirical_farkas_falsification`).
    4. Strict Two-Tier LP Bounds (`Tribunal F-E02` & `F-E03`):
         - Tier A (`thm_query_enclosing_interval_sound`): Conservative sound outer enclosure `[q_lb, q_ub]`.
         - Tier B (`thm_query_tight_minimax_interval_sound`): Attained minimax optimality via
           verified primal boundary witnesses `θ_min, θ_max ∈ Θ_feas`.
    5. Universal Calibration-vs-Holdout Extrapolation Disjointness (`thm_holdout_disjoint_falsification`,
       proving `Θ_feas(cal) ≠ ∅ ∧ Θ_feas(cal) ∩ Θ_feas(hold) = ∅`) + `StageD.iterateStep` trajectory check.
-/

import StageE.Q0ObservationDesignAndIdentifiability

namespace GrandZero.StageE

open GrandZero.StageA
open GrandZero.StageB
open GrandZero.StageC
open GrandZero.StageD

/-! ### Part 1: Componentwise Vector Inequalities & Non-Negative Dot Monotonicity -/

def VecLe {q : Nat} (u v : VecQ0 q) : Prop :=
  ∀ i : Fin q, u i ≤ v i

def vecLeBool {q : Nat} (u v : VecQ0 q) : Bool :=
  allFin q (fun i => decide (u i ≤ v i))

theorem lem_vecLeBool_iff {q : Nat} (u v : VecQ0 q) :
    vecLeBool u v = true ↔ VecLe u v := by
  unfold vecLeBool VecLe
  rw [allFin_iff]
  constructor
  · intro h i; exact decide_eq_true_eq.mp (h i)
  · intro h i; exact decide_eq_true_eq.mpr (h i)

def vecNonnegBool {q : Nat} (w : VecQ0 q) : Bool :=
  allFin q (fun i => decide (0 ≤ w i))

theorem lem_vecNonnegBool_iff {q : Nat} (w : VecQ0 q) :
    vecNonnegBool w = true ↔ ∀ i : Fin q, 0 ≤ w i := by
  unfold vecNonnegBool
  rw [allFin_iff]
  constructor
  · intro h i; exact decide_eq_true_eq.mp (h i)
  · intro h i; exact decide_eq_true_eq.mpr (h i)

def vecPosBool {q : Nat} (e : VecQ0 q) : Bool :=
  allFin q (fun i => decide (0 < e i))

theorem lem_vecPosBool_iff {q : Nat} (e : VecQ0 q) :
    vecPosBool e = true ↔ ∀ i : Fin q, 0 < e i := by
  unfold vecPosBool
  rw [allFin_iff]
  constructor
  · intro h i; exact decide_eq_true_eq.mp (h i)
  · intro h i; exact decide_eq_true_eq.mpr (h i)

theorem finSum_le_finSum :
    ∀ (q : Nat) {f g : Fin q → Rat},
      (∀ i : Fin q, f i ≤ g i) → finSum q f ≤ finSum q g
  | 0, _, _, _ => by simp only [finSum]; grind
  | k + 1, f, g, hle => by
      simp only [finSum]
      have h0 := hle ⟨0, Nat.zero_lt_succ k⟩
      have hrest := finSum_le_finSum k
        (f := fun i => f ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩)
        (g := fun i => g ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩)
        (fun i => hle ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩)
      grind

theorem dotVec_le_of_nonneg_left {q : Nat} {w u v : VecQ0 q}
    (hw : ∀ i : Fin q, 0 ≤ w i) (huv : VecLe u v) :
    dotVec w u ≤ dotVec w v := by
  unfold dotVec
  apply finSum_le_finSum q
  intro i
  exact rat_mul_le_mul_of_nonneg_left (hw i) (huv i)

theorem lem_vcatMat_vec {m1 m2 p : Nat} (A : MatQ0 m1 p) (B : MatQ0 m2 p) (θ : VecQ0 p) :
    matVec (vcatMat A B) θ = vcatVec (matVec A θ) (matVec B θ) := by
  funext i
  unfold vcatMat vcatVec matVec
  by_cases h : i.val < m1
  · simp [h]
  · simp [h]

theorem lem_vecLe_vcatVec_iff {m1 m2 : Nat} (u1 b1 : VecQ0 m1) (u2 b2 : VecQ0 m2) :
    VecLe (vcatVec u1 u2) (vcatVec b1 b2) ↔ VecLe u1 b1 ∧ VecLe u2 b2 := by
  constructor
  · intro h
    refine ⟨fun i1 => ?_, fun i2 => ?_⟩
    · have hi := h ⟨i1.val, by have := i1.isLt; omega⟩
      unfold vcatVec at hi
      simp [i1.isLt] at hi
      exact hi
    · have idx_lt : m1 + i2.val < m1 + m2 := by have := i2.isLt; omega
      have hi := h ⟨m1 + i2.val, idx_lt⟩
      have hnot : ¬ (m1 + i2.val < m1) := by omega
      unfold vcatVec at hi
      simp only [hnot, ↓reduceDIte] at hi
      have hsub : (⟨m1 + i2.val - m1, by omega⟩ : Fin m2) = i2 := by
        apply Fin.ext; dsimp; omega
      rw [hsub] at hi
      exact hi
  · rintro ⟨h1, h2⟩ i
    unfold vcatVec
    by_cases hlt : i.val < m1
    · simp only [hlt, ↓reduceDIte]
      exact h1 ⟨i.val, hlt⟩
    · simp only [hlt, ↓reduceDIte]
      exact h2 ⟨i.val - m1, by have := i.isLt; omega⟩

/-! ### Part 2: Offset-Consistent Box-Residual Polytope (`Tribunal F-E01`) -/

/-- Exact bounded-error residual membership `∀ i, |(Φ θ + d₀)_i - y_obs_i| ≤ ε_i` (`F-E01`). -/
def InResidualEnvelope (D : AffineObservationDesignQ0)
    (yObs eps : VecQ0 D.m) (θ : VecQ0 D.p) : Prop :=
  ∀ i : Fin D.m,
    D.predict θ i - yObs i ≤ eps i ∧
    yObs i - D.predict θ i ≤ eps i

/-- Exact semi-algebraic + bounded-error feasible parameter set `Θ_feas`. -/
def InFeasibleParameterSet (D : AffineObservationDesignQ0)
    (yObs eps : VecQ0 D.m) (θ : VecQ0 D.p) : Prop :=
  ValidDomainQ0 (vecToList θ) D.thetaCtx ∧ InResidualEnvelope D yObs eps θ

/-- Stacked `2m × p` box-residual matrix `[Φ ; -Φ]`. -/
def boxMat (D : AffineObservationDesignQ0) : MatQ0 (D.m + D.m) D.p :=
  vcatMat D.Phi (negMat D.Phi)

/-- Offset-adjusted `2m` box-residual RHS `[y_obs + ε - d₀ ; -y_obs + ε + d₀]` (`Tribunal F-E01`). -/
def boxRhs (D : AffineObservationDesignQ0) (yObs eps : VecQ0 D.m) : VecQ0 (D.m + D.m) :=
  vcatVec (subVec (addVec yObs eps) D.d0) (addVec (subVec eps yObs) D.d0)

/-- Target Theorem `lem_boxPolytope_iff_absResidual` (`Tribunal F-E01`):
    `boxMat D · θ ≤ boxRhs D yObs eps` holds iff `|(Φ θ + d₀)_i - y_obs_i| ≤ ε_i` for every channel `i`. -/
theorem lem_boxPolytope_iff_absResidual
    (D : AffineObservationDesignQ0) (yObs eps : VecQ0 D.m) (θ : VecQ0 D.p) :
    VecLe (matVec (boxMat D) θ) (boxRhs D yObs eps) ↔ InResidualEnvelope D yObs eps θ := by
  unfold boxMat boxRhs
  rw [lem_vcatMat_vec, matVec_negMat, lem_vecLe_vcatVec_iff]
  constructor
  · rintro ⟨htop, hbot⟩ i
    have ht := htop i
    have hb := hbot i
    dsimp [AffineObservationDesignQ0.predict, negVec, addVec, subVec] at ht hb ⊢
    constructor <;> grind
  · intro hres
    refine ⟨fun i => ?_, fun i => ?_⟩
    · have h1 := (hres i).1
      dsimp [AffineObservationDesignQ0.predict, addVec, subVec] at h1 ⊢
      grind
    · have h2 := (hres i).2
      dsimp [AffineObservationDesignQ0.predict, negVec, addVec, subVec] at h2 ⊢
      grind

def checkFeasibleParameter (D : AffineObservationDesignQ0)
    (yObs eps : VecQ0 D.m) (θ : VecQ0 D.p) : Bool :=
  checkValidDomainQ0 (vecToList θ) D.thetaCtx &&
  vecLeBool (matVec (boxMat D) θ) (boxRhs D yObs eps)

theorem lem_checkFeasibleParameter_iff
    (D : AffineObservationDesignQ0) (yObs eps : VecQ0 D.m) (θ : VecQ0 D.p) :
    checkFeasibleParameter D yObs eps θ = true ↔ InFeasibleParameterSet D yObs eps θ := by
  unfold checkFeasibleParameter InFeasibleParameterSet
  rw [Bool.and_eq_true, lem_checkValidDomain_iff, lem_vecLeBool_iff, lem_boxPolytope_iff_absResidual]

/-! ### Part 3: `StageD.NonnegCertQ0`-Certified Domain Affine Rows (`G_dom θ ≥ g₀`) -/

/-- Head-recursive unitless De Bruijn sum matching `finSum` structure cleanly. -/
def buildUnitlessAffineSumHead (Γ : VarCtxQ0) :
    (rem : Nat) → (off : Nat) → off + rem ≤ Γ.length → (Fin rem → Rat) → ExprQ0
  | 0, _, _, _ => .ratLit 0 UnitSpecQ0.unitless
  | rem + 1, off, hle, coeff =>
      let uCur := Γ.getD off UnitSpecQ0.unitless
      .binOp .add
        (.binOp .mul (.ratLit (coeff ⟨0, Nat.zero_lt_succ rem⟩) UnitSpecQ0.unitless)
                     (unitNormalizeExpr (.bvar off) uCur))
        (buildUnitlessAffineSumHead Γ rem (off + 1) (by omega)
          (fun i => coeff ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩))

def buildUnitlessAffineRowExpr (Γ : VarCtxQ0) (gRow : VecQ0 Γ.length) (g0 : Rat) : ExprQ0 :=
  .binOp .sub
    (buildUnitlessAffineSumHead Γ Γ.length 0 (by omega) gRow)
    (.ratLit g0 UnitSpecQ0.unitless)

theorem lem_buildUnitlessAffineSumHead_eval (Γ : VarCtxQ0) (θ : VecQ0 Γ.length) :
    ∀ (rem off : Nat) (hle : off + rem ≤ Γ.length) (coeff : Fin rem → Rat),
      denoteExpr (vecToList θ) (buildUnitlessAffineSumHead Γ rem off hle coeff) =
        some (finSum rem (fun i => coeff i * θ ⟨off + i.val, by have := i.isLt; omega⟩))
  | 0, _, _, _ => rfl
  | rem + 1, off, hle, coeff => by
      have hoff_lt : off < Γ.length := by omega
      have hget : (vecToList θ)[off]? = some (θ ⟨off, hoff_lt⟩) :=
        vecToList_getElem θ ⟨off, hoff_lt⟩
      have hnorm : denoteExpr (vecToList θ)
          (unitNormalizeExpr (.bvar off) (Γ.getD off UnitSpecQ0.unitless)) =
            some (θ ⟨off, hoff_lt⟩) := by
        have h10 : ¬ ((1 : Rat) = 0) := by decide
        simp only [unitNormalizeExpr, denoteExpr, hget, evalBinOp, if_neg h10, Option.some.injEq]
        exact rat_div_one _
      have ih := lem_buildUnitlessAffineSumHead_eval Γ θ rem (off + 1) (by omega)
        (fun i => coeff ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩)
      simp only [buildUnitlessAffineSumHead, denoteExpr, hnorm, ih, evalBinOp, finSum,
                 Option.some.injEq, Nat.add_zero]
      have htail : (finSum rem fun i : Fin rem =>
          coeff ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩ *
            θ ⟨off + 1 + i.val, by have := i.isLt; omega⟩) =
        (finSum rem fun i : Fin rem =>
          coeff ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩ *
            θ ⟨off + (i.val + 1), by have := i.isLt; omega⟩) := by
        apply finSum_ext
        intro i
        have hidx : (⟨off + 1 + i.val, by have := i.isLt; omega⟩ : Fin Γ.length) =
            ⟨off + (i.val + 1), by have := i.isLt; omega⟩ := by
          apply Fin.ext; dsimp; omega
        rw [hidx]
      rw [htail]

theorem lem_buildUnitlessAffineRowExpr_eval (Γ : VarCtxQ0) (θ : VecQ0 Γ.length)
    (gRow : VecQ0 Γ.length) (g0 : Rat) :
    denoteExpr (vecToList θ) (buildUnitlessAffineRowExpr Γ gRow g0) =
      some (dotVec gRow θ - g0) := by
  unfold buildUnitlessAffineRowExpr
  rw [denoteExpr, lem_buildUnitlessAffineSumHead_eval]
  simp only [denoteExpr, evalBinOp, Option.some.injEq]
  have heq : (finSum Γ.length fun i : Fin Γ.length =>
      gRow i * θ ⟨0 + i.val, by have := i.isLt; omega⟩) = dotVec gRow θ := by
    unfold dotVec
    apply finSum_ext
    intro i
    have hidx : (⟨0 + i.val, by have := i.isLt; omega⟩ : Fin Γ.length) = i := by
      apply Fin.ext; dsimp; omega
    rw [hidx]
  rw [heq]

/-- Bundle of `qDom` affine domain rows `G_dom θ ≥ g₀`, each certified on `Real_ℚ(C_Θ)`
    via `StageD.NonnegCertQ0`. -/
structure DomainAffineBundleQ0 (p : Nat) where
  qDom     : Nat
  Gdom     : MatQ0 qDom p
  g0       : VecQ0 qDom
  rowCerts : Fin qDom → NonnegCertQ0

def emptyDomainAffineBundle (p : Nat) : DomainAffineBundleQ0 p :=
  { qDom := 0
    Gdom := fun i => i.elim0
    g0 := fun i => i.elim0
    rowCerts := fun i => i.elim0 }

def checkDomainAffineBundle (C : ContextQ0) (db : DomainAffineBundleQ0 C.vars.length) : Bool :=
  allFin db.qDom fun r =>
    checkNonnegCert C
      (buildUnitlessAffineRowExpr C.vars (fun j => db.Gdom r j) (db.g0 r))
      (db.rowCerts r)

theorem lem_domainAffineBundle_sound (C : ContextQ0) (db : DomainAffineBundleQ0 C.vars.length)
    (hdb : checkDomainAffineBundle C db = true)
    (θ : VecQ0 C.vars.length) (hdom : ValidDomainQ0 (vecToList θ) C) :
    VecLe (matVec (negMat db.Gdom) θ) (negVec db.g0) := by
  unfold checkDomainAffineBundle at hdb
  rw [allFin_iff] at hdb
  intro r
  rcases thm_nonneg_cert_sound C _ (db.rowCerts r) (hdb r) (vecToList θ) hdom with
    ⟨v, hden, _, hv_nn⟩
  rw [lem_buildUnitlessAffineRowExpr_eval] at hden
  injection hden with hv_eq
  subst hv_eq
  rw [matVec_negMat]
  dsimp [negVec, matVec, dotVec] at hv_nn ⊢
  grind

def augMat (D : AffineObservationDesignQ0) (db : DomainAffineBundleQ0 D.p) :
    MatQ0 ((D.m + D.m) + db.qDom) D.p :=
  vcatMat (boxMat D) (negMat db.Gdom)

def augRhs (D : AffineObservationDesignQ0) (yObs eps : VecQ0 D.m)
    (db : DomainAffineBundleQ0 D.p) : VecQ0 ((D.m + D.m) + db.qDom) :=
  vcatVec (boxRhs D yObs eps) (negVec db.g0)

theorem lem_feasible_imp_augPolytope
    (D : AffineObservationDesignQ0) (yObs eps : VecQ0 D.m)
    (db : DomainAffineBundleQ0 D.p)
    (hdb : checkDomainAffineBundle D.thetaCtx db = true)
    (θ : VecQ0 D.p) (hfeas : InFeasibleParameterSet D yObs eps θ) :
    VecLe (matVec (augMat D db) θ) (augRhs D yObs eps db) := by
  unfold augMat augRhs
  rw [lem_vcatMat_vec, lem_vecLe_vcatVec_iff]
  exact ⟨(lem_boxPolytope_iff_absResidual D yObs eps θ).mpr hfeas.2,
         lem_domainAffineBundle_sound D.thetaCtx db hdb θ hfeas.1⟩

/-! ### Part 4: Exact Finite-Sample Empirical Falsification via Farkas Dual -/

def checkPolytopeFarkasDual {q p : Nat} (M : MatQ0 q p) (b : VecQ0 q) (w : VecQ0 q) : Bool :=
  vecNonnegBool w &&
  vecEqBool (matVec (transposeMat M) w) (zeroVec p) &&
  decide (dotVec w b < 0)

theorem thm_farkas_polytope_infeasible {q p : Nat}
    (M : MatQ0 q p) (b w : VecQ0 q)
    (hfark : checkPolytopeFarkasDual M b w = true) :
    ∀ θ : VecQ0 p, ¬ VecLe (matVec M θ) b := by
  unfold checkPolytopeFarkasDual at hfark
  simp only [Bool.and_eq_true, lem_vecNonnegBool_iff, vecEqBool_iff, decide_eq_true_eq] at hfark
  rcases hfark with ⟨⟨hw_nn, hmtw⟩, hwb_neg⟩
  intro θ hle
  have h1 : dotVec w (matVec M θ) ≤ dotVec w b := dotVec_le_of_nonneg_left hw_nn hle
  rw [dotVec_matVec_transpose, hmtw, dotVec_zero_left] at h1
  grind

structure EmpiricalFalsificationCertQ0 (D : AffineObservationDesignQ0) where
  domRows : DomainAffineBundleQ0 D.p
  wDual   : VecQ0 ((D.m + D.m) + domRows.qDom)

def checkEmpiricalFalsificationCert
    (D : AffineObservationDesignQ0) (yObs eps : VecQ0 D.m)
    (cert : EmpiricalFalsificationCertQ0 D) : Bool :=
  checkDomainAffineBundle D.thetaCtx cert.domRows &&
  checkPolytopeFarkasDual (augMat D cert.domRows) (augRhs D yObs eps cert.domRows) cert.wDual

/-- Target Theorem `thm_empirical_farkas_falsification` (`Tribunal F-E01`):
    Whenever `checkEmpiricalFalsificationCert D yObs eps cert = true`, the offset-adjusted
    empirical feasible parameter set `Θ_feas(C_Θ, Φ, d₀, y_obs, ε)` is provably EMPTY! -/
theorem thm_empirical_farkas_falsification
    (D : AffineObservationDesignQ0) (yObs eps : VecQ0 D.m)
    (cert : EmpiricalFalsificationCertQ0 D)
    (hchk : checkEmpiricalFalsificationCert D yObs eps cert = true) :
    ∀ θ : VecQ0 D.p, ¬ InFeasibleParameterSet D yObs eps θ := by
  unfold checkEmpiricalFalsificationCert at hchk
  simp only [Bool.and_eq_true] at hchk
  rcases hchk with ⟨hdb, hfark⟩
  intro θ hfeas
  exact thm_farkas_polytope_infeasible _ _ cert.wDual hfark θ
    (lem_feasible_imp_augPolytope D yObs eps cert.domRows hdb θ hfeas)

/-! ### Part 5: Enclosing vs. Tight LP Dual Query Intervals (`Tribunal F-E02` & `F-E03`) -/

/-- Tier A (`Tribunal F-E02`): Sound Enclosing Query Interval Certificate.
    Certifies a conservative outer bound `[qLb, qUb]` on `⟨cQuery, θ⟩` across `Θ_feas`
    without claiming endpoint attainment. -/
structure QueryEnclosingCertQ0 (D : AffineObservationDesignQ0) where
  thetaHat : VecQ0 D.p
  domRows  : DomainAffineBundleQ0 D.p
  wLb      : VecQ0 ((D.m + D.m) + domRows.qDom)
  wUb      : VecQ0 ((D.m + D.m) + domRows.qDom)

namespace QueryEnclosingCertQ0

def qLb {D : AffineObservationDesignQ0} (cert : QueryEnclosingCertQ0 D)
    (yObs eps : VecQ0 D.m) : Rat :=
  -(dotVec cert.wLb (augRhs D yObs eps cert.domRows))

def qUb {D : AffineObservationDesignQ0} (cert : QueryEnclosingCertQ0 D)
    (yObs eps : VecQ0 D.m) : Rat :=
  dotVec cert.wUb (augRhs D yObs eps cert.domRows)

def width {D : AffineObservationDesignQ0} (cert : QueryEnclosingCertQ0 D)
    (yObs eps : VecQ0 D.m) : Rat :=
  cert.qUb yObs eps - cert.qLb yObs eps

end QueryEnclosingCertQ0

def checkQueryEnclosingCert
    (D : AffineObservationDesignQ0) (yObs eps : VecQ0 D.m)
    (cQuery : VecQ0 D.p) (cert : QueryEnclosingCertQ0 D) : Bool :=
  checkFeasibleParameter D yObs eps cert.thetaHat &&
  checkDomainAffineBundle D.thetaCtx cert.domRows &&
  vecNonnegBool cert.wLb &&
  vecNonnegBool cert.wUb &&
  vecEqBool (matVec (transposeMat (augMat D cert.domRows)) cert.wLb) (negVec cQuery) &&
  vecEqBool (matVec (transposeMat (augMat D cert.domRows)) cert.wUb) cQuery

/-- Target Theorem `thm_query_enclosing_interval_sound` (`Tribunal F-E02` Tier A):
    Certifies non-emptiness of `Θ_feas`, conservative global outer enclosure
    `∀ θ ∈ Θ_feas, qLb ≤ ⟨cQuery, θ⟩ ≤ qUb`, and non-negative width `0 ≤ qUb - qLb`. -/
theorem thm_query_enclosing_interval_sound
    (D : AffineObservationDesignQ0) (yObs eps : VecQ0 D.m)
    (cQuery : VecQ0 D.p) (cert : QueryEnclosingCertQ0 D)
    (hchk : checkQueryEnclosingCert D yObs eps cQuery cert = true) :
    InFeasibleParameterSet D yObs eps cert.thetaHat ∧
    (∀ θ : VecQ0 D.p, InFeasibleParameterSet D yObs eps θ →
      cert.qLb yObs eps ≤ dotVec cQuery θ ∧ dotVec cQuery θ ≤ cert.qUb yObs eps) ∧
    0 ≤ cert.width yObs eps := by
  unfold checkQueryEnclosingCert at hchk
  simp only [Bool.and_eq_true, lem_checkFeasibleParameter_iff,
             lem_vecNonnegBool_iff, vecEqBool_iff] at hchk
  rcases hchk with ⟨⟨⟨⟨⟨hhat, hdb⟩, hwLb_nn⟩, hwUb_nn⟩, heqLb⟩, heqUb⟩
  have henc : ∀ θ : VecQ0 D.p, InFeasibleParameterSet D yObs eps θ →
      cert.qLb yObs eps ≤ dotVec cQuery θ ∧ dotVec cQuery θ ≤ cert.qUb yObs eps := by
    intro θ hfeas
    have haug := lem_feasible_imp_augPolytope D yObs eps cert.domRows hdb θ hfeas
    have hub : dotVec cQuery θ ≤ cert.qUb yObs eps := by
      have h1 := dotVec_le_of_nonneg_left hwUb_nn haug
      rw [dotVec_matVec_transpose, heqUb] at h1
      exact h1
    have hlb : cert.qLb yObs eps ≤ dotVec cQuery θ := by
      have h2 := dotVec_le_of_nonneg_left hwLb_nn haug
      rw [dotVec_matVec_transpose, heqLb, dotVec_neg_left] at h2
      unfold QueryEnclosingCertQ0.qLb
      grind
    exact ⟨hlb, hub⟩
  have hhat_bounds := henc cert.thetaHat hhat
  refine ⟨hhat, henc, ?_⟩
  unfold QueryEnclosingCertQ0.width
  have h1 := hhat_bounds.1
  have h2 := hhat_bounds.2
  grind

/-- Tier B (`Tribunal F-E02`): Attained Tight Minimax Query Interval Certificate.
    Requires explicit domain-valid & envelope-feasible primal extremizers `thetaMin, thetaMax`
    achieving both dual bounds `qLb` and `qUb`. -/
structure TightQueryIntervalCertQ0 (D : AffineObservationDesignQ0) where
  enclosing : QueryEnclosingCertQ0 D
  thetaMin  : VecQ0 D.p
  thetaMax  : VecQ0 D.p

def checkTightQueryIntervalCert
    (D : AffineObservationDesignQ0) (yObs eps : VecQ0 D.m)
    (cQuery : VecQ0 D.p) (cert : TightQueryIntervalCertQ0 D) : Bool :=
  checkQueryEnclosingCert D yObs eps cQuery cert.enclosing &&
  checkFeasibleParameter D yObs eps cert.thetaMin &&
  checkFeasibleParameter D yObs eps cert.thetaMax &&
  decide (dotVec cQuery cert.thetaMin = cert.enclosing.qLb yObs eps) &&
  decide (dotVec cQuery cert.thetaMax = cert.enclosing.qUb yObs eps)

/-- Target Theorem `thm_query_tight_minimax_interval_sound` (`Tribunal F-E02` Tier B):
    Proves BOTH global outer enclosure AND exact primal attainment of `qLb` and `qUb` inside `Θ_feas`. -/
theorem thm_query_tight_minimax_interval_sound
    (D : AffineObservationDesignQ0) (yObs eps : VecQ0 D.m)
    (cQuery : VecQ0 D.p) (cert : TightQueryIntervalCertQ0 D)
    (hchk : checkTightQueryIntervalCert D yObs eps cQuery cert = true) :
    InFeasibleParameterSet D yObs eps cert.thetaMin ∧
    InFeasibleParameterSet D yObs eps cert.thetaMax ∧
    dotVec cQuery cert.thetaMin = cert.enclosing.qLb yObs eps ∧
    dotVec cQuery cert.thetaMax = cert.enclosing.qUb yObs eps ∧
    (∀ θ : VecQ0 D.p, InFeasibleParameterSet D yObs eps θ →
      cert.enclosing.qLb yObs eps ≤ dotVec cQuery θ ∧
      dotVec cQuery θ ≤ cert.enclosing.qUb yObs eps) := by
  unfold checkTightQueryIntervalCert at hchk
  simp only [Bool.and_eq_true, lem_checkFeasibleParameter_iff, decide_eq_true_eq] at hchk
  rcases hchk with ⟨⟨⟨⟨henc_chk, hmin_f⟩, hmax_f⟩, hmin_val⟩, hmax_val⟩
  have henc := (thm_query_enclosing_interval_sound D yObs eps cQuery cert.enclosing henc_chk).2.1
  exact ⟨hmin_f, hmax_f, hmin_val, hmax_val, henc⟩

/-! ### Part 6: Universal Calibration-vs-Holdout Extrapolation Disjointness + `Stage D` Check -/

/-- Certificate proving calibration feasibility `Θ_feas(cal) ≠ ∅` simultaneously with
    universal calibration-holdout disjointness `Θ_feas(cal) ∩ Θ_feas(hold) = ∅`. -/
structure HoldoutDisjointCertQ0 (Dcal Dhold : AffineObservationDesignQ0) where
  thetaCal  : VecQ0 Dcal.p
  domRows   : DomainAffineBundleQ0 Dcal.p
  wDisjoint : VecQ0 (((Dcal.m + Dcal.m) + domRows.qDom) + (Dhold.m + Dhold.m))

def checkHoldoutDisjointCert
    (Dcal Dhold : AffineObservationDesignQ0)
    (hCtxEq : Dcal.thetaCtx = Dhold.thetaCtx)
    (yCal epsCal : VecQ0 Dcal.m)
    (yHold epsHold : VecQ0 Dhold.m)
    (cert : HoldoutDisjointCertQ0 Dcal Dhold) : Bool :=
  have hp : Dhold.p = Dcal.p := by unfold AffineObservationDesignQ0.p; rw [hCtxEq]
  let MholdCast : MatQ0 (Dhold.m + Dhold.m) Dcal.p := hp ▸ boxMat Dhold
  checkFeasibleParameter Dcal yCal epsCal cert.thetaCal &&
  checkDomainAffineBundle Dcal.thetaCtx cert.domRows &&
  checkPolytopeFarkasDual
    (vcatMat (augMat Dcal cert.domRows) MholdCast)
    (vcatVec (augRhs Dcal yCal epsCal cert.domRows) (boxRhs Dhold yHold epsHold))
    cert.wDisjoint

/-- Target Theorem `thm_holdout_disjoint_falsification`:
    Proves that the model fits the calibration window (`∃ θ_cal ∈ Θ_feas(cal)`), YET NO
    parameter vector `θ` in the entire parameter space can simultaneously satisfy both
    calibration and out-of-sample holdout envelopes! -/
theorem thm_holdout_disjoint_falsification
    (Dcal Dhold : AffineObservationDesignQ0)
    (hCtxEq : Dcal.thetaCtx = Dhold.thetaCtx)
    (yCal epsCal : VecQ0 Dcal.m)
    (yHold epsHold : VecQ0 Dhold.m)
    (cert : HoldoutDisjointCertQ0 Dcal Dhold)
    (hchk : checkHoldoutDisjointCert Dcal Dhold hCtxEq yCal epsCal yHold epsHold cert = true) :
    InFeasibleParameterSet Dcal yCal epsCal cert.thetaCal ∧
    (∀ θ : VecQ0 Dcal.p,
      ¬ (InFeasibleParameterSet Dcal yCal epsCal θ ∧
         InFeasibleParameterSet Dhold yHold epsHold
           ((by unfold AffineObservationDesignQ0.p; rw [hCtxEq] : Dcal.p = Dhold.p) ▸ θ))) := by
  cases Dcal with
  | mk ctxCal obsCal PhiCal d0Cal uPhiCal uD0Cal =>
    cases Dhold with
    | mk ctxHold obsHold PhiHold d0Hold uPhiHold uD0Hold =>
      dsimp at hCtxEq
      subst hCtxEq
      unfold checkHoldoutDisjointCert at hchk
      simp only [Bool.and_eq_true, lem_checkFeasibleParameter_iff] at hchk
      rcases hchk with ⟨⟨hcal_ok, hdb_ok⟩, hfark⟩
      refine ⟨hcal_ok, ?_⟩
      intro θ ⟨hf_cal, hf_hold⟩
      have haug_cal := lem_feasible_imp_augPolytope
        ⟨ctxCal, obsCal, PhiCal, d0Cal, uPhiCal, uD0Cal⟩ yCal epsCal cert.domRows hdb_ok θ hf_cal
      have hbox_hold := (lem_boxPolytope_iff_absResidual
        ⟨ctxCal, obsHold, PhiHold, d0Hold, uPhiHold, uD0Hold⟩ yHold epsHold θ).mpr hf_hold.2
      have hstack : VecLe
          (matVec (vcatMat (augMat ⟨ctxCal, obsCal, PhiCal, d0Cal, uPhiCal, uD0Cal⟩ cert.domRows)
                           (boxMat ⟨ctxCal, obsHold, PhiHold, d0Hold, uPhiHold, uD0Hold⟩)) θ)
          (vcatVec (augRhs ⟨ctxCal, obsCal, PhiCal, d0Cal, uPhiCal, uD0Cal⟩ yCal epsCal cert.domRows)
                   (boxRhs ⟨ctxCal, obsHold, PhiHold, d0Hold, uPhiHold, uD0Hold⟩ yHold epsHold)) := by
        rw [lem_vcatMat_vec, lem_vecLe_vcatVec_iff]
        exact ⟨haug_cal, hbox_hold⟩
      exact thm_farkas_polytope_infeasible _ _ cert.wDisjoint hfark θ hstack

/-- Direct binding to frozen `StageD.iterateStep` witnessing an out-of-sample trajectory
    observable residual escape `|obs(ρ_t) - y_obs| > ε` (`ε > 0`). -/
def checkDynHoldoutResidualEscape
    (dyn : GuardedDynSpecQ0) (obs : ExprQ0)
    (ρ₀ : List Rat) (tHold : Nat) (yHold epsHold : Rat) : Bool :=
  decide (0 < epsHold) &&
  checkValidDomainQ0 ρ₀ dyn.ctx &&
  match iterateStep dyn.stepCoords tHold ρ₀ with
  | none => false
  | some ρt =>
      match denoteExpr ρt obs with
      | none => false
      | some yPred => decide (epsHold < yPred - yHold ∨ epsHold < yHold - yPred)

theorem thm_dyn_holdout_residual_escape_sound
    (dyn : GuardedDynSpecQ0) (obs : ExprQ0)
    (ρ₀ : List Rat) (tHold : Nat) (yHold epsHold : Rat)
    (hchk : checkDynHoldoutResidualEscape dyn obs ρ₀ tHold yHold epsHold = true) :
    0 < epsHold ∧
    ValidDomainQ0 ρ₀ dyn.ctx ∧
    ∃ ρt yPred,
      iterateStep dyn.stepCoords tHold ρ₀ = some ρt ∧
      denoteExpr ρt obs = some yPred ∧
      ¬ (yPred - yHold ≤ epsHold ∧ yHold - yPred ≤ epsHold) := by
  unfold checkDynHoldoutResidualEscape at hchk
  simp only [Bool.and_eq_true, decide_eq_true_eq, lem_checkValidDomain_iff] at hchk
  rcases hchk with ⟨⟨heps, hdom⟩, hstep_chk⟩
  cases hstep : iterateStep dyn.stepCoords tHold ρ₀ with
  | none => rw [hstep] at hstep_chk; contradiction
  | some ρt =>
      rw [hstep] at hstep_chk
      dsimp only at hstep_chk
      cases hobs : denoteExpr ρt obs with
      | none => rw [hobs] at hstep_chk; contradiction
      | some yPred =>
          rw [hobs] at hstep_chk
          dsimp only at hstep_chk
          have hout := decide_eq_true_eq.mp hstep_chk
          refine ⟨heps, hdom, ρt, yPred, rfl, hobs, ?_⟩
          intro ⟨h1, h2⟩
          cases hout with
          | inl hl => grind
          | inr hr => grind

end GrandZero.StageE
