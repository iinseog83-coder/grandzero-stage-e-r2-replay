/-
  GRANDZERO Ω — Stage B (Minimal 3-Context · 1-Triangle 2-Cell Certifier)
  Module B-2: Q0TypedTransportAndPullback.lean
  Scope:
    1. 3D Product Authority Lattice `AuthorityVecQ0 = (formal, empirical, institutional)`
       with componentwise partial order & `meet` (`thm_authority_product_nonescalation`,
       `Tribunal Refinement 2.B`).
    2. Sign- & pole-aware guard certificate checker `BridgeGuardProofQ0` extending
       `StageA.checkGuardProof` (`thm_bridge_guard_proof_sound`).
    3. `BridgeMorphismQ0`, static unit/kind + authority gate, coordinate pole extraction,
       pulled-back equality & guard discharge, and full semantic domain preservation
       `thm_transport_maps_valid_domain` & `thm_static_domain_pullback`
       (`Tribunal Condition 2`, `2.A`, `2.D`).
-/

import StageB.Q0ContextAndParallelSubst

namespace GrandZero.StageB

open GrandZero.StageA

/-! ### Part 1: 3D Product Authority Lattice (`Tribunal Refinement 2.B`) -/

/-- Orthogonal 3-axis authority vector `(a_F, a_E, a_I)`:
    formal mathematical proof, empirical validation, and institutional execution approval
    live in independent coordinates rather than a collapsed 1D ranking. -/
structure AuthorityVecQ0 where
  formal        : Nat := 0
  empirical     : Nat := 0
  institutional : Nat := 0
  deriving DecidableEq, Repr, Inhabited

namespace AuthorityVecQ0

def exploratory       : AuthorityVecQ0 := { formal := 0, empirical := 0, institutional := 0 }
def formalOnly        : AuthorityVecQ0 := { formal := 1, empirical := 0, institutional := 0 }
def empiricalOnly     : AuthorityVecQ0 := { formal := 0, empirical := 1, institutional := 0 }
def institutionalOnly : AuthorityVecQ0 := { formal := 0, empirical := 0, institutional := 1 }
def formalEmpirical   : AuthorityVecQ0 := { formal := 1, empirical := 1, institutional := 0 }

/-- Componentwise lattice meet (`⊓`), representing conservative authority propagation. -/
def meet (a b : AuthorityVecQ0) : AuthorityVecQ0 :=
  { formal        := Nat.min a.formal b.formal
    empirical     := Nat.min a.empirical b.empirical
    institutional := Nat.min a.institutional b.institutional }

end AuthorityVecQ0

/-- Componentwise authority non-escalation order `A_dst ≼ A_src`. -/
def AuthorityLe (dst src : AuthorityVecQ0) : Prop :=
  dst.formal ≤ src.formal ∧
  dst.empirical ≤ src.empirical ∧
  dst.institutional ≤ src.institutional

/-- Computable boolean test for `AuthorityLe`. -/
def checkAuthorityLe (dst src : AuthorityVecQ0) : Bool :=
  decide (dst.formal ≤ src.formal) &&
  decide (dst.empirical ≤ src.empirical) &&
  decide (dst.institutional ≤ src.institutional)

theorem lem_checkAuthorityLe_iff (dst src : AuthorityVecQ0) :
    checkAuthorityLe dst src = true ↔ AuthorityLe dst src := by
  unfold checkAuthorityLe AuthorityLe
  simp only [Bool.and_eq_true, decide_eq_true_eq]
  exact ⟨fun ⟨⟨h1, h2⟩, h3⟩ => ⟨h1, h2, h3⟩, fun ⟨h1, h2, h3⟩ => ⟨⟨h1, h2⟩, h3⟩⟩

theorem AuthorityLe.refl (a : AuthorityVecQ0) : AuthorityLe a a :=
  ⟨Nat.le_refl _, Nat.le_refl _, Nat.le_refl _⟩

theorem AuthorityLe.trans {a b c : AuthorityVecQ0}
    (h1 : AuthorityLe a b) (h2 : AuthorityLe b c) : AuthorityLe a c :=
  ⟨Nat.le_trans h1.1 h2.1, Nat.le_trans h1.2.1 h2.2.1, Nat.le_trans h1.2.2 h2.2.2⟩

theorem AuthorityLe.antisymm {a b : AuthorityVecQ0}
    (h1 : AuthorityLe a b) (h2 : AuthorityLe b a) : a = b := by
  cases a; cases b
  simp only [AuthorityLe] at h1 h2
  simp only [AuthorityVecQ0.mk.injEq]
  exact ⟨Nat.le_antisymm h1.1 h2.1,
         Nat.le_antisymm h1.2.1 h2.2.1,
         Nat.le_antisymm h1.2.2 h2.2.2⟩

theorem AuthorityLe.meet_left (a b : AuthorityVecQ0) : AuthorityLe (a.meet b) a :=
  ⟨Nat.min_le_left _ _, Nat.min_le_left _ _, Nat.min_le_left _ _⟩

theorem AuthorityLe.meet_right (a b : AuthorityVecQ0) : AuthorityLe (a.meet b) b :=
  ⟨Nat.min_le_right _ _, Nat.min_le_right _ _, Nat.min_le_right _ _⟩

/-- Formal and empirical authority coordinates are genuinely incomparable in `AuthorityLe`. -/
theorem thm_formal_empirical_incomparable :
    ¬ AuthorityLe AuthorityVecQ0.empiricalOnly AuthorityVecQ0.formalOnly ∧
    ¬ AuthorityLe AuthorityVecQ0.formalOnly AuthorityVecQ0.empiricalOnly := by
  dsimp [AuthorityLe, AuthorityVecQ0.empiricalOnly, AuthorityVecQ0.formalOnly]
  omega

/-- Target Theorem `THM-AUTHORITY-PRODUCT-NONESCALATION` (`Tribunal Refinement 2.B`):
    Internal transport satisfying `checkAuthorityLe` preserves componentwise bounds, is
    transitive across composite paths, and can NEVER synthesize empirical (`a_E > 0`)
    or institutional (`a_I > 0`) authority from purely formal (`a_E = 0, a_I = 0`) premises. -/
theorem thm_authority_product_nonescalation
    {src mid dst : AuthorityVecQ0}
    (h1 : checkAuthorityLe mid src = true)
    (h2 : checkAuthorityLe dst mid = true) :
    AuthorityLe dst src ∧
    (src.empirical = 0 → dst.empirical = 0) ∧
    (src.institutional = 0 → dst.institutional = 0) := by
  have hle1 := (lem_checkAuthorityLe_iff mid src).mp h1
  have hle2 := (lem_checkAuthorityLe_iff dst mid).mp h2
  have htot := AuthorityLe.trans hle2 hle1
  refine ⟨htot, ?_, ?_⟩
  · intro he0
    have h := htot.2.1
    omega
  · intro hi0
    have h := htot.2.2
    omega

/-! ### Part 2: Ordered-Field Sign Lemmas over `Rat` -/

theorem rat_add_pos_pos {a b : Rat} (ha : 0 < a) (hb : 0 < b) : 0 < a + b := by grind
theorem rat_add_pos_nonneg {a b : Rat} (ha : 0 < a) (hb : 0 ≤ b) : 0 < a + b := by grind
theorem rat_add_nonneg_pos {a b : Rat} (ha : 0 ≤ a) (hb : 0 < b) : 0 < a + b := by grind
theorem rat_add_nonneg_nonneg {a b : Rat} (ha : 0 ≤ a) (hb : 0 ≤ b) : 0 ≤ a + b := by grind

theorem rat_sq_nonneg (a : Rat) : 0 ≤ a * a := by
  by_cases h : 0 ≤ a
  · exact Rat.mul_nonneg h h
  · have hneg : 0 ≤ -a := by grind
    have hsq := Rat.mul_nonneg hneg hneg
    grind

theorem rat_div_pos {a b : Rat} (ha : 0 < a) (hb : 0 < b) : 0 < a / b := by
  by_cases h : 0 < a / b
  · exact h
  · have hneg : 0 ≤ -(a / b) := by grind
    have hb_nn : 0 ≤ b := by grind
    have hprod := Rat.mul_nonneg hneg hb_nn
    have hbz : b ≠ 0 := by grind
    have hcancel := rat_div_mul_cancel a b hbz
    grind

theorem rat_div_nonneg {a b : Rat} (ha : 0 ≤ a) (hb : 0 < b) : 0 ≤ a / b := by
  by_cases h : 0 ≤ a / b
  · exact h
  · have hneg : 0 < -(a / b) := by grind
    have hprod := Rat.mul_pos hneg hb
    have hbz : b ≠ 0 := by grind
    have hcancel := rat_div_mul_cancel a b hbz
    grind

/-! ### Part 3: Sign- & Pole-Aware Guard Proof Checker (`BridgeGuardProofQ0`) -/

/-- Same guard polarity check (`nonZero`/`pos`/`nonNeg`) for algebraic equivalence transport. -/
def sameGuardKind : GuardQ0 → GuardQ0 → Bool
  | .nonZero _, .nonZero _ => true
  | .pos _,     .pos _     => true
  | .nonNeg _,  .nonNeg _  => true
  | _,          _          => false

/-- Extended whitebox guard proof witness for Stage B static domain pullback & cones. -/
inductive BridgeGuardProofQ0 where
  | fromStageA     : GuardProofQ0 → BridgeGuardProofQ0
  | gPosImpNzB     : BridgeGuardProofQ0 → BridgeGuardProofQ0
  | gPosImpNNegB   : BridgeGuardProofQ0 → BridgeGuardProofQ0
  | gPosAddPos     : BridgeGuardProofQ0 → BridgeGuardProofQ0 → BridgeGuardProofQ0
  | gPosAddNNeg    : BridgeGuardProofQ0 → BridgeGuardProofQ0 → BridgeGuardProofQ0
  | gNNegAddPos    : BridgeGuardProofQ0 → BridgeGuardProofQ0 → BridgeGuardProofQ0
  | gNNegAddNNeg   : BridgeGuardProofQ0 → BridgeGuardProofQ0 → BridgeGuardProofQ0
  | gPosMulPos     : BridgeGuardProofQ0 → BridgeGuardProofQ0 → BridgeGuardProofQ0
  | gPosDivPos     : BridgeGuardProofQ0 → BridgeGuardProofQ0 → BridgeGuardProofQ0
  | gNNegMulNNeg   : BridgeGuardProofQ0 → BridgeGuardProofQ0 → BridgeGuardProofQ0
  | gNNegDivPos    : BridgeGuardProofQ0 → BridgeGuardProofQ0 → BridgeGuardProofQ0
  | gSqNNeg        : List GuardProofQ0 → BridgeGuardProofQ0
  | gAlgebraicEquiv : GuardQ0 → BridgeGuardProofQ0 → ProofCertQ0 → BridgeGuardProofQ0
  deriving DecidableEq, Repr, Inhabited

/-- Trusted target-bound checker for `BridgeGuardProofQ0`. -/
def checkBridgeGuardProof
    (Γ_vars : VarCtxQ0) (Γ_hyps : HypCtxQ0) (Ω : List GuardQ0)
    (p : BridgeGuardProofQ0) (target : GuardQ0) : Bool :=
  if (synthUnit Γ_vars (guardExpr target)).isNone then false
  else
    match p, target with
    | .fromStageA pa, ω =>
        checkGuardProof Γ_vars Γ_hyps Ω pa ω
    | .gPosImpNzB p0, .nonZero e =>
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p0 (.pos e)
    | .gPosImpNNegB p0, .nonNeg e =>
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p0 (.pos e)
    | .gPosAddPos p1 p2, .pos (.binOp .add a b) =>
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p1 (.pos a) &&
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p2 (.pos b)
    | .gPosAddNNeg p1 p2, .pos (.binOp .add a b) =>
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p1 (.pos a) &&
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p2 (.nonNeg b)
    | .gNNegAddPos p1 p2, .pos (.binOp .add a b) =>
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p1 (.nonNeg a) &&
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p2 (.pos b)
    | .gNNegAddNNeg p1 p2, .nonNeg (.binOp .add a b) =>
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p1 (.nonNeg a) &&
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p2 (.nonNeg b)
    | .gPosMulPos p1 p2, .pos (.binOp .mul a b) =>
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p1 (.pos a) &&
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p2 (.pos b)
    | .gPosDivPos p1 p2, .pos (.binOp .div a b) =>
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p1 (.pos a) &&
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p2 (.pos b)
    | .gNNegMulNNeg p1 p2, .nonNeg (.binOp .mul a b) =>
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p1 (.nonNeg a) &&
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p2 (.nonNeg b)
    | .gNNegDivPos p1 p2, .nonNeg (.binOp .div a b) =>
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p1 (.nonNeg a) &&
        checkBridgeGuardProof Γ_vars Γ_hyps Ω p2 (.pos b)
    | .gSqNNeg poleProofs, .nonNeg (.binOp .mul a b) =>
        if a != b then false
        else
          match reflectExpr Γ_vars a with
          | some ra => checkGuardListProofs Γ_vars Γ_hyps Ω poleProofs ra.guards
          | none    => false
    | .gAlgebraicEquiv srcGuard pSrc eqCert, ω =>
        sameGuardKind srcGuard ω &&
        checkBridgeGuardProof Γ_vars Γ_hyps Ω pSrc srcGuard &&
        (auditProof Γ_vars Γ_hyps Ω eqCert (guardExpr srcGuard) (guardExpr ω) == SyndromeQ0.zero)
    | _, _ => false

theorem thm_bridge_guard_proof_sound
    (Γ_vars : VarCtxQ0) (Γ_hyps : HypCtxQ0) (Ω : List GuardQ0) (ρ : List Rat)
    (henv : EnvModelsCtx ρ Γ_vars)
    (hhyps : HypsHold ρ Γ_hyps)
    (hguards : GuardsHold ρ Ω) :
    ∀ (p : BridgeGuardProofQ0) (ω : GuardQ0),
      checkBridgeGuardProof Γ_vars Γ_hyps Ω p ω = true →
      (synthUnit Γ_vars (guardExpr ω)).isSome = true ∧ evalGuard ρ ω = true
  | p, ω, hchk => by
      unfold checkBridgeGuardProof at hchk
      cases hsu : synthUnit Γ_vars (guardExpr ω) with
      | none => simp [hsu] at hchk
      | some u_ω =>
          simp only [hsu, Option.isNone_some, Bool.false_eq_true, ↓reduceIte] at hchk
          refine ⟨by simp, ?_⟩
          cases p with
          | fromStageA pa =>
              exact (thm_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards pa ω hchk).2
          | gPosImpNzB p0 =>
              cases ω with
              | pos _ | nonNeg _ => contradiction
              | nonZero e =>
                  have ih := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p0 (.pos e) hchk).2
                  rcases (evalGuard_pos_iff ρ e).mp ih with ⟨v, hv, hpos⟩
                  exact (evalGuard_nonZero_iff ρ e).mpr ⟨v, hv, rat_pos_imp_ne_zero hpos⟩
          | gPosImpNNegB p0 =>
              cases ω with
              | nonZero _ | pos _ => contradiction
              | nonNeg e =>
                  have ih := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p0 (.pos e) hchk).2
                  rcases (evalGuard_pos_iff ρ e).mp ih with ⟨v, hv, hpos⟩
                  exact (evalGuard_nonNeg_iff ρ e).mpr ⟨v, hv, rat_pos_imp_nonneg hpos⟩
          | gPosAddPos p1 p2 =>
              cases ω with
              | nonZero _ | nonNeg _ => contradiction
              | pos d =>
                  cases d with
                  | bvar _ | ratLit _ _ | unaryNeg _ | letBind _ _ => contradiction
                  | binOp op a b =>
                      cases op with
                      | sub | mul | div => contradiction
                      | add =>
                          simp only [Bool.and_eq_true] at hchk
                          have ih1 := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p1 (.pos a) hchk.1).2
                          have ih2 := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p2 (.pos b) hchk.2).2
                          rcases (evalGuard_pos_iff ρ a).mp ih1 with ⟨va, hva, hpa⟩
                          rcases (evalGuard_pos_iff ρ b).mp ih2 with ⟨vb, hvb, hpb⟩
                          exact (evalGuard_pos_iff ρ (.binOp .add a b)).mpr
                            ⟨va + vb, by simp [denoteExpr, evalBinOp, hva, hvb], rat_add_pos_pos hpa hpb⟩
          | gPosAddNNeg p1 p2 =>
              cases ω with
              | nonZero _ | nonNeg _ => contradiction
              | pos d =>
                  cases d with
                  | bvar _ | ratLit _ _ | unaryNeg _ | letBind _ _ => contradiction
                  | binOp op a b =>
                      cases op with
                      | sub | mul | div => contradiction
                      | add =>
                          simp only [Bool.and_eq_true] at hchk
                          have ih1 := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p1 (.pos a) hchk.1).2
                          have ih2 := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p2 (.nonNeg b) hchk.2).2
                          rcases (evalGuard_pos_iff ρ a).mp ih1 with ⟨va, hva, hpa⟩
                          rcases (evalGuard_nonNeg_iff ρ b).mp ih2 with ⟨vb, hvb, hpb⟩
                          exact (evalGuard_pos_iff ρ (.binOp .add a b)).mpr
                            ⟨va + vb, by simp [denoteExpr, evalBinOp, hva, hvb], rat_add_pos_nonneg hpa hpb⟩
          | gNNegAddPos p1 p2 =>
              cases ω with
              | nonZero _ | nonNeg _ => contradiction
              | pos d =>
                  cases d with
                  | bvar _ | ratLit _ _ | unaryNeg _ | letBind _ _ => contradiction
                  | binOp op a b =>
                      cases op with
                      | sub | mul | div => contradiction
                      | add =>
                          simp only [Bool.and_eq_true] at hchk
                          have ih1 := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p1 (.nonNeg a) hchk.1).2
                          have ih2 := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p2 (.pos b) hchk.2).2
                          rcases (evalGuard_nonNeg_iff ρ a).mp ih1 with ⟨va, hva, hpa⟩
                          rcases (evalGuard_pos_iff ρ b).mp ih2 with ⟨vb, hvb, hpb⟩
                          exact (evalGuard_pos_iff ρ (.binOp .add a b)).mpr
                            ⟨va + vb, by simp [denoteExpr, evalBinOp, hva, hvb], rat_add_nonneg_pos hpa hpb⟩
          | gNNegAddNNeg p1 p2 =>
              cases ω with
              | nonZero _ | pos _ => contradiction
              | nonNeg d =>
                  cases d with
                  | bvar _ | ratLit _ _ | unaryNeg _ | letBind _ _ => contradiction
                  | binOp op a b =>
                      cases op with
                      | sub | mul | div => contradiction
                      | add =>
                          simp only [Bool.and_eq_true] at hchk
                          have ih1 := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p1 (.nonNeg a) hchk.1).2
                          have ih2 := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p2 (.nonNeg b) hchk.2).2
                          rcases (evalGuard_nonNeg_iff ρ a).mp ih1 with ⟨va, hva, hpa⟩
                          rcases (evalGuard_nonNeg_iff ρ b).mp ih2 with ⟨vb, hvb, hpb⟩
                          exact (evalGuard_nonNeg_iff ρ (.binOp .add a b)).mpr
                            ⟨va + vb, by simp [denoteExpr, evalBinOp, hva, hvb], rat_add_nonneg_nonneg hpa hpb⟩
          | gPosMulPos p1 p2 =>
              cases ω with
              | nonZero _ | nonNeg _ => contradiction
              | pos d =>
                  cases d with
                  | bvar _ | ratLit _ _ | unaryNeg _ | letBind _ _ => contradiction
                  | binOp op a b =>
                      cases op with
                      | add | sub | div => contradiction
                      | mul =>
                          simp only [Bool.and_eq_true] at hchk
                          have ih1 := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p1 (.pos a) hchk.1).2
                          have ih2 := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p2 (.pos b) hchk.2).2
                          rcases (evalGuard_pos_iff ρ a).mp ih1 with ⟨va, hva, hpa⟩
                          rcases (evalGuard_pos_iff ρ b).mp ih2 with ⟨vb, hvb, hpb⟩
                          exact (evalGuard_pos_iff ρ (.binOp .mul a b)).mpr
                            ⟨va * vb, by simp [denoteExpr, evalBinOp, hva, hvb], Rat.mul_pos hpa hpb⟩
          | gPosDivPos p1 p2 =>
              cases ω with
              | nonZero _ | nonNeg _ => contradiction
              | pos d =>
                  cases d with
                  | bvar _ | ratLit _ _ | unaryNeg _ | letBind _ _ => contradiction
                  | binOp op a b =>
                      cases op with
                      | add | sub | mul => contradiction
                      | div =>
                          simp only [Bool.and_eq_true] at hchk
                          have ih1 := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p1 (.pos a) hchk.1).2
                          have ih2 := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p2 (.pos b) hchk.2).2
                          rcases (evalGuard_pos_iff ρ a).mp ih1 with ⟨va, hva, hpa⟩
                          rcases (evalGuard_pos_iff ρ b).mp ih2 with ⟨vb, hvb, hpb⟩
                          have hbnz : vb ≠ 0 := rat_pos_imp_ne_zero hpb
                          exact (evalGuard_pos_iff ρ (.binOp .div a b)).mpr
                            ⟨va / vb, by simp [denoteExpr, evalBinOp, hva, hvb, hbnz], rat_div_pos hpa hpb⟩
          | gNNegMulNNeg p1 p2 =>
              cases ω with
              | nonZero _ | pos _ => contradiction
              | nonNeg d =>
                  cases d with
                  | bvar _ | ratLit _ _ | unaryNeg _ | letBind _ _ => contradiction
                  | binOp op a b =>
                      cases op with
                      | add | sub | div => contradiction
                      | mul =>
                          simp only [Bool.and_eq_true] at hchk
                          have ih1 := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p1 (.nonNeg a) hchk.1).2
                          have ih2 := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p2 (.nonNeg b) hchk.2).2
                          rcases (evalGuard_nonNeg_iff ρ a).mp ih1 with ⟨va, hva, hpa⟩
                          rcases (evalGuard_nonNeg_iff ρ b).mp ih2 with ⟨vb, hvb, hpb⟩
                          exact (evalGuard_nonNeg_iff ρ (.binOp .mul a b)).mpr
                            ⟨va * vb, by simp [denoteExpr, evalBinOp, hva, hvb], Rat.mul_nonneg hpa hpb⟩
          | gNNegDivPos p1 p2 =>
              cases ω with
              | nonZero _ | pos _ => contradiction
              | nonNeg d =>
                  cases d with
                  | bvar _ | ratLit _ _ | unaryNeg _ | letBind _ _ => contradiction
                  | binOp op a b =>
                      cases op with
                      | add | sub | mul => contradiction
                      | div =>
                          simp only [Bool.and_eq_true] at hchk
                          have ih1 := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p1 (.nonNeg a) hchk.1).2
                          have ih2 := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p2 (.pos b) hchk.2).2
                          rcases (evalGuard_nonNeg_iff ρ a).mp ih1 with ⟨va, hva, hpa⟩
                          rcases (evalGuard_pos_iff ρ b).mp ih2 with ⟨vb, hvb, hpb⟩
                          have hbnz : vb ≠ 0 := rat_pos_imp_ne_zero hpb
                          exact (evalGuard_nonNeg_iff ρ (.binOp .div a b)).mpr
                            ⟨va / vb, by simp [denoteExpr, evalBinOp, hva, hvb, hbnz], rat_div_nonneg hpa hpb⟩
          | gSqNNeg poleProofs =>
              cases ω with
              | nonZero _ | pos _ => contradiction
              | nonNeg d =>
                  cases d with
                  | bvar _ | ratLit _ _ | unaryNeg _ | letBind _ _ => contradiction
                  | binOp op a b =>
                      cases op with
                      | add | sub | div => contradiction
                      | mul =>
                          dsimp only at hchk
                          by_cases hab : a != b
                          · simp [hab] at hchk
                          · simp only [hab, Bool.false_eq_true, ↓reduceIte] at hchk
                            have heq_ab : a = b := by simp [bne_iff_ne] at hab; exact hab
                            subst heq_ab
                            cases hra : reflectExpr Γ_vars a with
                            | none => rw [hra] at hchk; contradiction
                            | some ra =>
                                rw [hra] at hchk
                                have hg_ra := thm_guard_list_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards
                                  poleProofs ra.guards hchk
                                have hisSome := (thm_gpr_domain_exact a Γ_vars ρ ra henv hra).mp hg_ra
                                cases hda : denoteExpr ρ a with
                                | none => rw [hda] at hisSome; contradiction
                                | some va =>
                                    exact (evalGuard_nonNeg_iff ρ (.binOp .mul a a)).mpr
                                      ⟨va * va, by simp [denoteExpr, evalBinOp, hda], rat_sq_nonneg va⟩
          | gAlgebraicEquiv srcGuard pSrc eqCert =>
              simp only [Bool.and_eq_true, beq_iff_eq] at hchk
              rcases hchk with ⟨⟨hkind, hpSrc⟩, haud⟩
              have ihSrc := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards pSrc srcGuard hpSrc).2
              have hstrong := (thm_syndrome_sound eqCert Γ_vars Γ_hyps Ω (guardExpr srcGuard) (guardExpr ω) haud).2
                ρ henv hhyps hguards
              rcases hstrong with ⟨v, hd_src, hd_dst⟩
              cases srcGuard <;> cases ω <;> simp [sameGuardKind] at hkind
              · simp [guardExpr] at hd_src hd_dst
                simp [evalGuard, hd_src] at ihSrc
                simp [evalGuard, hd_dst, ihSrc]
              · simp [guardExpr] at hd_src hd_dst
                simp [evalGuard, hd_src] at ihSrc
                simp [evalGuard, hd_dst, ihSrc]
              · simp [guardExpr] at hd_src hd_dst
                simp [evalGuard, hd_src] at ihSrc
                simp [evalGuard, hd_dst, ihSrc]

/-- Pairwise list checker for `BridgeGuardProofQ0`. -/
def checkBridgeGuardList
    (Γ_vars : VarCtxQ0) (Γ_hyps : HypCtxQ0) (Ω : List GuardQ0) :
    List BridgeGuardProofQ0 → List GuardQ0 → Bool
  | [], [] => true
  | p :: ps, ω :: ωs =>
      checkBridgeGuardProof Γ_vars Γ_hyps Ω p ω &&
      checkBridgeGuardList Γ_vars Γ_hyps Ω ps ωs
  | _, _ => false

theorem thm_bridge_guard_list_sound
    (Γ_vars : VarCtxQ0) (Γ_hyps : HypCtxQ0) (Ω : List GuardQ0) (ρ : List Rat)
    (henv : EnvModelsCtx ρ Γ_vars)
    (hhyps : HypsHold ρ Γ_hyps)
    (hguards : GuardsHold ρ Ω) :
    ∀ (ps : List BridgeGuardProofQ0) (targets : List GuardQ0),
      checkBridgeGuardList Γ_vars Γ_hyps Ω ps targets = true →
      GuardsHold ρ targets
  | [], [], _ => fun _ hm => by simp at hm
  | [], _ :: _, h => by simp [checkBridgeGuardList] at h
  | _ :: _, [], h => by simp [checkBridgeGuardList] at h
  | p :: ps, ω :: ωs, h => by
      simp only [checkBridgeGuardList, Bool.and_eq_true] at h
      have hd := (thm_bridge_guard_proof_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards p ω h.1).2
      have tl := thm_bridge_guard_list_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards ps ωs h.2
      intro g hg
      cases List.mem_cons.mp hg with
      | inl heq => subst heq; exact hd
      | inr htl => exact tl g htl

/-! ### Part 4: `BridgeMorphismQ0`, Pullbacks, & Total Domain Transport (`Tribunal Condition 2`) -/

/-- Typed Scientific Transport morphism `f : C_src → C_dst` carrying coordinate expressions
    and explicit 3D authority vectors. -/
structure BridgeMorphismQ0 where
  src     : ContextQ0
  dst     : ContextQ0
  coords  : List ExprQ0
  srcAuth : AuthorityVecQ0 := AuthorityVecQ0.formalOnly
  dstAuth : AuthorityVecQ0 := AuthorityVecQ0.formalOnly
  deriving DecidableEq, Repr, Inhabited

/-- Pull back destination guards along coordinate map `coords`. -/
def pullbackGuards (coords : List ExprQ0) (Ω_dst : List GuardQ0) : List GuardQ0 :=
  Ω_dst.map (substGuardMap coords)

/-- Pull back destination equality hypotheses along coordinate map `coords`. -/
def pullbackHyps (coords : List ExprQ0) (H_dst : HypCtxQ0) : HypCtxQ0 :=
  H_dst.map (substPropMap coords)

/-- Extract all pole guards across every coordinate expression `c ∈ coords` via `reflectExpr`. -/
def collectCoordsPoleGuards (Γ_src : VarCtxQ0) : List ExprQ0 → Option (List GuardQ0)
  | [] => some []
  | c :: cs =>
      match reflectExpr Γ_src c, collectCoordsPoleGuards Γ_src cs with
      | some rc, some rest => some (rc.guards ++ rest)
      | _, _               => none

theorem lem_collectCoordsPoleGuards_total {Γ_src : VarCtxQ0} :
    ∀ {coords : List ExprQ0} {Γ_dst : VarCtxQ0},
      checkCoordsUnits Γ_src coords Γ_dst = true →
      ∃ gs : List GuardQ0, collectCoordsPoleGuards Γ_src coords = some gs
  | [], [], _ => ⟨[], rfl⟩
  | [], _ :: _, h => by simp [checkCoordsUnits] at h
  | _ :: _, [], h => by simp [checkCoordsUnits] at h
  | c :: cs, u :: us, h => by
      simp only [checkCoordsUnits, Bool.and_eq_true, beq_iff_eq] at h
      rcases thm_gpr_typed_total c Γ_src u h.1 with ⟨rc, hrc, _⟩
      rcases lem_collectCoordsPoleGuards_total h.2 with ⟨rest, hrest⟩
      exact ⟨rc.guards ++ rest, by simp [collectCoordsPoleGuards, hrc, hrest]⟩

theorem lem_collectCoordsPoleGuards_evalCoords {Γ_src : VarCtxQ0} {ρ : List Rat}
    (henv : EnvModelsCtx ρ Γ_src) :
    ∀ {coords : List ExprQ0} {gs : List GuardQ0},
      collectCoordsPoleGuards Γ_src coords = some gs →
      GuardsHold ρ gs →
      ∃ ρ' : List Rat, evalCoords ρ coords = some ρ'
  | [], _, hcol, _ => by
      simp only [collectCoordsPoleGuards, Option.some.injEq] at hcol
      exact ⟨[], rfl⟩
  | c :: cs, _, hcol, hgs => by
      unfold collectCoordsPoleGuards at hcol
      cases hrc : reflectExpr Γ_src c with
      | none => rw [hrc] at hcol; contradiction
      | some rc =>
        cases hrest : collectCoordsPoleGuards Γ_src cs with
        | none => rw [hrc, hrest] at hcol; contradiction
        | some rest =>
          rw [hrc, hrest] at hcol
          simp only [Option.some.injEq] at hcol
          subst hcol
          rcases guardsHold_append.mp hgs with ⟨hg_c, hg_rest⟩
          have hisSome := (thm_gpr_domain_exact c Γ_src ρ rc henv hrc).mp hg_c
          cases hdc : denoteExpr ρ c with
          | none => rw [hdc] at hisSome; contradiction
          | some vc =>
              rcases lem_collectCoordsPoleGuards_evalCoords henv hrest hg_rest with ⟨vs, hvs⟩
              exact ⟨vc :: vs, by simp [evalCoords, hdc, hvs]⟩

/-- Pairwise discharge checker for pulled-back equality propositions via `StageA.auditProof`. -/
def checkHypListProofs
    (Γ_vars : VarCtxQ0) (Γ_hyps : HypCtxQ0) (Ω : List GuardQ0) :
    List ProofCertQ0 → HypCtxQ0 → Bool
  | [], [] => true
  | cert :: cs, (.eqProp lhs rhs) :: ps =>
      (auditProof Γ_vars Γ_hyps Ω cert lhs rhs == SyndromeQ0.zero) &&
      checkHypListProofs Γ_vars Γ_hyps Ω cs ps
  | _, _ => false

theorem lem_checkHypListProofs_sound
    (Γ_vars : VarCtxQ0) (Γ_hyps : HypCtxQ0) (Ω : List GuardQ0) (ρ : List Rat)
    (henv : EnvModelsCtx ρ Γ_vars)
    (hhyps : HypsHold ρ Γ_hyps)
    (hguards : GuardsHold ρ Ω) :
    ∀ (certs : List ProofCertQ0) (targets : HypCtxQ0),
      checkHypListProofs Γ_vars Γ_hyps Ω certs targets = true →
      HypsHold ρ targets
  | [], [], _ => fun _ hm => by simp at hm
  | [], _ :: _, h => by simp [checkHypListProofs] at h
  | _ :: _, [], h => by simp [checkHypListProofs] at h
  | cert :: cs, (.eqProp lhs rhs) :: ps, h => by
      simp only [checkHypListProofs, Bool.and_eq_true, beq_iff_eq] at h
      have hstrong := (thm_syndrome_sound cert Γ_vars Γ_hyps Ω lhs rhs h.1).2 ρ henv hhyps hguards
      rcases hstrong with ⟨v, hl, hr⟩
      have hd : denoteProp ρ (.eqProp lhs rhs) = some true := by
        simp [denoteProp, hl, hr]
      have tl := lem_checkHypListProofs_sound Γ_vars Γ_hyps Ω ρ henv hhyps hguards cs ps h.2
      intro ψ hψ
      cases List.mem_cons.mp hψ with
      | inl heq => subst heq; exact hd
      | inr htl => exact tl ψ htl

/-- Static unit & well-typedness check for a `BridgeMorphismQ0` (excluding authority check). -/
def checkBridgeUnitsOnly (f : BridgeMorphismQ0) : Bool :=
  wellTypedContext f.src &&
  wellTypedContext f.dst &&
  checkCoordsUnits f.src.vars f.coords f.dst.vars

/-- Full static check (`Units` + `AuthorityLe`). -/
def checkBridgeStatic (f : BridgeMorphismQ0) : Bool :=
  checkBridgeUnitsOnly f && checkAuthorityLe f.dstAuth f.srcAuth

/-- Certificate bundling total coordinate definedness, pulled-back equality proofs,
    and pulled-back guard proofs for a `BridgeMorphismQ0`. -/
structure BridgeCertQ0 where
  coordPoleProofs : List BridgeGuardProofQ0
  hypPullProofs   : List ProofCertQ0
  guardPullProofs : List BridgeGuardProofQ0
  deriving DecidableEq, Repr, Inhabited

/-- Complete computable checker for a `BridgeMorphismQ0` and its `BridgeCertQ0`. -/
def checkBridgeCert (f : BridgeMorphismQ0) (cert : BridgeCertQ0) : Bool :=
  if !checkBridgeStatic f then false
  else
    match collectCoordsPoleGuards f.src.vars f.coords with
    | none => false
    | some poleGuards =>
        checkBridgeGuardList f.src.vars f.src.hyps f.src.guards cert.coordPoleProofs poleGuards &&
        checkHypListProofs f.src.vars f.src.hyps f.src.guards cert.hypPullProofs
          (pullbackHyps f.coords f.dst.hyps) &&
        checkBridgeGuardList f.src.vars f.src.hyps f.src.guards cert.guardPullProofs
          (pullbackGuards f.coords f.dst.guards)

/-- Target Theorem `thm_transport_maps_valid_domain` (`Tribunal Condition 2` & `2.A`):
    Whenever `checkBridgeCert f cert = true`, authority non-escalation holds AND for EVERY
    source point `ρ ∈ Real_ℚ(f.src)`, all coordinate expressions evaluate to `some ρ'` with
    `ρ' ∈ Real_ℚ(f.dst)` (preserving destination context length, equalities, and guards). -/
theorem thm_transport_maps_valid_domain
    (f : BridgeMorphismQ0) (cert : BridgeCertQ0)
    (hcert : checkBridgeCert f cert = true) :
    AuthorityLe f.dstAuth f.srcAuth ∧
    ∀ ρ : List Rat, ValidDomainQ0 ρ f.src →
      ∃ ρ' : List Rat, evalCoords ρ f.coords = some ρ' ∧ ValidDomainQ0 ρ' f.dst := by
  unfold checkBridgeCert at hcert
  cases hstat : checkBridgeStatic f with
  | false => simp [hstat] at hcert
  | true =>
      simp only [hstat, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hcert
      unfold checkBridgeStatic checkBridgeUnitsOnly at hstat
      simp only [Bool.and_eq_true] at hstat
      rcases hstat with ⟨⟨⟨_, hwt_dst⟩, hc_units⟩, hauth_b⟩
      have hauth := (lem_checkAuthorityLe_iff f.dstAuth f.srcAuth).mp hauth_b
      cases hpoles : collectCoordsPoleGuards f.src.vars f.coords with
      | none => rw [hpoles] at hcert; contradiction
      | some poleGuards =>
          rw [hpoles] at hcert
          simp only [Bool.and_eq_true] at hcert
          rcases hcert with ⟨⟨hpole_chk, hhyp_chk⟩, hgrd_chk⟩
          refine ⟨hauth, fun ρ hvalid => ?_⟩
          rcases hvalid with ⟨henv, hhyps, hguards⟩
          have hpole_hold := thm_bridge_guard_list_sound
            f.src.vars f.src.hyps f.src.guards ρ henv hhyps hguards
            cert.coordPoleProofs poleGuards hpole_chk
          rcases lem_collectCoordsPoleGuards_evalCoords henv hpoles hpole_hold with ⟨ρ', hev⟩
          have hlen_coords : f.coords.length = f.dst.vars.length := checkCoordsUnits_length hc_units
          have henv' : EnvModelsCtx ρ' f.dst.vars := by
            unfold EnvModelsCtx
            rw [evalCoords_length hev, hlen_coords]
          unfold wellTypedContext at hwt_dst
          simp only [Bool.and_eq_true, List.all_eq_true] at hwt_dst
          rcases hwt_dst with ⟨hwt_hyps_dst, hwt_grds_dst⟩
          have hpull_hyps := lem_checkHypListProofs_sound
            f.src.vars f.src.hyps f.src.guards ρ henv hhyps hguards
            cert.hypPullProofs (pullbackHyps f.coords f.dst.hyps) hhyp_chk
          have hhyps' : HypsHold ρ' f.dst.hyps := by
            intro ψ hψ
            have hw_dst : wellScopedProp f.dst.vars.length ψ = true :=
              wellTypedProp_imp_wellScoped (hwt_hyps_dst ψ hψ)
            have hw_c : wellScopedProp f.coords.length ψ = true := by
              rw [hlen_coords]; exact hw_dst
            have hmem_pull : substPropMap f.coords ψ ∈ pullbackHyps f.coords f.dst.hyps := by
              unfold pullbackHyps
              exact List.mem_map.mpr ⟨ψ, hψ, rfl⟩
            have hp := hpull_hyps (substPropMap f.coords ψ) hmem_pull
            rw [lem_substPropMap_denote hev ψ hw_c] at hp
            exact hp
          have hpull_grds := thm_bridge_guard_list_sound
            f.src.vars f.src.hyps f.src.guards ρ henv hhyps hguards
            cert.guardPullProofs (pullbackGuards f.coords f.dst.guards) hgrd_chk
          have hguards' : GuardsHold ρ' f.dst.guards := by
            intro ω hω
            have hsu_dst : (synthUnit f.dst.vars (guardExpr ω)).isSome = true :=
              hwt_grds_dst ω hω
            cases hsu_opt : synthUnit f.dst.vars (guardExpr ω) with
            | none => rw [hsu_opt] at hsu_dst; contradiction
            | some u_ω =>
                have hw_dst : wellScoped f.dst.vars.length (guardExpr ω) = true :=
                  synthUnit_imp_wellScoped (guardExpr ω) hsu_opt
                have hw_c : wellScoped f.coords.length (guardExpr ω) = true := by
                  rw [hlen_coords]; exact hw_dst
                have hmem_pull : substGuardMap f.coords ω ∈ pullbackGuards f.coords f.dst.guards := by
                  unfold pullbackGuards
                  exact List.mem_map.mpr ⟨ω, hω, rfl⟩
                have hg := hpull_grds (substGuardMap f.coords ω) hmem_pull
                rw [lem_substGuardMap_eval hev ω hw_c] at hg
                exact hg
          exact ⟨ρ', hev, henv', hhyps', hguards'⟩

/-- Static Safe-Domain Pullback Inclusion (`Tribunal Refinement 2.D`):
    Explicitly states static set pullback `Real_ℚ(src) ⊆ f⁻¹(Real_ℚ(dst))` (distinct from
    dynamical ODE/CBF forward time-invariance, which requires vector-field dynamics). -/
theorem thm_static_domain_pullback
    (f : BridgeMorphismQ0) (cert : BridgeCertQ0)
    (hcert : checkBridgeCert f cert = true)
    (ρ : List Rat) (hρ : ValidDomainQ0 ρ f.src) :
    ∃ ρ' : List Rat, evalCoords ρ f.coords = some ρ' ∧ ValidDomainQ0 ρ' f.dst :=
  (thm_transport_maps_valid_domain f cert hcert).2 ρ hρ

/-- Syntactic & authority composition of two consecutive bridges `f12 : C1 → C2` and `f23 : C2 → C3`. -/
def compBridge (f12 f23 : BridgeMorphismQ0) : BridgeMorphismQ0 :=
  { src     := f12.src
    dst     := f23.dst
    coords  := compCoords f12.coords f23.coords
    srcAuth := f12.srcAuth
    dstAuth := f23.dstAuth }

theorem thm_compBridge_units_preserved
    {f12 f23 : BridgeMorphismQ0}
    (hmid : f12.dst.vars = f23.src.vars)
    (hu12 : checkCoordsUnits f12.src.vars f12.coords f12.dst.vars = true)
    (hu23 : checkCoordsUnits f23.src.vars f23.coords f23.dst.vars = true) :
    checkCoordsUnits f12.src.vars (compBridge f12 f23).coords f23.dst.vars = true := by
  have go : ∀ {cs : List ExprQ0} {us : VarCtxQ0},
      checkCoordsUnits f23.src.vars cs us = true →
      checkCoordsUnits f12.src.vars (cs.map (substMap f12.coords)) us = true := by
    intro cs us hcs
    induction cs generalizing us with
    | nil =>
        cases us with
        | nil => rfl
        | cons _ _ => simp [checkCoordsUnits] at hcs
    | cons c rest ih =>
        cases us with
        | nil => simp [checkCoordsUnits] at hcs
        | cons u urest =>
            simp only [List.map_cons, checkCoordsUnits, Bool.and_eq_true, beq_iff_eq] at hcs ⊢
            have hwc : wellScoped f12.dst.vars.length c = true := by
              rw [hmid]
              exact synthUnit_imp_wellScoped c hcs.1
            have hsu := lem_substMap_unit c hu12 hwc
            rw [hmid, hcs.1] at hsu
            exact ⟨hsu, ih hcs.2⟩
  exact go hu23

end GrandZero.StageB
