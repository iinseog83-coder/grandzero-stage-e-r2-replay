/-
  GRANDZERO Ω — Stage C (Finite Rational Cellular Sheaf & Global Consistency Gate)
  Module C-5: Q0StageCAdversarialVectors.lean
  Scope:
    Mechanized formal theorems (`0 sorry`, `0 custom axiom`, `0 native_decide`)
    and structured audit records for orthogonal verification vectors `TC-01 ~ TC-07`:
      - `TC-01`  : Filled Triangle Affine Scale/Offset Sheaf (`verifiedCompatGlobalSection 1 0`)
                   + `tc01_stageB_affine_vs_nonlinear_gate` (accepts affine `Stage B` bridge,
                     rejects nonlinear `TB-02` rational bridge `v / (1 + κ v)`).
      - `TC-02`  : Hollow 3-Cycle Holonomy / Non-Coboundary Loop (`verifiedCohomologyObstruction 1 1`
                   + `∀ x, δ⁰ x ≠ η` + universal exclusion of `verifiedCompatGlobalSection`).
      - `TC-03`  : `H¹ = 0` Trap A — Non-Cocycle 2-Face Curvature (`verifiedFaceCurvatureFailure 1 0`
                   on filled triangle with `h¹ = 0` + `∀ x, δ⁰ x ≠ η` + universal exclusions).
      - `TC-04a` : `H¹ = 0` Trap B1 — Conflicting Vertex Anchors (`verifiedAnchorOrGuardIncompatibility 1 0`
                   via `.affineFarkasDual` + `∃ x_lin, δ⁰ x_lin = η` + `∀ x, x ∉ S`).
      - `TC-04b` : `H¹ = 0` Trap B2 — Pinned Stalk Positivity Guard Violation (`verifiedAnchorOrGuardIncompatibility 1 0`
                   via `.pinnedStalkDomainViolation` + `∃ x_lin, δ⁰ x_lin = η` + `∀ x, x ∉ S`).
      - `TC-05a` : Topological Boundary Sign Flip (`∀ bundle, rejectedInvalidComplexOrSheaf .boundaryNotNilpotent`).
      - `TC-05b` : Valid `∂₁ ∂₂ = 0` & Units but Non-Functorial Diamond (`∀ bundle, rejectedInvalidComplexOrSheaf .nonFunctorialSheafRestriction`).
      - `TC-06`  : Forged `h¹ = 0` Cohomology Certificate on Hollow 3-Cycle (`rejectedInvalidCertificate`).
      - `TC-07a` : Energy (`J`) → Torque (`N·m`) Restriction Matrix Smuggling (`∀ bundle, rejectedInvalidComplexOrSheaf .illTypedStalkOrMatrix`).
      - `TC-07b` : Multi-Cell 3D Authority Escalation `(1,0,0) → (1,1,0)` (`∀ bundle, rejectedInvalidComplexOrSheaf .authorityEscalation`).
-/

import StageC.Q0AffineStageBBridgeAndGlobalGate

namespace GrandZero.StageC

open GrandZero.StageA
open GrandZero.StageB

/-! ### Part 1: Base Filled-Triangle Unit-Typed Cellular Sheaf (`TC-01`, `TC-03`, `TC-04a`, `TC-04b`) -/

/-- Vertex contexts on the filled triangle `X_tri`:
    - `v = 0`: `energy` (`J`) with positivity guard `x_0 > 0`,
    - `v = 1`: `energy` (`J`) with positivity guard `x_1 > 0`,
    - `v = 2`: `unitless` (nondimensionalized energy at `E_ref = 2 J`) with positivity guard `x_2 > 0`. -/
def tc01_vCtx : Fin 3 → ContextQ0
  | ⟨0, _⟩ => { vars := [UnitSpecQ0.energy],   hyps := [], guards := [.pos (.bvar 0)] }
  | ⟨1, _⟩ => { vars := [UnitSpecQ0.energy],   hyps := [], guards := [.pos (.bvar 0)] }
  | ⟨2, _⟩ => { vars := [UnitSpecQ0.unitless], hyps := [], guards := [.pos (.bvar 0)] }

def tc01_eVars : Fin 3 → VarCtxQ0 := fun _ => [UnitSpecQ0.energy]
def tc01_fVars : Fin 1 → VarCtxQ0 := fun _ => [UnitSpecQ0.energy]

/-- Signed vertex-edge incidence `∂₁` for `e0: 0→1`, `e1: 1→2`, `e2: 0→2`. -/
def tc01_incVE : MatQ0 3 3 :=
  matOfLists 3 3 [
    [-1,  0, -1],
    [ 1, -1,  0],
    [ 0,  1,  1]
  ]

/-- Oriented triangle boundary `∂₂ = [1, 1, -1]ᵀ` satisfying `∂₁ ∂₂ = 0`. -/
def tc01_incEF : MatQ0 3 1 :=
  matOfLists 3 1 [[1], [1], [-1]]

/-- Vertex-to-edge restriction matrices:
    `v = 0, 1` restrict by `1` (`unitless * energy = energy`),
    `v = 2` redimensionalizes by `2 J` (`energy * unitless = energy`). -/
def tc01_resVE (v : Fin 3) (e : Fin 3) : MatQ0 (tc01_eVars e).length (tc01_vCtx v).vars.length :=
  match v.val, e.val with
  | 0, 0 | 0, 2 => fun _ _ => 1
  | 1, 0 | 1, 1 => fun _ _ => 1
  | 2, 1 | 2, 2 => fun _ _ => 2
  | _, _        => fun _ _ => 0

def tc01_unitVE (v : Fin 3) (e : Fin 3) :
    Fin (tc01_eVars e).length → Fin (tc01_vCtx v).vars.length → UnitSpecQ0 :=
  match v.val with
  | 2 => fun _ _ => UnitSpecQ0.energy
  | _ => fun _ _ => UnitSpecQ0.unitless

def tc01_resEF (e : Fin 3) (f : Fin 1) : MatQ0 (tc01_fVars f).length (tc01_eVars e).length :=
  fun _ _ => 1

def tc01_unitEF (e : Fin 3) (f : Fin 1) :
    Fin (tc01_fVars f).length → Fin (tc01_eVars e).length → UnitSpecQ0 :=
  fun _ _ => UnitSpecQ0.unitless

def tc01_sheaf : CellularSheafQ0 :=
  { nV                := 3
    nE                := 3
    nF                := 1
    vCtx              := tc01_vCtx
    eVars             := tc01_eVars
    fVars             := tc01_fVars
    incVE             := tc01_incVE
    incEF             := tc01_incEF
    resVE             := tc01_resVE
    unitVE            := tc01_unitVE
    resEF             := tc01_resEF
    unitEF            := tc01_unitEF
    vAuth             := fun _ => AuthorityVecQ0.formalOnly
    eAuth             := fun _ => AuthorityVecQ0.formalOnly
    claimedGlobalAuth := AuthorityVecQ0.formalOnly }

/-- Exact `CohomologyComplementBasis` for `tc01_sheaf` (`N0 = 3, N1 = 3, N2 = 1`):
    `δ⁰` has rank `r0 = 2`, `h⁰ = k0 = 1` (`K0 = [2, 2, 1]ᵀ`),
    `δ¹` has rank `r1 = 1`, `k1 = 2`, and `h¹ = 0` (`H¹(X_tri; F) = 0`). -/
def tc01_cohomCert : CohomologyComplementBasis tc01_sheaf.N0 tc01_sheaf.N1 tc01_sheaf.N2 :=
  { rn0 :=
      { r := 2
        k := 1
        U := matOfLists tc01_sheaf.N0 2 [[1, 0], [0, 1], [0, 0]]
        B := matOfLists tc01_sheaf.N1 2 [[-1, 1], [0, -1], [-1, 0]]
        L := matOfLists 2 tc01_sheaf.N1 [[-1, -1, 0], [0, -1, 0]]
        K := matOfLists tc01_sheaf.N0 1 [[2], [2], [1]]
        R := matOfLists 1 tc01_sheaf.N0 [[0, 0, 1]] }
    rn1 :=
      { r := 1
        k := 2
        U := matOfLists tc01_sheaf.N1 1 [[0], [0], [-1]]
        B := matOfLists tc01_sheaf.N2 1 [[1]]
        L := matOfLists 1 tc01_sheaf.N2 [[1]]
        K := matOfLists tc01_sheaf.N1 2 [[-1, 1], [0, -1], [-1, 0]]
        R := matOfLists 2 tc01_sheaf.N1 [[-1, -1, 0], [0, -1, 0]] }
    h1  := 0
    H   := zeroMat tc01_sheaf.N1 0
    LB0 := matOfLists 2 tc01_sheaf.N1 [[-1, -1, 0], [0, -1, 0]]
    LH  := zeroMat 0 tc01_sheaf.N1 }

/-! ### Vector `TC-01`: Filled Triangle Compatible Guarded Global Section (`verifiedCompatGlobalSection 1 0`) -/

def tc01_eta  : VecQ0 tc01_sheaf.N1 := vecOfList tc01_sheaf.N1 [2, 2, 4]
def tc01_Apin : MatQ0 1 tc01_sheaf.N0 := matOfLists 1 tc01_sheaf.N0 [[1, 0, 0]]
def tc01_cpin : VecQ0 1 := vecOfList 1 [8]
def tc01_xSol : VecQ0 tc01_sheaf.N0 := vecOfList tc01_sheaf.N0 [8, 10, 6]

def tc01_bundle : StageCCertBundleQ0 tc01_sheaf 1 :=
  { cohomCert := tc01_cohomCert
    payload   := .compatGlobalSection tc01_xSol }

theorem tc01_filled_triangle_compat_global_section :
    auditCellularSheafGate tc01_sheaf tc01_eta tc01_Apin tc01_cpin tc01_bundle =
      .verifiedCompatGlobalSection 1 0 ∧
    (∃ xSol : VecQ0 tc01_sheaf.N0,
      InGlobalSolutionSet tc01_sheaf tc01_eta tc01_Apin tc01_cpin xSol) := by
  have h : auditCellularSheafGate tc01_sheaf tc01_eta tc01_Apin tc01_cpin tc01_bundle =
      .verifiedCompatGlobalSection 1 0 := by
    with_unfolding_all rfl
  exact ⟨h, (thm_stageC_compat_section_sound tc01_sheaf tc01_eta tc01_Apin tc01_cpin tc01_bundle 1 0 h).2.2.2.2.2.2⟩

/-- Explicit verification of the `Stage B → Stage C` Exact Affine Gate (`__NONLINEAR_STAGE_B_COMPATIBILITY_HELD`):
    1. Accepts the affine `Stage B` redimensionalization expression `2_J * x + 4_J` (`= true`)
       and certifies `StrongEq` over all environments.
    2. Rejects (`= false`) `TB-02`'s nonlinear rational bridge `v / (1 + κ v)`! -/
def tc01_affine_stageB_expr : ExprQ0 :=
  .binOp .add (.binOp .mul (.ratLit 2 UnitSpecQ0.energy) (.bvar 0)) (.ratLit 4 UnitSpecQ0.energy)

def tc01_nonlinear_tb02_expr : ExprQ0 :=
  .binOp .div (.bvar 0)
    (.binOp .add (.ratLit 1 UnitSpecQ0.unitless) (.binOp .mul (.bvar 1) (.bvar 0)))

theorem tc01_stageB_affine_vs_nonlinear_gate :
    checkExactAffineEquiv [UnitSpecQ0.unitless] tc01_affine_stageB_expr
      (vecOfList 1 [2]) (fun _ => UnitSpecQ0.energy) 4 UnitSpecQ0.energy = true ∧
    checkExactAffineEquiv [velUnit, invVelUnit] tc01_nonlinear_tb02_expr
      (vecOfList 2 [1, 0]) (fun i => if i.val = 0 then UnitSpecQ0.unitless else velUnit) 0 velUnit = false := by
  constructor <;> with_unfolding_all rfl

/-! ### Vector `TC-02`: Hollow 3-Cycle Non-Coboundary Loop (`verifiedCohomologyObstruction 1 1`) -/

def tc02_vCtx : Fin 3 → ContextQ0 :=
  fun _ => { vars := [UnitSpecQ0.unitless], hyps := [], guards := [] }

def tc02_eVars : Fin 3 → VarCtxQ0 := fun _ => [UnitSpecQ0.unitless]
def tc02_fVars : Fin 0 → VarCtxQ0 := fun _ => []

/-- Hollow 3-cycle `0 → 1 → 2 → 0` with `0` faces (`nF = 0`). -/
def tc02_incVE : MatQ0 3 3 :=
  matOfLists 3 3 [
    [-1,  0,  1],
    [ 1, -1,  0],
    [ 0,  1, -1]
  ]

def tc02_resVE (v : Fin 3) (e : Fin 3) : MatQ0 (tc02_eVars e).length (tc02_vCtx v).vars.length :=
  if tc02_incVE v e == 0 then (fun _ _ => 0) else (fun _ _ => 1)

def tc02_sheaf : CellularSheafQ0 :=
  { nV                := 3
    nE                := 3
    nF                := 0
    vCtx              := tc02_vCtx
    eVars             := tc02_eVars
    fVars             := tc02_fVars
    incVE             := tc02_incVE
    incEF             := zeroMat 3 0
    resVE             := tc02_resVE
    unitVE            := fun _ _ _ _ => UnitSpecQ0.unitless
    resEF             := fun _ _ _ _ => 0
    unitEF            := fun _ _ _ _ => UnitSpecQ0.unitless
    vAuth             := fun _ => AuthorityVecQ0.formalOnly
    eAuth             := fun _ => AuthorityVecQ0.formalOnly
    claimedGlobalAuth := AuthorityVecQ0.formalOnly }

/-- Exact `CohomologyComplementBasis` for hollow 3-cycle `tc02_sheaf`:
    `r0 = 2, h⁰ = 1`, `r1 = 0, k1 = 3`, and `h¹ = 1` (`H = [0, 0, 1]ᵀ`, `LH = [1, 1, 1]`). -/
def tc02_cohomCert : CohomologyComplementBasis tc02_sheaf.N0 tc02_sheaf.N1 tc02_sheaf.N2 :=
  { rn0 :=
      { r := 2
        k := 1
        U := matOfLists tc02_sheaf.N0 2 [[1, 0], [0, 1], [0, 0]]
        B := matOfLists tc02_sheaf.N1 2 [[-1, 1], [0, -1], [1, 0]]
        L := matOfLists 2 tc02_sheaf.N1 [[-1, -1, 0], [0, -1, 0]]
        K := matOfLists tc02_sheaf.N0 1 [[1], [1], [1]]
        R := matOfLists 1 tc02_sheaf.N0 [[0, 0, 1]] }
    rn1 :=
      { r := 0
        k := 3
        U := zeroMat tc02_sheaf.N1 0
        B := zeroMat tc02_sheaf.N2 0
        L := zeroMat 0 tc02_sheaf.N2
        K := idMat tc02_sheaf.N1
        R := idMat tc02_sheaf.N1 }
    h1  := 1
    H   := matOfLists tc02_sheaf.N1 1 [[0], [0], [1]]
    LB0 := matOfLists 2 tc02_sheaf.N1 [[-1, -1, 0], [0, -1, 0]]
    LH  := matOfLists 1 tc02_sheaf.N1 [[1, 1, 1]] }

def tc02_eta   : VecQ0 tc02_sheaf.N1 := vecOfList tc02_sheaf.N1 [0, 0, 1]
def tc02_yDual : VecQ0 tc02_sheaf.N1 := vecOfList tc02_sheaf.N1 [1, 1, 1]
def tc02_Apin  : MatQ0 0 tc02_sheaf.N0 := zeroMat 0 tc02_sheaf.N0
def tc02_cpin  : VecQ0 0 := zeroVec 0

def tc02_bundle : StageCCertBundleQ0 tc02_sheaf 0 :=
  { cohomCert := tc02_cohomCert
    payload   := .cohomologyObstruction tc02_yDual }

theorem tc02_hollow_cycle_cohomology_obstruction :
    auditCellularSheafGate tc02_sheaf tc02_eta tc02_Apin tc02_cpin tc02_bundle =
      .verifiedCohomologyObstruction 1 1 ∧
    matVec (assembleDelta1 tc02_sheaf) tc02_eta = zeroVec tc02_sheaf.N2 ∧
    (∀ x : VecQ0 tc02_sheaf.N0, matVec (assembleDelta0 tc02_sheaf) x ≠ tc02_eta) ∧
    (∀ b_any : StageCCertBundleQ0 tc02_sheaf 0, ∀ k0 k1 : Nat,
      auditCellularSheafGate tc02_sheaf tc02_eta tc02_Apin tc02_cpin b_any ≠
        .verifiedCompatGlobalSection k0 k1) := by
  have h : auditCellularSheafGate tc02_sheaf tc02_eta tc02_Apin tc02_cpin tc02_bundle =
      .verifiedCohomologyObstruction 1 1 := by
    with_unfolding_all rfl
  rcases thm_stageC_cohomology_obstruction_sound_and_exclusive
    tc02_sheaf tc02_eta tc02_Apin tc02_cpin tc02_bundle 1 1 h with ⟨hd1, _, hno, hexcl⟩
  exact ⟨h, hd1, hno, hexcl⟩

/-! ### Vector `TC-03`: `H¹ = 0` Trap A — Non-Cocycle Face Curvature (`verifiedFaceCurvatureFailure 1 0`) -/

def tc03_eta   : VecQ0 tc01_sheaf.N1 := vecOfList tc01_sheaf.N1 [1, 1, 0]
def tc03_Apin  : MatQ0 0 tc01_sheaf.N0 := zeroMat 0 tc01_sheaf.N0
def tc03_cpin  : VecQ0 0 := zeroVec 0

def tc03_bundle : StageCCertBundleQ0 tc01_sheaf 0 :=
  { cohomCert := tc01_cohomCert
    payload   := .curvatureClaim }

theorem tc03_filled_triangle_face_curvature_failure :
    auditCellularSheafGate tc01_sheaf tc03_eta tc03_Apin tc03_cpin tc03_bundle =
      .verifiedFaceCurvatureFailure 1 0 ∧
    tc01_cohomCert.h1 = 0 ∧
    matVec (assembleDelta1 tc01_sheaf) tc03_eta ≠ zeroVec tc01_sheaf.N2 ∧
    (∀ x : VecQ0 tc01_sheaf.N0, matVec (assembleDelta0 tc01_sheaf) x ≠ tc03_eta) ∧
    (∀ b_any : StageCCertBundleQ0 tc01_sheaf 0, ∀ k0 k1 : Nat,
      auditCellularSheafGate tc01_sheaf tc03_eta tc03_Apin tc03_cpin b_any ≠
        .verifiedCompatGlobalSection k0 k1 ∧
      auditCellularSheafGate tc01_sheaf tc03_eta tc03_Apin tc03_cpin b_any ≠
        .verifiedCohomologyObstruction k0 k1) := by
  have h : auditCellularSheafGate tc01_sheaf tc03_eta tc03_Apin tc03_cpin tc03_bundle =
      .verifiedFaceCurvatureFailure 1 0 := by
    with_unfolding_all rfl
  rcases thm_stageC_face_curvature_sound_and_exclusive
    tc01_sheaf tc03_eta tc03_Apin tc03_cpin tc03_bundle 1 0 h with ⟨hnz, hno, hexcl⟩
  exact ⟨h, rfl, hnz, hno, hexcl⟩

/-! ### Vectors `TC-04a` & `TC-04b`: `H¹ = 0` Trap B — Anchor & Positivity-Guard Incompatibility (`Condition B`) -/

/-- `TC-04a`: `h¹ = 0` and `η = 0 ∈ im(δ⁰)`, but anchors `x_0 = 10` and `x_2 = 8` conflict
    across `δ⁰ x = 0` (`-x_0 + 2 x_2 = 0`), refuted universally via `.affineFarkasDual`. -/
def tc04_eta    : VecQ0 tc01_sheaf.N1 := zeroVec tc01_sheaf.N1
def tc04a_Apin  : MatQ0 2 tc01_sheaf.N0 := matOfLists 2 tc01_sheaf.N0 [[1, 0, 0], [0, 0, 1]]
def tc04a_cpin  : VecQ0 2 := vecOfList 2 [10, 8]

def tc04a_bundle : StageCCertBundleQ0 tc01_sheaf 2 :=
  { cohomCert := tc01_cohomCert
    payload   := .anchorOrGuardUnsat
      (.affineFarkasDual (vecOfList tc01_sheaf.N1 [0, 0, 1]) (vecOfList 2 [1, -2])) }

theorem tc04a_anchor_farkas_incompatibility :
    auditCellularSheafGate tc01_sheaf tc04_eta tc04a_Apin tc04a_cpin tc04a_bundle =
      .verifiedAnchorOrGuardIncompatibility 1 0 ∧
    (∃ x_lin : VecQ0 tc01_sheaf.N0, matVec (assembleDelta0 tc01_sheaf) x_lin = tc04_eta) ∧
    (∀ x : VecQ0 tc01_sheaf.N0, ¬ InGlobalSolutionSet tc01_sheaf tc04_eta tc04a_Apin tc04a_cpin x) ∧
    (∀ b_any : StageCCertBundleQ0 tc01_sheaf 2, ∀ k0 k1 : Nat,
      auditCellularSheafGate tc01_sheaf tc04_eta tc04a_Apin tc04a_cpin b_any ≠
        .verifiedCompatGlobalSection k0 k1) := by
  have h : auditCellularSheafGate tc01_sheaf tc04_eta tc04a_Apin tc04a_cpin tc04a_bundle =
      .verifiedAnchorOrGuardIncompatibility 1 0 := by
    with_unfolding_all rfl
  rcases thm_stageC_incompatibility_sound_and_exclusive
    tc01_sheaf tc04_eta tc04a_Apin tc04a_cpin tc04a_bundle 1 0 h with ⟨hlin, hunsat, hexcl⟩
  exact ⟨h, hlin, hunsat, hexcl⟩

/-- `TC-04b`: `h¹ = 0`, `η = 0`, and single anchor `x_0 = -4` HAS a linear solution `[-4, -4, -2]ᵀ`,
    yet forces vertex `v = 1` to `x_1 = -4`, violating its semi-algebraic positivity guard `x_1 > 0`!
    Refuted universally (`S = ∅`) via `.pinnedStalkDomainViolation`. -/
def tc04b_Apin : MatQ0 1 tc01_sheaf.N0 := matOfLists 1 tc01_sheaf.N0 [[1, 0, 0]]
def tc04b_cpin : VecQ0 1 := vecOfList 1 [-4]

def tc04b_bundle : StageCCertBundleQ0 tc01_sheaf 1 :=
  { cohomCert := tc01_cohomCert
    payload   := .anchorOrGuardUnsat
      (.pinnedStalkDomainViolation
        ⟨1, by decide⟩
        (matOfLists (tc01_sheaf.dV ⟨1, by decide⟩) tc01_sheaf.N1 [[1, 0, 0]])
        (matOfLists (tc01_sheaf.dV ⟨1, by decide⟩) 1 [[1]])) }

theorem tc04b_guard_domain_incompatibility :
    auditCellularSheafGate tc01_sheaf tc04_eta tc04b_Apin tc04b_cpin tc04b_bundle =
      .verifiedAnchorOrGuardIncompatibility 1 0 ∧
    (∃ x_lin : VecQ0 tc01_sheaf.N0,
      matVec (assembleDelta0 tc01_sheaf) x_lin = tc04_eta ∧
      matVec tc04b_Apin x_lin = tc04b_cpin) ∧
    (∀ x : VecQ0 tc01_sheaf.N0, ¬ InGlobalSolutionSet tc01_sheaf tc04_eta tc04b_Apin tc04b_cpin x) ∧
    (∀ b_any : StageCCertBundleQ0 tc01_sheaf 1, ∀ k0 k1 : Nat,
      auditCellularSheafGate tc01_sheaf tc04_eta tc04b_Apin tc04b_cpin b_any ≠
        .verifiedCompatGlobalSection k0 k1) := by
  have h : auditCellularSheafGate tc01_sheaf tc04_eta tc04b_Apin tc04b_cpin tc04b_bundle =
      .verifiedAnchorOrGuardIncompatibility 1 0 := by
    with_unfolding_all rfl
  rcases thm_stageC_incompatibility_sound_and_exclusive
    tc01_sheaf tc04_eta tc04b_Apin tc04b_cpin tc04b_bundle 1 0 h with ⟨_, hunsat, hexcl⟩
  have hlin_both :
      matVec (assembleDelta0 tc01_sheaf) (vecOfList tc01_sheaf.N0 [-4, -4, -2]) = tc04_eta ∧
      matVec tc04b_Apin (vecOfList tc01_sheaf.N0 [-4, -4, -2]) = tc04b_cpin := by
    constructor
    · exact (vecEqBool_iff _ _).mp (by with_unfolding_all rfl)
    · exact (vecEqBool_iff _ _).mp (by with_unfolding_all rfl)
  exact ⟨h, ⟨vecOfList tc01_sheaf.N0 [-4, -4, -2], hlin_both⟩, hunsat, hexcl⟩

/-! ### Vectors `TC-05a` & `TC-05b`: Boundary Sign Flip vs. Non-Functorial Sheaf (`Conditions A & C`) -/

/-- `TC-05a`: Flipped face boundary sign `incEF = [[1], [1], [1]]` (`∂₁ ∂₂ ≠ 0`). -/
def tc05a_sheaf : CellularSheafQ0 :=
  { tc01_sheaf with incEF := matOfLists 3 1 [[1], [1], [1]] }

theorem tc05a_boundary_sign_flip_rejected :
    validateSheafComplexStructure tc05a_sheaf = some .boundaryNotNilpotent ∧
    ∀ (nPin : Nat) (η : VecQ0 tc05a_sheaf.N1)
      (Apin : MatQ0 nPin tc05a_sheaf.N0) (cpin : VecQ0 nPin)
      (bundle : StageCCertBundleQ0 tc05a_sheaf nPin),
      auditCellularSheafGate tc05a_sheaf η Apin cpin bundle =
        .rejectedInvalidComplexOrSheaf .boundaryNotNilpotent := by
  have hv : validateSheafComplexStructure tc05a_sheaf = some .boundaryNotNilpotent := by
    with_unfolding_all rfl
  exact ⟨hv, fun _ η Apin cpin b => thm_stageC_structural_invalid_universal tc05a_sheaf η Apin cpin _ hv b⟩

/-- `TC-05b`: Valid `∂₁ ∂₂ = 0` AND valid physical units (`energy * unitless = energy`),
    but non-commuting diamond restrictions at `v = 2` (`ρ_{2≼e1} = 2 ≠ 3 = ρ_{2≼e2}`). -/
def tc05b_resVE (v : Fin 3) (e : Fin 3) : MatQ0 (tc01_eVars e).length (tc01_vCtx v).vars.length :=
  match v.val, e.val with
  | 0, 0 | 0, 2 => fun _ _ => 1
  | 1, 0 | 1, 1 => fun _ _ => 1
  | 2, 1        => fun _ _ => 2
  | 2, 2        => fun _ _ => 3
  | _, _        => fun _ _ => 0

def tc05b_sheaf : CellularSheafQ0 :=
  { tc01_sheaf with resVE := tc05b_resVE }

theorem tc05b_nonfunctorial_sheaf_rejected :
    checkBoundaryNilpotent tc05b_sheaf = true ∧
    checkSheafUnitsAndContexts tc05b_sheaf = true ∧
    validateSheafComplexStructure tc05b_sheaf = some .nonFunctorialSheafRestriction ∧
    ∀ (nPin : Nat) (η : VecQ0 tc05b_sheaf.N1)
      (Apin : MatQ0 nPin tc05b_sheaf.N0) (cpin : VecQ0 nPin)
      (bundle : StageCCertBundleQ0 tc05b_sheaf nPin),
      auditCellularSheafGate tc05b_sheaf η Apin cpin bundle =
        .rejectedInvalidComplexOrSheaf .nonFunctorialSheafRestriction := by
  have hb : checkBoundaryNilpotent tc05b_sheaf = true := by with_unfolding_all rfl
  have hu : checkSheafUnitsAndContexts tc05b_sheaf = true := by with_unfolding_all rfl
  have hv : validateSheafComplexStructure tc05b_sheaf = some .nonFunctorialSheafRestriction := by
    with_unfolding_all rfl
  exact ⟨hb, hu, hv, fun _ η Apin cpin b =>
    thm_stageC_structural_invalid_universal tc05b_sheaf η Apin cpin _ hv b⟩

/-! ### Vector `TC-06`: Forged `h¹ = 0` Cohomology Certificate on Hollow 3-Cycle (`rejectedInvalidCertificate`) -/

/-- Adversary tries to erase the `H¹` hole on hollow 3-cycle `tc02_sheaf` by forging `h1 := 0`
    and claiming `rn1.k := 2` (`U1 L1 δ1 + K1 R1 = I3` fails!). -/
def tc06_forgedCohomCert : CohomologyComplementBasis tc02_sheaf.N0 tc02_sheaf.N1 tc02_sheaf.N2 :=
  { rn0 := tc02_cohomCert.rn0
    rn1 :=
      { r := 1
        k := 2
        U := zeroMat tc02_sheaf.N1 1
        B := zeroMat tc02_sheaf.N2 1
        L := zeroMat 1 tc02_sheaf.N2
        K := matOfLists tc02_sheaf.N1 2 [[-1, 0], [1, -1], [0, 1]]
        R := matOfLists 2 tc02_sheaf.N1 [[-1, 0, 0], [-1, -1, 0]] }
    h1  := 0
    H   := zeroMat tc02_sheaf.N1 0
    LB0 := matOfLists 2 tc02_sheaf.N1 [[-1, 0, 0], [-1, -1, 0]]
    LH  := zeroMat 0 tc02_sheaf.N1 }

def tc06_forgedBundle : StageCCertBundleQ0 tc02_sheaf 0 :=
  { cohomCert := tc06_forgedCohomCert
    payload   := .compatGlobalSection (zeroVec tc02_sheaf.N0) }

theorem tc06_forged_cohomology_dim_rejected :
    validateSheafComplexStructure tc02_sheaf = none ∧
    checkCohomologyCert (assembleDelta0 tc02_sheaf) (assembleDelta1 tc02_sheaf) tc06_forgedCohomCert = false ∧
    auditCellularSheafGate tc02_sheaf (zeroVec tc02_sheaf.N1) tc02_Apin tc02_cpin tc06_forgedBundle =
      .rejectedInvalidCertificate := by
  refine ⟨?_, ?_, ?_⟩ <;> with_unfolding_all rfl

/-! ### Vectors `TC-07a` & `TC-07b`: `Energy → Torque` Matrix Smuggling & 3D Authority Escalation -/

/-- `TC-07a`: Edge `e0` carries `UnitSpecQ0.torque` (`N·m`, `.torque`) while `v = 0` carries
    `UnitSpecQ0.energy` (`J`, `.canonical`). Rejected at Step 2 before linear algebra runs! -/
def tc07a_eVars : Fin 3 → VarCtxQ0
  | ⟨0, _⟩ => [UnitSpecQ0.torque]
  | _      => [UnitSpecQ0.energy]

def tc07a_sheaf : CellularSheafQ0 :=
  { nV                := 3
    nE                := 3
    nF                := 1
    vCtx              := tc01_vCtx
    eVars             := tc07a_eVars
    fVars             := tc01_fVars
    incVE             := tc01_incVE
    incEF             := tc01_incEF
    resVE             := fun v e => match v.val, e.val with
                          | 0, 0 | 0, 2 => fun _ _ => 1
                          | 1, 0 | 1, 1 => fun _ _ => 1
                          | 2, 1 | 2, 2 => fun _ _ => 2
                          | _, _        => fun _ _ => 0
    unitVE            := fun v _ _ _ => if v.val = 2 then UnitSpecQ0.energy else UnitSpecQ0.unitless
    resEF             := fun _ _ _ _ => 1
    unitEF            := fun _ _ _ _ => UnitSpecQ0.unitless
    vAuth             := fun _ => AuthorityVecQ0.formalOnly
    eAuth             := fun _ => AuthorityVecQ0.formalOnly
    claimedGlobalAuth := AuthorityVecQ0.formalOnly }

theorem tc07a_ill_typed_torque_matrix_rejected :
    checkBoundaryNilpotent tc07a_sheaf = true ∧
    validateSheafComplexStructure tc07a_sheaf = some .illTypedStalkOrMatrix ∧
    ∀ (nPin : Nat) (η : VecQ0 tc07a_sheaf.N1)
      (Apin : MatQ0 nPin tc07a_sheaf.N0) (cpin : VecQ0 nPin)
      (bundle : StageCCertBundleQ0 tc07a_sheaf nPin),
      auditCellularSheafGate tc07a_sheaf η Apin cpin bundle =
        .rejectedInvalidComplexOrSheaf .illTypedStalkOrMatrix := by
  have hb : checkBoundaryNilpotent tc07a_sheaf = true := by with_unfolding_all rfl
  have hv : validateSheafComplexStructure tc07a_sheaf = some .illTypedStalkOrMatrix := by
    with_unfolding_all rfl
  exact ⟨hb, hv, fun _ η Apin cpin b =>
    thm_stageC_structural_invalid_universal tc07a_sheaf η Apin cpin _ hv b⟩

/-- `TC-07b`: Valid sheaf on `X_tri` attempting to escalate purely formal local authority `(1, 0, 0)`
    into empirical authority `(1, 1, 0)` upon global section gluing! -/
def tc07b_sheaf : CellularSheafQ0 :=
  { tc01_sheaf with claimedGlobalAuth := AuthorityVecQ0.formalEmpirical }

theorem tc07b_authority_escalation_rejected :
    checkBoundaryNilpotent tc07b_sheaf = true ∧
    checkSheafUnitsAndContexts tc07b_sheaf = true ∧
    checkSheafFlagFunctoriality tc07b_sheaf = true ∧
    checkCochainNilpotent tc07b_sheaf = true ∧
    validateSheafComplexStructure tc07b_sheaf = some .authorityEscalation ∧
    ∀ (nPin : Nat) (η : VecQ0 tc07b_sheaf.N1)
      (Apin : MatQ0 nPin tc07b_sheaf.N0) (cpin : VecQ0 nPin)
      (bundle : StageCCertBundleQ0 tc07b_sheaf nPin),
      auditCellularSheafGate tc07b_sheaf η Apin cpin bundle =
        .rejectedInvalidComplexOrSheaf .authorityEscalation := by
  have hb  : checkBoundaryNilpotent tc07b_sheaf = true := by with_unfolding_all rfl
  have hu  : checkSheafUnitsAndContexts tc07b_sheaf = true := by with_unfolding_all rfl
  have hf  : checkSheafFlagFunctoriality tc07b_sheaf = true := by with_unfolding_all rfl
  have hcn : checkCochainNilpotent tc07b_sheaf = true := by with_unfolding_all rfl
  have hv  : validateSheafComplexStructure tc07b_sheaf = some .authorityEscalation := by
    with_unfolding_all rfl
  exact ⟨hb, hu, hf, hcn, hv, fun _ η Apin cpin b =>
    thm_stageC_structural_invalid_universal tc07b_sheaf η Apin cpin _ hv b⟩

/-! ### Part 2: Structured Runtime Formatting & Vector Table (`stage_c_audit`) -/

def formatInvalidReason : StageCInvalidReasonQ0 → String
  | .boundaryNotNilpotent          => "boundaryNotNilpotent"
  | .illTypedStalkOrMatrix         => "illTypedStalkOrMatrix"
  | .nonFunctorialSheafRestriction => "nonFunctorialSheafRestriction"
  | .cochainNotNilpotent           => "cochainNotNilpotent"
  | .authorityEscalation           => "authorityEscalation"

def formatStageCOutcome : StageCGateOutcomeQ0 → String
  | .verifiedCompatGlobalSection h0 h1          => s!"verifiedCompatGlobalSection(h0={h0},h1={h1})"
  | .verifiedCohomologyObstruction h0 h1        => s!"verifiedCohomologyObstruction(h0={h0},h1={h1})"
  | .verifiedFaceCurvatureFailure h0 h1         => s!"verifiedFaceCurvatureFailure(h0={h0},h1={h1})"
  | .verifiedAnchorOrGuardIncompatibility h0 h1 => s!"verifiedAnchorOrGuardIncompatibility(h0={h0},h1={h1})"
  | .rejectedInvalidComplexOrSheaf r            => s!"rejectedInvalidComplexOrSheaf({formatInvalidReason r})"
  | .rejectedInvalidCertificate                 => "rejectedInvalidCertificate"

structure StageCVectorRecord where
  vecId    : String
  expected : StageCGateOutcomeQ0
  actual   : StageCGateOutcomeQ0
  detail   : String

def tc05a_dummyBundle : StageCCertBundleQ0 tc05a_sheaf 0 :=
  { cohomCert := tc01_cohomCert, payload := .curvatureClaim }

def tc05b_dummyBundle : StageCCertBundleQ0 tc05b_sheaf 0 :=
  { cohomCert := tc01_cohomCert, payload := .curvatureClaim }

def tc07a_dummyBundle : StageCCertBundleQ0 tc07a_sheaf 0 :=
  { cohomCert := tc01_cohomCert, payload := .curvatureClaim }

def tc07b_dummyBundle : StageCCertBundleQ0 tc07b_sheaf 0 :=
  { cohomCert := tc01_cohomCert, payload := .curvatureClaim }

def stageCVectorRecords : List StageCVectorRecord :=
  [ { vecId    := "TC-01"
      expected := .verifiedCompatGlobalSection 1 0
      actual   := auditCellularSheafGate tc01_sheaf tc01_eta tc01_Apin tc01_cpin tc01_bundle
      detail   := "FilledTriangle_UnitScaledSheaf_GuardedSection_x=[8,10,6]" },
    { vecId    := "TC-02"
      expected := .verifiedCohomologyObstruction 1 1
      actual   := auditCellularSheafGate tc02_sheaf tc02_eta tc02_Apin tc02_cpin tc02_bundle
      detail   := "Hollow3Cycle_HolonomyCocycle_DualWitness_y=[1,1,1]" },
    { vecId    := "TC-03"
      expected := .verifiedFaceCurvatureFailure 1 0
      actual   := auditCellularSheafGate tc01_sheaf tc03_eta tc03_Apin tc03_cpin tc03_bundle
      detail   := "FilledTriangle_H1Zero_NonCocycleCurvature_delta1Eta=[2]" },
    { vecId    := "TC-04a"
      expected := .verifiedAnchorOrGuardIncompatibility 1 0
      actual   := auditCellularSheafGate tc01_sheaf tc04_eta tc04a_Apin tc04a_cpin tc04a_bundle
      detail   := "FilledTriangle_H1Zero_ConflictingAnchors_AffineFarkasDual" },
    { vecId    := "TC-04b"
      expected := .verifiedAnchorOrGuardIncompatibility 1 0
      actual   := auditCellularSheafGate tc01_sheaf tc04_eta tc04b_Apin tc04b_cpin tc04b_bundle
      detail   := "FilledTriangle_H1Zero_PinnedStalkPositivityGuardViolation" },
    { vecId    := "TC-05a"
      expected := .rejectedInvalidComplexOrSheaf .boundaryNotNilpotent
      actual   := auditCellularSheafGate tc05a_sheaf tc04_eta tc03_Apin tc03_cpin tc05a_dummyBundle
      detail   := "Step1_FlippedFaceBoundarySign_partial1partial2_ne_0" },
    { vecId    := "TC-05b"
      expected := .rejectedInvalidComplexOrSheaf .nonFunctorialSheafRestriction
      actual   := auditCellularSheafGate tc05b_sheaf tc04_eta tc03_Apin tc03_cpin tc05b_dummyBundle
      detail   := "Step3_ValidBoundaryAndUnits_NonCommutingDiamondRestriction" },
    { vecId    := "TC-06"
      expected := .rejectedInvalidCertificate
      actual   := auditCellularSheafGate tc02_sheaf (zeroVec tc02_sheaf.N1) tc02_Apin tc02_cpin tc06_forgedBundle
      detail   := "Step6_ForgedH1ZeroCertificateOnHollow3Cycle" },
    { vecId    := "TC-07a"
      expected := .rejectedInvalidComplexOrSheaf .illTypedStalkOrMatrix
      actual   := auditCellularSheafGate tc07a_sheaf tc04_eta tc03_Apin tc03_cpin tc07a_dummyBundle
      detail   := "Step2_EnergyToTorqueRestrictionMatrixSmugglingBlocked" },
    { vecId    := "TC-07b"
      expected := .rejectedInvalidComplexOrSheaf .authorityEscalation
      actual   := auditCellularSheafGate tc07b_sheaf tc04_eta tc03_Apin tc03_cpin tc07b_dummyBundle
      detail   := "Step5_GlobalAuthorityMeet_FormalOnlyToEmpiricalBlocked" } ]

end GrandZero.StageC
